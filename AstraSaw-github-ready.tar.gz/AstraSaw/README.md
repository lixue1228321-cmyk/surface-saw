# AstraSaw

Experimental research project targeting iOS 27.0.1 (iPhone 15 Pro Max / A17 Pro).

This repository contains staged exploration code and notes for various local primitives (sandbox escape attempts, information leaks, IOSurface-related races, IPC-related techniques). Most paths documented in `DEAD_PATHS.md` are no longer viable on the tested firmware.

## Contents

- `AstraSaw/` — Xcode project sources (Swift + Objective-C)
- `analysis/` — Research notes
- `DEAD_PATHS.md` — Detailed record of failed / blocked channels across multiple runs

## Status (as of last recorded run)

| Primitive     | Status     | Notes                                      |
|---------------|------------|--------------------------------------------|
| KASLR         | Dead       | No surviving leak channels                 |
| Kernel read   | Dead       |                                            |
| Kernel write  | Partial    | Trigger possible, reclaim unreliable       |
| Sandbox       | Partial    | Some fd-related experiments                |
| IPC related   | Partial    | Obfuscation / encryption observed          |

See `DEAD_PATHS.md` for the full breakdown.

## Building

Open `AstraSaw.xcodeproj` in Xcode.  
Target is for research on a specific device / firmware combination.  
No prebuilt IPA is included.

## Disclaimer

This is research / educational material only.  
It is provided as-is with no warranty.  
The authors are not responsible for any use or misuse.  
Test only on devices you own.  
Many techniques shown here are already mitigated or unreliable.

## License

Research archive. No formal license assigned by original authors.  
Use at your own risk.
