// AppleKeyStore Selector Fuzzer — kREAD info leak hunter
//
// Probes all reachable AppleKeyStore selectors for:
//   1. OOB reads returning kernel heap data (CVE-2026-65343 variants)
//   2. Uninitialized output buffers containing stale kernel pointers
//   3. Error paths that leak kernel addresses in return codes
//
// Target: iOS 27.0.1 (24A446) — iPhone17,2 / A17 Pro
// Context: Device probe confirmed AppleKeyStore OPEN with 67 selectors from sandbox

#ifndef AKS_FUZZER_H
#define AKS_FUZZER_H

#include <stdint.h>
#include <stdbool.h>

#define AKS_MAX_SELECTORS    128
#define AKS_MAX_HITS         64

typedef void (*aks_log_fn)(const char *line);

typedef struct {
    uint32_t selector;
    uint64_t value;
    uint32_t offset;
    uint32_t output_size;
    uint8_t  method_type;   // 0=scalar, 1=struct, 2=mixed
    uint8_t  input_pattern; // which input pattern triggered it
} aks_hit_t;

typedef struct {
    bool     aks_opened;
    uint32_t selectors_reachable;
    uint32_t selectors_responding;
    uint32_t total_bytes_scanned;
    uint32_t hit_count;
    aks_hit_t hits[AKS_MAX_HITS];
    uint64_t  kaslr_candidate;
    bool     has_kaslr;
} aks_fuzzer_result_t;

void aks_fuzzer_set_log(aks_log_fn fn);
void aks_fuzzer_run(aks_fuzzer_result_t *result);

#endif
