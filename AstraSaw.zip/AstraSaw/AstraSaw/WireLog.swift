import Foundation
import Darwin
import os.log

// TCP log server on port 4242.
// Mac side: iproxy 4242 4242 && nc localhost 4242
// All chain output streams here in real time.

final class WireLog: @unchecked Sendable {
    static let shared = WireLog()
    private let oslog = OSLog(subsystem: "com.astra.saw", category: "chain")
    private let queue = DispatchQueue(label: "wirelog", qos: .utility)
    private var clients: [Int32] = []
    private var serverFd: Int32 = -1
    private let port: UInt16 = 4242
    private var buffer: [String] = []  // full log history — replayed on new connect
    private var fileHandle: FileHandle?
    private(set) var logFileURL: URL?
    private var autoTimer: Timer?
    private var lastUploadedLineCount = -1

    func start() {
        queue.async {
            self.openLogFile()
            self.listen()
        }
    }

    private func openLogFile() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HHmmss"
        let name = "astrasaw_\(formatter.string(from: Date())).log"
        let url = docs.appendingPathComponent(name)
        FileManager.default.createFile(atPath: url.path, contents: nil)
        fileHandle = try? FileHandle(forWritingTo: url)
        fileHandle?.seekToEndOfFile()
        logFileURL = url
    }

    func reset() {
        queue.async {
            self.buffer.removeAll()
            self.fileHandle?.closeFile()
            self.openLogFile()
        }
        NotificationCenter.default.post(name: .wireLogReset, object: nil)
        log("=== LOG RESET ===", level: .stage)
    }

    func allLogFiles() -> [URL] {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let files = (try? FileManager.default.contentsOfDirectory(at: docs, includingPropertiesForKeys: [.creationDateKey])) ?? []
        return files.filter { $0.lastPathComponent.hasPrefix("astrasaw_") && $0.pathExtension == "log" }
            .sorted { $0.lastPathComponent > $1.lastPathComponent }
    }

    private func listen() {
        serverFd = socket(AF_INET6, SOCK_STREAM, 0)
        guard serverFd >= 0 else { return }

        var yes: Int32 = 1
        setsockopt(serverFd, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))
        setsockopt(serverFd, SOL_SOCKET, SO_NOSIGPIPE, &yes, socklen_t(MemoryLayout<Int32>.size))

        var noV6Only: Int32 = 0
        setsockopt(serverFd, IPPROTO_IPV6, IPV6_V6ONLY, &noV6Only, socklen_t(MemoryLayout<Int32>.size))

        var addr = sockaddr_in6()
        addr.sin6_len = UInt8(MemoryLayout<sockaddr_in6>.size)
        addr.sin6_family = sa_family_t(AF_INET6)
        addr.sin6_port = port.bigEndian
        addr.sin6_addr = in6addr_any

        let bindResult = withUnsafePointer(to: &addr) { ptr in
            ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) { sa in
                bind(serverFd, sa, socklen_t(MemoryLayout<sockaddr_in6>.size))
            }
        }
        guard bindResult == 0 else {
            close(serverFd)
            serverFd = -1
            return
        }

        Darwin.listen(serverFd, 4)

        DispatchQueue.global(qos: .background).async {
            while self.serverFd >= 0 {
                let clientFd = accept(self.serverFd, nil, nil)
                if clientFd >= 0 {
                    var flag: Int32 = 1
                    setsockopt(clientFd, IPPROTO_TCP, TCP_NODELAY, &flag, socklen_t(MemoryLayout<Int32>.size))
                    setsockopt(clientFd, SOL_SOCKET, SO_NOSIGPIPE, &flag, socklen_t(MemoryLayout<Int32>.size))
                    self.queue.async {
                        self.clients.append(clientFd)
                        let banner = "[AstraSaw] connected — replaying \(self.buffer.count) buffered lines\n"
                        _ = Darwin.send(clientFd, banner, banner.utf8.count, 0)
                        for old in self.buffer {
                            let d = Array(old.utf8)
                            _ = Darwin.send(clientFd, d, d.count, 0)
                        }
                        let sep = "[AstraSaw] — live stream from here —\n"
                        _ = Darwin.send(clientFd, sep, sep.utf8.count, 0)
                    }
                }
            }
        }
    }

    func log(_ message: String, level: Level = .info) {
        let ts = Self.timestamp()
        let prefix: String
        switch level {
        case .info:  prefix = "[·]"
        case .ok:    prefix = "[+]"
        case .warn:  prefix = "[!]"
        case .fail:  prefix = "[-]"
        case .stage: prefix = "[»]"
        case .data:  prefix = "[=]"
        }
        let line = "\(ts) \(prefix) \(message)\n"

        os_log("%{public}s", log: oslog, type: level.osType, line)

        queue.async {
            self.buffer.append(line)
            if let lineData = line.data(using: .utf8) {
                self.fileHandle?.write(lineData)
                self.fileHandle?.synchronizeFile()
            }
            let data = Array(line.utf8)
            self.clients.removeAll { fd in
                let sent = Darwin.send(fd, data, data.count, 0)
                if sent <= 0 {
                    close(fd)
                    return true
                }
                return false
            }
        }

        NotificationCenter.default.post(
            name: .wireLogLine,
            object: nil,
            userInfo: ["line": line, "level": level]
        )
    }

    func stage(_ n: Int, _ name: String) {
        log("═══════════════════════════════════════", level: .stage)
        log("STAGE \(n): \(name)", level: .stage)
        log("═══════════════════════════════════════", level: .stage)
    }

    func ok(_ msg: String) { log(msg, level: .ok) }
    func warn(_ msg: String) { log(msg, level: .warn) }
    func fail(_ msg: String) { log(msg, level: .fail) }
    func data(_ msg: String) { log(msg, level: .data) }

    private static func timestamp() -> String {
        var tv = timeval()
        gettimeofday(&tv, nil)
        var tm = tm()
        var time = tv.tv_sec
        localtime_r(&time, &tm)
        return String(format: "%02d:%02d:%02d.%03d",
                      tm.tm_hour, tm.tm_min, tm.tm_sec, tv.tv_usec / 1000)
    }

    func sendLogs(completion: @escaping (Bool) -> Void) {
        sendLogs(final: false, completion: completion)
    }

    /// Last endpoint that answered. Probing six candidate gateways on every
    /// flush would stall the log queue for seconds, so the winner is cached and
    /// reused until a POST fails.
    private static var cachedLogURL: URL?
    private static let logCandidates = ["172.20.10.11", "172.20.10.1", "172.20.10.2",
                                        "192.168.1.1", "192.168.0.1", "10.0.0.1"]

    private func resolveLogURL() -> URL {
        if let u = WireLog.cachedLogURL { return u }
        for ip in WireLog.logCandidates {
            let u = URL(string: "http://\(ip):7777/log")!
            var req = URLRequest(url: u)
            req.httpMethod = "HEAD"
            req.timeoutInterval = 1.0
            let sem = DispatchSemaphore(value: 0)
            var ok = false
            URLSession.shared.dataTask(with: req) { _, resp, _ in
                if let http = resp as? HTTPURLResponse, http.statusCode > 0 { ok = true }
                sem.signal()
            }.resume()
            _ = sem.wait(timeout: .now() + 1.5)
            if ok {
                WireLog.cachedLogURL = u
                return u
            }
        }
        let fallback = URL(string: "http://172.20.10.11:7777/log")!
        WireLog.cachedLogURL = fallback
        return fallback
    }

    /// Upload the whole buffer to the Mac receiver.
    ///
    /// `final == true` marks the payload as a completed run, which makes the
    /// receiver keep a timestamped copy in addition to `wirelog_latest.txt`.
    func sendLogs(final: Bool, completion: @escaping (Bool) -> Void = { _ in }) {
        queue.async {
            let text = self.buffer.joined()
            guard !text.isEmpty else { completion(false); return }
            let url = self.resolveLogURL()
            var req = URLRequest(url: url)
            req.httpMethod = "POST"
            req.httpBody = text.data(using: .utf8)
            req.timeoutInterval = 10
            req.setValue("text/plain", forHTTPHeaderField: "Content-Type")
            req.setValue(final ? "1" : "0", forHTTPHeaderField: "X-Log-Final")
            URLSession.shared.dataTask(with: req) { _, resp, _ in
                let ok = (resp as? HTTPURLResponse)?.statusCode == 200
                if !ok { WireLog.cachedLogURL = nil }
                DispatchQueue.main.async { completion(ok) }
            }.resume()
        }
    }

    // MARK: - Unattended log upload

    /// Push the whole log to the Mac every `seconds`, and once more when the
    /// chain finishes. Nobody has to tap "Send": a run that ends in a panic or
    /// a killed app still leaves the latest snapshot on the Mac.
    func startAutoUpload(every seconds: TimeInterval = 10) {
        DispatchQueue.main.async {
            guard self.autoTimer == nil else { return }
            self.autoTimer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: true) { [weak self] _ in
                self?.uploadSnapshot(final: false)
            }
            self.autoTimer?.tolerance = 2
        }
    }

    func uploadSnapshot(final: Bool) {
        queue.async {
            if !final && self.buffer.count == self.lastUploadedLineCount { return }
            guard !self.buffer.isEmpty else { return }
            self.lastUploadedLineCount = self.buffer.count
            self.sendLogs(final: final) { ok in
                if !ok {
                    self.queue.async { self.lastUploadedLineCount = -1 }
                }
            }
        }
    }

    enum Level: Sendable {
        case info, ok, warn, fail, stage, data
        var osType: OSLogType {
            switch self {
            case .info, .data: return .info
            case .ok, .stage:  return .default
            case .warn:        return .error
            case .fail:        return .fault
            }
        }
    }
}

extension Notification.Name {
    static let wireLogLine = Notification.Name("wireLogLine")
    static let wireLogReset = Notification.Name("wireLogReset")
}

