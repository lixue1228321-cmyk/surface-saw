import SwiftUI

@main
struct AstraSawApp: App {
    init() {
        WireLog.shared.start()
        WireLog.shared.log("AstraSaw initialized — TCP log server on port 4242")
        WireLog.shared.log("connect from Mac: iproxy 4242 4242 && nc localhost 4242")
        // HTTP upload disabled — use Xcode console + on-device log file instead
        // WireLog.shared.startAutoUpload(every: 10)
    }

    var body: some Scene {
        WindowGroup {
            ChainView()
        }
    }
}

struct ChainView: View {
    @StateObject private var runner = ChainRunner()

    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("AstraSaw")
                        .font(.system(size: 24, weight: .bold, design: .monospaced))
                        .foregroundColor(.green)
                    Text("sandbox → leak → race → krw → sptm")
                        .font(.system(size: 11, design: .monospaced))
                        .foregroundColor(.gray)
                }
                Spacer()
                Circle()
                    .fill(runner.running ? Color.orange : Color.green)
                    .frame(width: 12, height: 12)
            }
            .padding(.horizontal)
            .padding(.top, 8)

            // Stage indicators
            HStack(spacing: 6) {
                ForEach(0..<6) { i in
                    stageIndicator(i)
                }
            }
            .padding(.horizontal)
            .padding(.vertical, 8)

            // Log view
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 1) {
                        ForEach(Array(runner.logLines.enumerated()), id: \.offset) { idx, line in
                            Text(line.trimmingCharacters(in: .newlines))
                                .font(.system(size: 10, design: .monospaced))
                                .foregroundColor(colorForLine(line))
                                .id(idx)
                        }
                    }
                    .padding(.horizontal, 8)
                }
                .background(Color.black)
                .onChange(of: runner.logLines.count) { _ in
                    if let last = runner.logLines.indices.last {
                        proxy.scrollTo(last, anchor: .bottom)
                    }
                }
            }

            // Buttons
            HStack(spacing: 8) {
                Button(action: {
                    let url: URL
                    if let existing = WireLog.shared.logFileURL,
                       FileManager.default.isReadableFile(atPath: existing.path) {
                        url = existing
                    } else {
                        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                        let tmp = docs.appendingPathComponent("astrasaw_share.log")
                        let text = runner.logLines.joined()
                        try? text.write(to: tmp, atomically: true, encoding: .utf8)
                        url = tmp
                    }
                    let avc = UIActivityViewController(activityItems: [url], applicationActivities: nil)
                    if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                       let root = scene.keyWindow?.rootViewController {
                        avc.popoverPresentationController?.sourceView = root.view
                        avc.popoverPresentationController?.sourceRect = CGRect(x: root.view.bounds.midX, y: root.view.bounds.maxY - 60, width: 0, height: 0)
                        root.present(avc, animated: true)
                    }
                }) {
                    HStack {
                        Image(systemName: "square.and.arrow.up")
                        Text("Share")
                            .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color(white: 0.2))
                    .foregroundColor(.white)
                    .cornerRadius(12)
                }
                .disabled(runner.logLines.isEmpty)

                Button(action: { runner.sendLogs() }) {
                    HStack {
                        Image(systemName: "paperplane.fill")
                        Text(runner.sendStatus.isEmpty ? "Send" : runner.sendStatus)
                            .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color(white: 0.2))
                    .foregroundColor(.cyan)
                    .cornerRadius(12)
                }
                .disabled(runner.running || !runner.sendStatus.isEmpty)

                Button(action: { runner.runChain() }) {
                    HStack {
                        Image(systemName: runner.running ? "bolt.fill" : "play.fill")
                        Text(runner.running ? "Running..." : "Run")
                            .font(.system(size: 13, weight: .semibold, design: .monospaced))
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(runner.running ? Color.orange : Color.green)
                    .foregroundColor(.black)
                    .cornerRadius(12)
                }
                .disabled(runner.running)
            }
            .padding()
        }
        .background(Color(white: 0.05))
        .preferredColorScheme(.dark)
        .onAppear {
            // Unattended runs: `devicectl device process launch … --autorun`
            // (or ASTRASAW_AUTORUN=1) starts the chain without a tap on the
            // screen, so a run does not depend on someone holding the phone.
            let env = ProcessInfo.processInfo.environment
            let args = ProcessInfo.processInfo.arguments
            if env["ASTRASAW_AUTORUN"] == "1" || args.contains("--autorun") {
                WireLog.shared.log("AstraSaw: autorun requested by launch arguments")
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    if !runner.running { runner.runChain() }
                }
            }
        }
    }

    private func stageIndicator(_ n: Int) -> some View {
        let names = ["recon", "sandbox", "leak", "race", "krw", "sptm"]
        let status = runner.stageStatus[n] ?? "pending"
        let color: Color
        switch status {
        case "ok":      color = .green
        case "partial": color = .yellow
        case "warn":    color = .orange
        case "fail":    color = .red
        case "running": color = .blue
        default:        color = Color(white: 0.3)
        }

        return VStack(spacing: 2) {
            RoundedRectangle(cornerRadius: 4)
                .fill(color)
                .frame(height: 6)
            Text(names[n])
                .font(.system(size: 8, design: .monospaced))
                .foregroundColor(color)
        }
        .frame(maxWidth: .infinity)
    }

    private func colorForLine(_ line: String) -> Color {
        if line.contains("[+]") { return .green }
        if line.contains("[!]") { return .orange }
        if line.contains("[-]") { return .red }
        if line.contains("[»]") { return .cyan }
        if line.contains("[=]") { return .yellow }
        return Color(white: 0.7)
    }
}

