// ipc_uaf_turbo.h — Enhanced IPC UAF calibration for A18 Pro (4GHz P-cores)
// Fixes: separate affinity tags, timing sweep, extended iterations,
//        time-constraint thread policy, stagger strategies.
// Target: iOS 27.0.1 (d94ap / A18 Pro)
#ifndef IPC_UAF_TURBO_H
#define IPC_UAF_TURBO_H

#include <stdint.h>
#include <stdbool.h>
#include <mach/mach.h>

typedef void (*turbo_log_fn)(const char *msg);

typedef struct {
    uint32_t variant;
    uint32_t overlap;
    uint32_t confused;
    uint32_t iterations;
    uint32_t best_delay_ns;
    uint32_t best_busywait;
    uint32_t affinity_strategy;
} turbo_cal_result_t;

typedef struct {
    bool     any_overlap;
    bool     any_confused;
    uint32_t total_overlap;
    uint32_t total_confused;
    uint32_t best_variant;
    uint32_t best_strategy;
    turbo_cal_result_t per_variant[5];
} turbo_sweep_result_t;

void turbo_set_log(turbo_log_fn fn);

turbo_sweep_result_t turbo_calibrate_all(void);

turbo_cal_result_t turbo_calibrate_variant(uint32_t variant, uint32_t iters);

turbo_cal_result_t turbo_calibrate_deep(uint32_t variant, uint32_t iters);

#endif
