import Foundation

enum HEICGenerator {

    struct Payload {
        let url: URL
    }

    static func generate(name: String) -> Payload? {
        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent("\(name).heic")
        guard let data = minimalHEIC() else { return nil }
        do {
            try data.write(to: tmp)
            return Payload(url: tmp)
        } catch {
            return nil
        }
    }

    private static func minimalHEIC() -> Data? {
        var buf = Data()
        func box(_ type: String, _ payload: Data) -> Data {
            var d = Data(count: 4)
            let len = UInt32(payload.count + 8).bigEndian
            withUnsafeBytes(of: len) { d.replaceSubrange(0..<4, with: $0) }
            d.append(type.data(using: .ascii)!)
            d.append(payload)
            return d
        }
        let ftyp = box("ftyp", Data("heic".utf8) + Data(repeating: 0, count: 4) + Data("heic".utf8))
        buf.append(ftyp)
        let meta = box("meta", Data(repeating: 0, count: 4) + box("hdlr", Data(repeating: 0, count: 24)) + box("pitm", Data(repeating: 0, count: 4)))
        buf.append(meta)
        return buf
    }
}
