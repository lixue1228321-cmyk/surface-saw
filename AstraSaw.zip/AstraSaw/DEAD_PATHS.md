# AstraSaw — Dead Paths Registry

> iOS 27.0.1 / iPhone 15 Pro Max (iPhone17,2 / D94AP / A17 Pro)
> Last updated: 2026-11-19 (Run 8)

---

## Chain Status (Run 8)

| Primitive | Status | Details |
|-----------|--------|---------|
| KASLR | **DEAD** | 0 channels survive. Was solved in Run 7 (slide=0xcb7fc000) but that was previous boot |
| kWRITE | **PARTIAL** | IOSurface UAF triggers (sel17/sel18 OK), but `reclaimed=false` — spray doesn't land |
| kREAD | **DEAD** | DarkSword code alive, but 0 inpcb addresses from any channel |
| IPC UAF | **ACTIVE** | Confused port 0x20688b, ip_context echo works, but iin_object ENCRYPTED |

---

## Run 8 New Dead Channels (2026-11-19)

These channels were probed with new diagnostic code and confirmed dead:

| ID | Channel | Bytes Scanned | kptrs Found | Root Cause |
|----|---------|--------------|-------------|------------|
| R8-PCBLIST | 13 pcblist sysctls | 0 | 0 | EPERM (sandbox) or ENOENT (sysctl removed) |
| R8-PROCPID | proc_pidinfo(PIDFDSOCKETINFO) | 136/socket × 4 | 0 | Returns only 136B (wrong API), value at +108=`0xFFFFFFFF` is timestamp default |
| R8-MPKO | mach_port_kernel_object(task_self) | N/A | addr=0x0 | Sanitized on iOS 27 |
| R8-MPKO-HOST | mach_port_kernel_object(host) | N/A | addr=0x0 | Sanitized on iOS 27 |
| R8-KPROC | sysctl kern.proc.pid.N | 648 | 0 | All kernel pointers zeroed |
| R8-BOOTTIME | kern.boottime | 16 | 0 | Timestamps only |
| R8-WAKETIME | kern.waketime | 16 | 0 | Timestamps only |
| R8-CACHECFG | hw.cacheconfig | 80 | 0 | Cache line sizes only |
| R8-CACHESZ | hw.cachesize | 80 | 0 | Cache sizes only |
| R8-PAGESZ | hw.pagesize | 8 | 0 | Value=16384 |
| R8-ROUTE | net.routetable | 0 | 0 | EPERM |
| R8-ISSEL | IOSurface sel 0-30 | 0 | 0 | No selector returns kernel data |
| R8-IIN | IPC space_info iin_object | 8076 entries | ENCRYPTED | Low-3 bits differ across entries → NOT simple XOR. 3497 ports on 1 page → impossible |
| R8-STAGE2 | Stage 2 all channels | 1,244,907 | 0 | decmpfs, IOSurface, mach_msg, task_info, kinfo_proc, vm_region, proc_info, host_info, IOSurfaceRoot enum |
| R8-RECLAIM | IOSurface UAF reclaim | N/A | N/A | triggered=true, reclaimed=false — spray timing wrong |

**Run 8 verdict: ZERO kernel pointers from ANY channel. Total scan: ~1.25MB.**

---

## Historical Dead Paths (85+ from Run 1-7)

### Category Summary

| Cat | Root Cause | Count |
|-----|-----------|-------|
| C1 | API Sanitization — iOS 27 zeroes all kernel address returns | 11+ |
| C2 | Type Isolation — kalloc_type zone segregation | 5 |
| C3 | Hardware Protection — SPTM/PAC/DART/PAN | 6+ |
| C4 | Race Too Narrow — nanosecond window | 4+ |
| C5 | Architectural Design — not a pointer/leak | 5+ |
| C6 | Userspace Gatekeeper — VT/CoreMedia validates | 4 |
| C7 | Scope/Reachability — entitlement or boundary | 4+ |
| C8 | Counter Not Content-Sensitive | 3 |
| C9 | GPU Memory Isolation — DART/GART | 4 |
| C10 | Data vs Metadata Separation | 3+ |

### A. KASLR Leak Paths (7 — ALL DEAD)

- **A1** mach_port_kobject — zeroed kaddr
- **A2** task_info(TASK_DYLD_INFO) — userspace addr only
- **A3** IORegistry property scan — 0/1327 properties had kptrs
- **A4** Port space scan — 0/241 ports leaked kaddrs
- **A5** IOSurface property reflection — user-facing only
- **A6** KASLR decmpfs — 0/23 compressed files leaked
- **A7** IOSurface pixel buffer scan — userspace memory, conceptual error

### B. GPU / Metal (4 — ALL DEAD)

- **B1** F1OOB GPU cross-object OOB — Metal hardware bounds-check
- **B2** GPU→Kernel R/W via UAT — DEFINITIVE: UAT blocks GPU→kernel
- **B3** GPU PT KRW — dead by transitivity (B2)
- **B4** Metal buffer-extension OOB — DART silently discards

### C. IOSurface Overflow (2 — DEAD)

- **C1** compressionType=3 — kernel rejects
- **C2** sliceCount tile OOB — clamped to 1

### D. AVE / Video Encoder (4 — ALL DEAD)

- **D1** AVE DMA corruption — DART protects
- **D2** AVE OOB v2 — wrong zone
- **D3** MMCO DPB OOB (CVE-2026-112689) — dual bounds check
- **D4** AVE Temporal kR/W (CVE-2026-112705) — VT + kernel check

### E. AVC / Video Codec (2 — DEAD)

- **E1-E2** AVC SPS OOB — VT rejects before kernel

### F. IPC / Mach (2 — DEAD)

- **F1** IPC Port Request Table OOB (CVE-2026-112507) — single grow, no race
- **F2** IPC Port Table Write — same fundamental issue

### G. ANE (1 — DEAD)

- **G1** ANE symbolIndex OOB (CVE-2026-84494) — real bug, unreachable from sandbox

### H. SPTM (3 — DEAD from userspace)

- **H1-H3** CAS race, SAPT bypass, GMMU TLBI skip — all require EL2/EL3

### I-L. IOMFB, JPEG, AppleKeyStore (3 — DEAD)

- **I1** IOMFB (CVE-2026-112459) — DCP firmware side
- **K1** ScalerCSC UAF — ExclusiveAccess locked
- **L1** AppleJPEGDriver — CannotLock on all 128 selectors

### M-Q. Race/Overflow Paths (5 — DEAD)

- **M1** SocketUAF (CVE-2026-112514) — nanosecond window, 0 wins
- **N1** FlowDivert UAF (CVE-2026-112679) — 32K sockets, 0 corruption
- **O1** HEVC DPB via VT — gatekeeper blocks all 5 sub-paths
- **P1** APFS Crypto Refcount — resource leak, not UAF
- **Q1** VM Lock Counter Overflow — needs 16384 threads, limit 4096

### R-V. Oracle/Timing Paths (5 — DEAD)

- **R1** AVE2 Shared Memory kptr — 0/16 reactive
- **S1** F1OOB Kernel Write — DISPROVEN (user-to-user, unmapped hole)
- **T1** IOSurface Header Region via GPU — metadata in kalloc, not wired
- **U1** GPU Read Near-Gap — unmapped holes
- **V1** AVE2 Oracle — monotonic counter, not content-sensitive

### W-Z9. Advanced Exploitation Paths (15+ — ALL DEAD)

- **W1** HandleRace UAF kptr extraction — type isolation, 0 kptrs
- **X1** Physmap kRead → PTE manipulation — SPTM protects
- **Y1** KASLR timing side channel — counter-based
- **Z1-Z7** IPC UAF port kaddr recovery (7 strategies) — all sanitized/isolated
- **Z2.1** ip_context as pointer — DEFINITIVE: 0/619 sites dereference
- **Z3.1** space_info iin_object correlation — cryptographically hashed
- **Z4.1** HandleRace Deep — 6-phase probe, 0 kptrs
- **Z5.1** Spray reclaim stale IOSurface — Catch-22 (alive=no free, free=no API)
- **Z6.1** F1OOB + Confused Surface — GART mapping stale
- **Z7.1** Plane gap scan — pixel data only, 0 kptrs
- **Z8.1** OOL Descriptor Hijack — zone isolation + GPU-only
- **Z9.1** ip_context dereference sites — 186 LDR all false positives

### Run 7 Additional Dead Paths

- **DMA-R7** — DMA kread64, ringSetup always fails
- **SCALER-R7** — ScalerKRead, calibration failed
- **VT-ORACLE-R7** — VT dereference oracle, macho=false x8
- **PWRITEV-R7** — pwritev race, 0 wins (patched)
- **STAGE3-R7** — Kernel race CVE-2026-112507, 6000 ops 0 signal
- **AKS-R7** — AppleKeyStore 67 sels, 3/128 accessible, 0 kptrs
- **IPC-UAF-R7** — IPC UAF 0 wins (but ALIVE again in Run 8!)

---

## ALIVE Paths (Run 8)

| Path | Status | Blocker |
|------|--------|---------|
| **IOSurface UAF (CVE-2026-112477)** | trigger=YES, reclaim=NO | Spray timing — freed slot not reclaimed |
| **DarkSword ICMPv6 kread** | Code ready, sockets open | No inpcb kernel addresses |
| **IPC UAF (CVE-2026-112474)** | ACTIVE confused port | iin_object encrypted, kaddrs unreliable |
| **Sandbox escape (CVE-2026-112706)** | WORKING | N/A — this stage is complete |

---

## DO NOT RE-ATTEMPT

The following have been tested to exhaustion. Re-attempting wastes device time:

1. Any pcblist sysctl — ALL blocked by sandbox (EPERM) or removed (ENOENT)
2. proc_pidinfo for socket kernel addresses — sanitized to 0
3. mach_port_kernel_object — returns 0 on iOS 27
4. Any GPU-based kernel memory access — DART/UAT blocks everything
5. ip_context dereference — architecturally impossible
6. OOL descriptor cross-zone reclaim — zone isolation prevents it
7. AVE2/VT oracles — monotonic counters, not content-sensitive
