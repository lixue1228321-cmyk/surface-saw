# iin_object Obfuscation Analysis — DEAD PATH

**Date:** 2026-11-19
**Target:** iOS 27.0.1 (24A446) — iPhone17,2 / A17 Pro
**Verdict:** ❌ DEAD — VM_KERNEL_ADDRHASH is a one-way salted hash, non-invertible from userspace

---

## Summary

`mach_port_space_info()` returns `ipc_info_name_t` entries where `iin_object` contains the kernel address of the port object. On iOS 27.0.1, this field is **obfuscated** via `VM_KERNEL_ADDRHASH`, not the older `VM_KERNEL_ADDRPERM` (simple addition).

The hash is **one-way, salted with a per-boot random value, and truncated to 32 bits**. It cannot be reversed from userspace.

---

## Source Evidence

From `apple-oss-distributions/xnu` (main branch), `osfmk/ipc/mach_debug.c`:

```c
iin->iin_object = (natural_t)VM_KERNEL_ADDRHASH(
    (uintptr_t)port_pointers[index]);
```

Where `VM_KERNEL_ADDRHASH` is defined in `osfmk/mach/vm_param.h`:

```c
#define VM_KERNEL_ADDRHASH(_v) vm_kernel_addrhash((vm_offset_t)(_v))
```

The function `vm_kernel_addrhash()` uses `vm_kernel_addrhash_salt` — a **per-boot random value** initialized at kernel startup. The algorithm is a salted hash function (not XOR, not addition).

### natural_t truncation

`iin_object` is `natural_t` = `uint32_t`. The 64-bit hash output is truncated to 32 bits. Even if the hash were invertible, the upper 32 bits of the kernel address are permanently lost.

---

## Device Evidence (from log.log)

Five `iin_object` values from `mach_port_space_info()`:

| Entry | iin_object | Low 3 bits |
|-------|-----------|------------|
| 0     | 0x...4    | 100        |
| 1     | 0x...5    | 101        |
| 2     | 0x...6    | 110        |
| 3     | 0x...7    | 111        |
| 4     | 0x...2    | 010        |

All 5 low-3-bit values **differ**. Real kernel addresses in `ipc.ports` zone are 8-byte aligned (low 3 bits = 000). If the obfuscation were XOR or addition with a fixed constant, low 3 bits would be identical across all entries. The variation **proves** a non-linear hash is used.

Additional evidence: 3497 "ports" reported on a single 16KB page — impossible with real kernel addresses (each port object is >>4 bytes), confirming the values are hash outputs, not addresses.

---

## Attack Vectors Considered and Rejected

### 1. Brute-force inversion
- Input space: 2^64 possible kernel addresses
- Output space: 2^32 hash values
- Salt: unknown per-boot random
- **Infeasible** even with known hash algorithm

### 2. Known-plaintext attack
- Would need: a known kernel address + its hash output
- No kernel address is available from any userspace API (all channels sanitized)
- Circular dependency: need a kptr to break the hash, need the hash to get a kptr

### 3. Birthday/collision attack
- Could find two inputs with same hash, but doesn't help: we need the SPECIFIC address, not any collision

### 4. Timing/side-channel on hash computation
- `mach_port_space_info()` returns all entries at once — no per-entry timing observable
- No other observable side-channel from userspace

### 5. Use VM_KERNEL_ADDRPERM instead
- The older `VM_KERNEL_ADDRPERM` uses simple addition (`addr + salt`)
- BUT `mach_port_space_info` uses `VM_KERNEL_ADDRHASH`, not `ADDRPERM`
- No API returns ADDRPERM'd port addresses from app sandbox on 27.0.1

---

## Comparison: ADDRHASH vs ADDRPERM

| Property | VM_KERNEL_ADDRPERM | VM_KERNEL_ADDRHASH |
|----------|-------------------|-------------------|
| Algorithm | `addr + salt` | `hash(addr, salt)` |
| Invertible | Yes (subtract salt) | No |
| Salt recovery | From any known pair | Impossible without algo |
| Used in space_info | No (legacy) | **Yes (current)** |

---

## Conclusion

**Strategy 2 (iin_object de-obfuscation) is permanently dead.** The kernel deliberately upgraded from invertible ADDRPERM to non-invertible ADDRHASH specifically to prevent userspace from recovering kernel addresses through Mach port introspection APIs. This is a fundamental design decision, not a bug to exploit.

The remaining viable paths for kREAD are:
1. **IOSurface UAF reclaim** — fix spray timing to land controlled data in freed kalloc.1024 slot
2. **IOSurface stale-read** — read freed slot's stale data (vtable pointers) via selector enumeration before reclaim
