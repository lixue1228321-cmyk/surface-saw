# Strategy 3: IOSurface Stale-Read Info Leak Research

**Date**: 2026-11-19  
**Target**: iOS 27.0.1 (24A446) — iPhone17,2 / A17 Pro  
**Goal**: Find an IOSurface selector that reads stale data from freed kalloc.1024 slot after CVE-2026-112477 UAF → leak kernel pointers → kREAD

---

## 1. IOSurface Registry Architecture (from kernelcache strings)

The IOSurfaceRoot maintains an internal registry (linked list) for surface registration:
- **sel17** (register/async): adds entry to registry, starts async completion
- **sel18** (deregister): LIST_REMOVE — modifies list, no userspace read

Registry entry structure contains:
- Owner pointer → IOSurfaceRootUserClient (FREED after IOServiceClose)
- Surface pointer → IOSurface object
- Linked list prev/next pointers
- Completion flag at +0xf0 (the TOCTOU target)

### Allocation types found:
- `site.IOSurfaceClientSharedListEntry` — per-client shared list entry
- `site.IOSurfaceSharedListEntry` — global shared list entry
- `site.IOSurfaceEventNotifierClient` — event notification client
- `site.IOSurfaceSendRight` / `site.IOSurfaceWiredSendRight` — Mach port send rights

---

## 2. Selector Analysis — Data-Reading Operations

### Selectors that return data to userspace:

| Sel | Handler | Data Read Path | Stale-Read Potential |
|-----|---------|---------------|---------------------|
| 0 | `s_create_surface` / `create_surface` | Creates new surface, returns ID | **NO** — write operation |
| 1 | release_surface | Releases surface | **NO** — write |
| 6 | `create_surface_fast_path` | Fast create | **NO** — write |
| 8 | get_ycbcrmatrix | Returns matrix constant | **NO** — fixed value |
| 9 | set_value | Sets property on IOSurface object | **NO** — write |
| 10 | get_value | Reads property from IOSurface's OSDictionary | **LOW** — reads from surface object, not freed slot |
| 11 | remove_value | Removes property | **NO** — write |
| 16 | get_surface_use_count | Returns integer counter | **LOW** — reads from surface, not freed memory |
| 17 | register (async) | Registers in registry | **NO** — write |
| 18 | deregister (sync) | LIST_REMOVE from registry | **NO** — write (modifies list) |
| 34 | lookup_surface_from_port | Looks up surface by Mach port | **MAYBE** — traverses global table |
| 35 | create_port_from_surface | Creates Mach port for surface | **NO** — write |

### IOConnectMapMemory paths:

| Type | Maps | Contains kptrs? |
|------|------|----------------|
| 0 | Pixel buffer (surface planes) | **NO** — raw pixel data |
| 1 | `create_surface_client_mem` — client shared memory | **UNLIKELY** — user-visible metadata |
| Event | Shared event memory region | **UNLIKELY** — mapped counters/flags |

---

## 3. SharedEvent Notification System

Extensive event infrastructure found:
- `IOSurfaceSharedEvent` — event object with signal/wait semantics
- `IOSurfaceSharedEventListener` — listener with priority, WorkLoop, agent mask
- `IOSurfaceSharedEventNotification` — notification descriptor
- `IOSurfaceSharedEventNotificationPort` — Mach port for notifications
- `IOSurfaceSharedEventReference` — reference wrapper
- `IOSurfaceEventNotifierClient` — per-client event notifier

### Listener refcon path:
```
"IOSurfaceRootUserClient: duplicate listener refcon %08llx"
```
The refcon is 8 bytes. If a listener is registered on a surface associated with the freed
registry entry, the notification callback may pass stale data as the refcon.

**Verdict**: Not directly exploitable for kREAD — refcon is set by userspace, not read from kernel.

---

## 4. Key Insight: Shared Memory Mapping

```
"IOSurfaceRootUserClient: asked to allocate client shared id %08x not known by IOSurfaceRoot"
"IOSurfaceRootUserClient: couldn't map shared memory region into client"
```

There is a "client shared" allocation system where the IOSurfaceRoot maintains shared memory
regions identified by IDs. If a mapping persists after the UAF trigger and references the freed
slot's metadata, the mapped pages could expose kernel pointers.

**But**: Shared memory maps user-visible data (surface properties, counters), not kernel internal
metadata. The kernel pointer layout (vtable, zone pointers) is NOT in the mapped region.

---

## 5. Stale-Read Verdict: NO VIABLE PATH VIA IOSurface SELECTORS

### Why stale-read fails:

1. **No selector reads from registry entries** — the registry is internal, traversed only during
   register/deregister operations. No selector enumerates or dumps registry content.

2. **Property operations (sel 9/10/11) work on IOSurface objects** — these have their own
   OSDictionary stored separately from the registry entry and the freed kalloc.1024 slot.

3. **Use count (sel 16) returns a simple counter** — from the IOSurface object header, not
   from the freed memory.

4. **Shared memory contains user data** — mapped regions hold pixel buffers and event counters,
   not kernel metadata.

5. **The freed slot is a kalloc.1024 allocation** — it previously held IOSurfaceRootUserClient
   data (vtable, internal pointers). No selector is designed to read raw UserClient fields back
   to userspace.

---

## 6. Alternative Path: AppleKeyStore (67 selectors — HIGH VALUE)

### CVE-2026-65343 Details (from ByteV0rtex PoC):
- **Function**: `_LibSer_SEPControl_Deserialize`
- **Bug**: `copyout(payload_ptr, user_buf, declared_length)` — `declared_length` unchecked against buffer bounds
- **OOB**: declared_length=0x800 → copies ~0x7E8 bytes past buffer end
- **Result**: Adjacent heap allocations contain kernel pointers (`0xfffffff0xxxxxxxx`)
- **KASLR defeat**: Scan output for known AKS symbol offset → compute slide

### Status on iOS 27.0.1:
- **Patched in 26.6.1** (23G83) — 27.0.1 should have the fix
- **BUT**: Device probe confirmed AppleKeyStore OPEN with **67 selectors** from sandbox
- The PoC replays across 163 selectors — many might have DIFFERENT OOB or info leak bugs
- **67 unexplored selectors = massive unexplored attack surface**

### Sandbox reachability note:
CVE-2026-65343 README says "Direct IOServiceOpen blocked for sideloaded apps" — contradicts our
device probe which showed it OPEN. This may depend on:
1. Entitlements of the test app
2. iOS version differences (26 vs 27)
3. The XPC path through `ctkd` (bypasses direct IOServiceOpen requirement)

### Recommendation: FUZZ ALL 67 SELECTORS
Priority fuzzing targets for info leak:
- Selectors that return structured output (check `structureOutputSize > 0`)
- Selectors that handle serialization (SEP control messages)
- Selectors that return error messages containing kernel state
- Selectors with large output buffers (potential OOB reads)

---

## 7. Additional Leads Worth Investigating

### A. `IOSurface::getIndexedTimestamp(uint64_t)`
Found in kernelcache:
```
uint64_t IOSurface::getIndexedTimestamp(uint64_t) const
```
If the index is user-controlled and timestamps are stored inline, an out-of-bounds index
could read adjacent kernel memory. **Needs disassembler verification.**

### B. `IOSurfaceTransaction::serialize`
```
"IOSurfaceTransaction::serialize panic because of attempting to write to nullptr."
```
The serialize path processes transaction data. If a transaction references the freed registry
entry's surface, serialization might read stale fields. **Needs disassembler analysis.**

### C. `IOSurface::copyTimingInfo()`
```
IOSurface::copyTimingInfo() - dictionary copy failed
```
Copies timing dictionary from surface object. If the timing dictionary pointer is overlapped
with freed memory during reclaim, `copyTimingInfo` could copy stale data.
**Low probability but worth checking.**

---

## 8. Conclusions and Next Steps

### Dead:
- IOSurface stale-read via public selectors — no path exists

### Alive:
1. **AppleKeyStore 67-selector fuzzing** (HIGHEST PRIORITY)
   - Build IOKit fuzzer targeting all 67 reachable selectors
   - Focus on selectors with structured output or large buffers
   - Check if CVE-2026-65343 fix is complete or if variant exists

2. **Kernelcache disassembly required** (MEDIUM)
   - Install Ghidra (set GHIDRA_INSTALL_DIR) to analyze:
     - IOSurfaceRootUserClient dispatch table (sMethodDescs)
     - `getIndexedTimestamp` bounds checking
     - `IOSurfaceTransaction::serialize` data flow
     - SharedEvent notification data paths

3. **IOSurface shared memory mapping audit** (LOW)
   - Enumerate all IOConnectMapMemory types for IOSurfaceRoot
   - Check if any mapped region overlaps with or references kalloc.1024 zone metadata
